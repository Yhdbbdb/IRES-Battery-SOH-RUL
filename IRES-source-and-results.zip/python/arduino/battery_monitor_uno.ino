/*
 Arduino UNO battery monitor.
 Serial: Cell1,Cell2,Pack,Current,Temperature
 IMPORTANT: never connect a battery directly to an Arduino ADC pin.
 Use correctly rated voltage dividers/current/temperature sensors.
 Calibrate all constants for your actual hardware.
*/
const int CELL1_PIN=A0,CELL2_PIN=A1,PACK_PIN=A2,CURRENT_PIN=A3,TEMP_PIN=A4;
const float ADC_REF=5.0,ADC_MAX=1023.0;
const float CELL_DIVIDER=2.0,PACK_DIVIDER=4.0;
const float CURRENT_ZERO=2.50,CURRENT_SENSITIVITY=0.185;
const float TEMP_SENSITIVITY=0.010;
float av(int p){return analogRead(p)*ADC_REF/ADC_MAX;}
void setup(){Serial.begin(115200);delay(1000);Serial.println("BATTERY_MONITOR_READY");}
void loop(){
 static unsigned long last=0;if(millis()-last<1000)return;last=millis();
 float v1=av(CELL1_PIN)*CELL_DIVIDER,v2=av(CELL2_PIN)*CELL_DIVIDER,vp=av(PACK_PIN)*PACK_DIVIDER;
 float cur=(av(CURRENT_PIN)-CURRENT_ZERO)/CURRENT_SENSITIVITY;
 float temp=av(TEMP_PIN)/TEMP_SENSITIVITY;
 Serial.print(v1,3);Serial.print(",");Serial.print(v2,3);Serial.print(",");Serial.print(vp,3);Serial.print(",");Serial.print(cur,3);Serial.print(",");Serial.println(temp,2);
}
