# ============================================================
# main.py
# HYBRID BATTERY SOH / RUL PREDICTION SYSTEM
#
# FINAL PROJECT CONTROLLER
#
# 1. Prepare Dataset
# 2. Train SOH/RUL Models
# 3. Manual Prediction
# 4. Arduino Real-Time Dashboard
# 5. Model Information
# 6. Test Arduino Serial
# 7. Project Status
# 8. Exit
# ============================================================

import json
import subprocess
import sys
from pathlib import Path


# ============================================================
# PROJECT PATH
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


# ============================================================
# CONFIGURATION
# ============================================================

try:

    from config import (
        DATASET_CSV,
        MODEL_DIR,
        RESULTS_DIR,
        SERIAL_PORT,
        SERIAL_BAUD,
        FEATURES,
        EOL_SOH,
    )

except Exception as exc:

    print()
    print("=" * 72)
    print("CONFIGURATION ERROR")
    print("=" * 72)
    print(
        f"{type(exc).__name__}: {exc}"
    )
    print()
    print(
        "Make sure config.py is present in the project root."
    )
    raise


MODEL_DIR = Path(MODEL_DIR)
RESULTS_DIR = Path(RESULTS_DIR)


# ============================================================
# MODEL ARTIFACTS
# ============================================================

SOH_MODEL_NAMES = [
    "soh_RandomForest.joblib",
    "soh_BaggingTree.joblib",
    "soh_ExtraTrees.joblib",
    "soh_GradientBoosting.joblib",
    "soh_XGBoost.joblib",
]

RUL_ARTIFACTS = [
    "rul_CNN_BiLSTM.keras",
    "rul_CNN_BiLSTM_scaler.joblib",
    "rul_CNN_BiLSTM_metadata.json",
    "rul_BaggingTree.joblib",
    "rul_HistGradientBoosting.joblib",
]


# ============================================================
# HEADER
# ============================================================

def print_header():

    print()
    print("=" * 72)
    print(
        " HYBRID BATTERY SOH / RUL PREDICTION SYSTEM"
    )
    print("=" * 72)

    print(
        " Hardware : Arduino UNO"
    )

    print(
        " SOH      : RandomForest"
    )

    print(
        " RUL      : CNN-BiLSTM"
    )

    print(
        " RUL input: 20 completed discharge cycles"
    )

    print(
        f" EOL      : SOH <= {EOL_SOH}%"
    )

    print("=" * 72)


# ============================================================
# DATASET CHECK
# ============================================================

def dataset_exists():

    return Path(
        DATASET_CSV
    ).exists()


# ============================================================
# MODEL CHECK
# ============================================================

def soh_model_exists():

    return any(
        (
            MODEL_DIR / name
        ).exists()
        for name in SOH_MODEL_NAMES
    )


def cnn_rul_models_exist():

    required = [
        "rul_CNN_BiLSTM.keras",
        "rul_CNN_BiLSTM_scaler.joblib",
        "rul_CNN_BiLSTM_metadata.json",
    ]

    return all(
        (
            MODEL_DIR / name
        ).exists()
        for name in required
    )


def traditional_rul_models_exist():

    return (
        (
            MODEL_DIR
            / "rul_BaggingTree.joblib"
        ).exists()
        or
        (
            MODEL_DIR
            / "rul_HistGradientBoosting.joblib"
        ).exists()
    )


def models_exist():

    # The realtime system uses RandomForest for SOH.
    # The primary RUL system uses CNN-BiLSTM.
    return (
        soh_model_exists()
        and cnn_rul_models_exist()
    )


# ============================================================
# MODEL SELECTION FILE
# ============================================================

def selection_file():

    return (
        MODEL_DIR
        / "model_selection_results.json"
    )


def read_model_selection():

    path = selection_file()

    if not path.exists():
        return {}

    try:

        with open(
            path,
            "r",
            encoding="utf-8",
        ) as file:

            return json.load(file)

    except Exception:

        return {}


# ============================================================
# OPTION 1
# ============================================================

def prepare_dataset():

    print()
    print("=" * 72)
    print(
        "DATASET PREPARATION"
    )
    print("=" * 72)

    try:

        from src.dataset_preparation import load

        result = load()

        print()

        if result is not None:

            print(
                "Dataset preparation completed successfully."
            )

        else:

            print(
                "Dataset preparation did not produce a dataset."
            )

    except Exception as exc:

        print()
        print(
            "DATASET ERROR"
        )

        print(
            f"{type(exc).__name__}: {exc}"
        )


# ============================================================
# OPTION 2
# ============================================================

def train_models():

    print()
    print("=" * 72)
    print(
        "MODEL TRAINING"
    )
    print("=" * 72)

    if not dataset_exists():

        print()
        print(
            "Dataset does not exist."
        )

        print(
            "Run option 1 first."
        )

        return

    try:

        from src.models import train

        train()

        print()
        print(
            "=" * 72
        )
        print(
            "TRAINING FINISHED"
        )
        print(
            "=" * 72
        )

        if soh_model_exists():

            print(
                "[OK] SOH model artifact found."
            )

        else:

            print(
                "[WARNING] SOH model artifact not found."
            )

        if cnn_rul_models_exist():

            print(
                "[OK] CNN-BiLSTM RUL artifacts found."
            )

        else:

            print(
                "[WARNING] CNN-BiLSTM RUL artifacts not found."
            )

    except Exception as exc:

        print()
        print(
            "TRAINING ERROR"
        )

        print(
            f"{type(exc).__name__}: {exc}"
        )


# ============================================================
# OPTION 3
# ============================================================

def manual_prediction_menu():

    print()
    print("=" * 72)
    print(
        "MANUAL BATTERY PREDICTION"
    )
    print("=" * 72)

    if not soh_model_exists():

        print()
        print(
            "SOH model was not found."
        )

        print(
            "Run option 2 first."
        )

        return

    try:

        print()
        print(
            "Enter one calibrated battery measurement."
        )

        print(
            "NOTE: One measurement is NOT a complete discharge cycle."
        )

        print(
            "Therefore the CNN-BiLSTM RUL prediction is not generated here."
        )

        print()

        cell1 = float(
            input(
                "Cell 1 Voltage (V): "
            )
        )

        cell2 = float(
            input(
                "Cell 2 Voltage (V): "
            )
        )

        pack = float(
            input(
                "Pack Voltage (V): "
            )
        )

        current = float(
            input(
                "Current (A): "
            )
        )

        temperature = float(
            input(
                "Temperature (°C): "
            )
        )

        cycle_index_text = input(
            "Cycle number [1]: "
        ).strip()

        cycle_index = (
            int(cycle_index_text)
            if cycle_index_text
            else 1
        )

        from src.realtime_prediction import (
            manual_prediction
        )

        result = manual_prediction(
            cell1_voltage=cell1,
            cell2_voltage=cell2,
            pack_voltage=pack,
            current=current,
            temperature=temperature,
            cycle_index=cycle_index,
        )

        print()
        print("=" * 60)
        print(
            "MANUAL PREDICTION RESULT"
        )
        print("=" * 60)

        print(
            f"Cell 1 Voltage : "
            f"{result['cell1_voltage']:.3f} V"
        )

        print(
            f"Cell 2 Voltage : "
            f"{result['cell2_voltage']:.3f} V"
        )

        print(
            f"Pack Voltage   : "
            f"{result['pack_voltage']:.3f} V"
        )

        print(
            f"Current        : "
            f"{result['current']:.3f} A"
        )

        print(
            f"Temperature    : "
            f"{result['temperature']:.2f} °C"
        )

        print(
            f"Battery Mode   : "
            f"{result['battery_mode']}"
        )

        print(
            f"SOC            : "
            f"{result['soc']:.2f}%"
        )

        print(
            f"Cell Imbalance : "
            f"{result['cell_imbalance']:.4f} V"
        )

        print()

        if result["soh"] is not None:

            print(
                f"SOH            : "
                f"{result['soh']:.2f}%"
            )

            print(
                f"SOH Model      : "
                f"{result['SOH_model']}"
            )

            if result["soh"] <= EOL_SOH:

                print(
                    "Health Status  : "
                    "EOL / BELOW THRESHOLD"
                )

            else:

                print(
                    "Health Status  : "
                    "ABOVE EOL THRESHOLD"
                )

        else:

            print(
                "SOH            : unavailable"
            )

        print()

        print(
            "RUL            : Not generated"
        )

        print(
            "RUL Status     : "
            "Requires 20 completed discharge cycles"
        )

        print("=" * 60)

    except ValueError as exc:

        print()
        print(
            "INVALID INPUT"
        )

        print(
            str(exc)
        )

    except Exception as exc:

        print()
        print(
            "PREDICTION ERROR"
        )

        print(
            f"{type(exc).__name__}: {exc}"
        )


# ============================================================
# OPTION 4
# ============================================================

def open_dashboard():

    print()
    print("=" * 72)
    print(
        "ARDUINO REAL-TIME DASHBOARD"
    )
    print("=" * 72)

    dashboard = (
        PROJECT_ROOT
        / "dashboard.py"
    )

    if not dashboard.exists():

        print(
            "dashboard.py was not found."
        )

        return

    try:

        subprocess.run(
            [
                sys.executable,
                "-m",
                "streamlit",
                "run",
                str(dashboard),
            ],
            check=False,
        )

    except Exception as exc:

        print()
        print(
            "DASHBOARD ERROR"
        )

        print(
            f"{type(exc).__name__}: {exc}"
        )


# ============================================================
# OPTION 5
# ============================================================

def model_information():

    print()
    print("=" * 72)
    print(
        "MODEL INFORMATION"
    )
    print("=" * 72)

    print()

    print(
        "Model directory:"
    )

    print(
        f"  {MODEL_DIR}"
    )

    print()

    print(
        "SOH:"
    )

    if soh_model_exists():

        for name in SOH_MODEL_NAMES:

            path = (
                MODEL_DIR
                / name
            )

            if path.exists():

                print(
                    f"  [FOUND] {name}"
                )

    else:

        print(
            "  [NOT FOUND]"
        )

    print()

    print(
        "Primary RUL model:"
    )

    if cnn_rul_models_exist():

        print(
            "  [FOUND] rul_CNN_BiLSTM.keras"
        )

        print(
            "  [FOUND] rul_CNN_BiLSTM_scaler.joblib"
        )

        print(
            "  [FOUND] rul_CNN_BiLSTM_metadata.json"
        )

    else:

        print(
            "  [NOT COMPLETE]"
        )

    print()

    print(
        "Traditional RUL artifacts:"
    )

    if traditional_rul_models_exist():

        for name in [
            "rul_BaggingTree.joblib",
            "rul_HistGradientBoosting.joblib",
        ]:

            if (
                MODEL_DIR
                / name
            ).exists():

                print(
                    f"  [FOUND] {name}"
                )

    else:

        print(
            "  None found"
        )

    print()

    selection = read_model_selection()

    if selection:

        print(
            "Training selection result:"
        )

        for key, value in selection.items():

            print(
                f"  {key}: {value}"
            )

    else:

        print(
            "No model_selection_results.json found."
        )

    print()

    print(
        "Feature schema:"
    )

    print(
        f"  Number of features: {len(FEATURES)}"
    )

    for index, feature in enumerate(
        FEATURES,
        start=1,
    ):

        print(
            f"  {index:02d}. {feature}"
        )

    print()

    print(
        "Real-time RUL requirement:"
    )

    print(
        "  20 completed discharge cycles"
    )

    print()

    print(
        "EOL threshold:"
    )

    print(
        f"  SOH <= {EOL_SOH}%"
    )

    print("=" * 72)


# ============================================================
# OPTION 6
# ============================================================

def test_arduino():

    print()
    print("=" * 72)
    print(
        "ARDUINO SERIAL TEST"
    )
    print("=" * 72)

    print()

    print(
        f"Default port: {SERIAL_PORT}"
    )

    print(
        f"Baud rate   : {SERIAL_BAUD}"
    )

    custom = input(
        "Enter COM port or press ENTER for default: "
    ).strip()

    port = (
        custom
        if custom
        else SERIAL_PORT
    )

    reader = None

    try:

        from src.arduino_serial import (
            ArduinoReader
        )

        reader = ArduinoReader(
            port,
            SERIAL_BAUD,
        )

        reader.connect()

        print()
        print(
            "Arduino connected successfully."
        )

        print()
        print(
            "Expected packet:"
        )

        print(
            "cell1_voltage,"
            "cell2_voltage,"
            "pack_voltage,"
            "current,"
            "temperature"
        )

        print()
        print(
            "Reading 20 valid samples..."
        )

        print(
            "Press Ctrl+C to stop."
        )

        count = 0

        while count < 20:

            sample = (
                reader.read_sample()
            )

            if sample is not None:

                print(
                    sample
                )

                count += 1

        print()
        print(
            "Serial test completed."
        )

    except KeyboardInterrupt:

        print()
        print(
            "Serial test stopped."
        )

    except Exception as exc:

        print()
        print(
            "SERIAL ERROR"
        )

        print(
            f"{type(exc).__name__}: {exc}"
        )

    finally:

        if reader is not None:

            try:
                reader.disconnect()
            except Exception:
                pass


# ============================================================
# OPTION 7
# ============================================================

def project_status():

    print()
    print("=" * 72)
    print(
        "PROJECT STATUS"
    )
    print("=" * 72)

    print()

    # --------------------------------------------------------
    # Dataset
    # --------------------------------------------------------

    print(
        "Dataset:"
    )

    if dataset_exists():

        print(
            "  [OK] Dataset exists"
        )

        print(
            f"       {DATASET_CSV}"
        )

    else:

        print(
            "  [NOT READY] Dataset not found"
        )

    print()

    # --------------------------------------------------------
    # SOH
    # --------------------------------------------------------

    print(
        "SOH Model:"
    )

    if soh_model_exists():

        for name in SOH_MODEL_NAMES:

            if (
                MODEL_DIR
                / name
            ).exists():

                print(
                    f"  [OK] {name}"
                )

    else:

        print(
            "  [NOT READY]"
        )

    print()

    # --------------------------------------------------------
    # RUL
    # --------------------------------------------------------

    print(
        "RUL CNN-BiLSTM:"
    )

    if cnn_rul_models_exist():

        print(
            "  [OK] Model"
        )

        print(
            "  [OK] Scaler"
        )

        print(
            "  [OK] Metadata"
        )

    else:

        print(
            "  [NOT READY]"
        )

    print()

    # --------------------------------------------------------
    # Arduino
    # --------------------------------------------------------

    print(
        "Arduino:"
    )

    print(
        f"  Port : {SERIAL_PORT}"
    )

    print(
        f"  Baud : {SERIAL_BAUD}"
    )

    print()

    # --------------------------------------------------------
    # Features
    # --------------------------------------------------------

    print(
        "ML features:"
    )

    print(
        f"  {len(FEATURES)} exact training features"
    )

    print()

    # --------------------------------------------------------
    # RUL
    # --------------------------------------------------------

    print(
        "RUL requirement:"
    )

    print(
        "  20 completed discharge cycles"
    )

    print()

    # --------------------------------------------------------
    # Capacity
    # --------------------------------------------------------

    print(
        "Battery configuration:"
    )

    print(
        "  2S Li-ion"
    )

    print(
        "  1200 mAh per cell"
    )

    print(
        "  1200 mAh pack capacity in series"
    )

    print()

    # --------------------------------------------------------
    # Overall
    # --------------------------------------------------------

    if models_exist():

        print(
            "Overall ML status:"
        )

        print(
            "  [READY] SOH + CNN-BiLSTM RUL"
        )

    else:

        print(
            "Overall ML status:"
        )

        print(
            "  [NOT READY] Train models first"
        )

    print("=" * 72)


# ============================================================
# MAIN MENU
# ============================================================

def main():

    while True:

        print_header()

        print()

        print(
            "1. Prepare NASA + CSV Dataset"
        )

        print(
            "2. Train SOH/RUL Models"
        )

        print(
            "3. Manual Battery Prediction"
        )

        print(
            "4. Open Arduino Real-Time Dashboard"
        )

        print(
            "5. Model Information"
        )

        print(
            "6. Test Arduino Serial"
        )

        print(
            "7. Project Status"
        )

        print(
            "8. Exit"
        )

        print()

        choice = input(
            "Select an option: "
        ).strip()

        if choice == "1":

            prepare_dataset()

        elif choice == "2":

            train_models()

        elif choice == "3":

            manual_prediction_menu()

        elif choice == "4":

            open_dashboard()

        elif choice == "5":

            model_information()

        elif choice == "6":

            test_arduino()

        elif choice == "7":

            project_status()

        elif choice == "8":

            print()
            print(
                "Exiting Hybrid Battery "
                "SOH/RUL System..."
            )

            break

        else:

            print()
            print(
                "Invalid option."
            )

        if choice != "4":

            input(
                "\nPress ENTER to continue..."
            )


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":

    main()
