"""
make_figures.py - rebuild the paper's graphs from YOUR files (nothing is hard-coded).

Inputs
  --log      training_log.txt   console output of option 2 (Train SOH/RUL Models), pasted/saved as text
  --summary  battery_summary.csv   written by option 1 (data/processed/battery_summary.csv)
  --oof      oof_predictions.csv   OPTIONAL out-of-fold predictions, columns:
                                   task (SOH or RUL), model, battery_id, fold, y_true, y_pred
  --out      figs                  output folder (PDF + PNG)

Usage (defaults work from the project root, so the PyCharm Run button is enough)
  python make_figures.py
  python make_figures.py --log training_log.txt --summary data/processed/battery_summary.csv
  python make_figures.py --log training_log.txt --summary battery_summary.csv --oof oof_predictions.csv

Produces: soh_folds, rul_folds, summary, cnn_train, initial_soh
          (+ actual_vs_pred_*, residuals_*, per_battery_* when --oof is given)

Needs: numpy, pandas, matplotlib.

How to get oof_predictions.csv: in your cross-validation loop, after predicting each
validation fold, append rows and save once at the end, e.g.
    rows += [dict(task="SOH", model=name, battery_id=b, fold=k, y_true=yt, y_pred=yp)
             for b, yt, yp in zip(groups[val_idx], y[val_idx], pred)]
    pd.DataFrame(rows).to_csv("oof_predictions.csv", index=False)
"""
import argparse
import os
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

plt.rcParams.update({"font.size": 7, "font.family": "serif", "axes.linewidth": 0.6, "figure.dpi": 200})
COLORS = ["#1f4e79", "#c55a11", "#548235", "#7f7f7f"]


# ----------------------------------------------------------------- log parsing
def parse_log(path):
    """Return ({'SOH': {model: {'MAE': [...], 'RMSE': [...], 'R2': [...]}}, 'RUL': {...}}, epoch_mae list)."""
    text = open(path, encoding="utf-8", errors="ignore").read()
    res = {"SOH": {}, "RUL": {}}
    task = model = None
    for line in text.splitlines():
        m = re.match(r"\s*(SOH|RUL) MODEL:\s*(\S+)", line)
        if m:
            task, model = m.group(1), m.group(2)
            res[task].setdefault(model, {"MAE": [], "RMSE": [], "R2": []})
            continue
        m = re.match(r"\s*Fold\s+(\d+):\s*MAE=([-\d.]+),\s*RMSE=([-\d.]+),\s*R2=([-\d.]+)", line)
        if m:  # CNN-BiLSTM one-line format
            d = res["RUL"].setdefault("CNN-BiLSTM", {"MAE": [], "RMSE": [], "R2": []})
            d["MAE"].append(float(m.group(2)))
            d["RMSE"].append(float(m.group(3)))
            d["R2"].append(float(m.group(4)))
            continue
        m = re.match(r"\s*(MAE|RMSE|R2)\s*=\s*([-\d.]+)\s*$", line)
        if m and task and model:
            res[task][model][m.group(1)].append(float(m.group(2)))
    # training curve of the FINAL model: epoch lines after the last "Epoch 1/"
    starts = [m.start() for m in re.finditer(r"Epoch 1/\d+", text)]
    tail = text[starts[-1]:] if starts else ""
    epoch_mae = [float(x) for x in re.findall(r"loss:\s*[-\d.]+\s*-\s*mae:\s*([-\d.]+)", tail)]
    return res, epoch_mae


def clean(res):
    return {t: {m: v for m, v in d.items() if len(v["MAE"]) > 0} for t, d in res.items()}


# --------------------------------------------------------------------- plots
def savefig(fig, out, name):
    fig.tight_layout()
    fig.savefig(os.path.join(out, name + ".pdf"))
    fig.savefig(os.path.join(out, name + ".png"), dpi=300)
    plt.close(fig)


def fold_bars(d, ylabel, out, name, log=False):
    k = max(len(v["MAE"]) for v in d.values())
    folds = np.arange(1, k + 1)
    w = 0.8 / len(d)
    fig, ax = plt.subplots(figsize=(3.4, 2.1))
    for i, (m, v) in enumerate(d.items()):
        ax.bar(folds + (i - (len(d) - 1) / 2) * w, v["MAE"], w, label=m, color=COLORS[i % 4])
    ax.set_xlabel("GroupKFold fold"); ax.set_ylabel(ylabel); ax.set_xticks(folds)
    if log:
        ax.set_yscale("log")
    ax.grid(axis="y", lw=0.3); ax.legend(frameon=False, fontsize=6)
    savefig(fig, out, name)


def summary_plot(res, out):
    fig, axs = plt.subplots(1, 2, figsize=(3.4, 2.0))
    for ax, t, lab in zip(axs, ["SOH", "RUL"], ["SOH MAE (pp)", "RUL MAE (cycles)"]):
        d = res[t]
        names = list(d)
        mean = [np.mean(d[n]["MAE"]) for n in names]
        std = [np.std(d[n]["MAE"], ddof=1) for n in names]
        ax.bar(range(len(names)), mean, yerr=std, capsize=3, color=COLORS[:len(names)], error_kw={"lw": 0.6})
        ax.set_xticks(range(len(names)))
        ax.set_xticklabels([n[:6] for n in names], rotation=30, ha="right")
        ax.set_ylabel(lab); ax.grid(axis="y", lw=0.3)
    savefig(fig, out, "summary")


def train_curve(epoch_mae, cv_mae, out):
    if not epoch_mae:
        print("  (no 'Epoch ... mae:' lines found - skipped cnn_train)")
        return
    fig, ax = plt.subplots(figsize=(3.4, 2.0))
    ax.plot(range(1, len(epoch_mae) + 1), epoch_mae, color=COLORS[2], lw=1, label="Training MAE (final model)")
    if cv_mae is not None:
        ax.axhline(cv_mae, color="k", ls="--", lw=0.7, label=f"5-fold CV MAE ({cv_mae:.2f})")
    ax.set_xlabel("Epoch"); ax.set_ylabel("MAE (cycles)"); ax.grid(lw=0.3); ax.legend(frameon=False, fontsize=6)
    savefig(fig, out, "cnn_train")


def initial_soh(csv, out):
    df = pd.read_csv(csv)
    df = df.sort_values("battery_id").reset_index(drop=True)
    colors = ["#c00000" if (r.eol_reached and r.eol_cycle == 1) else "#1f4e79" for r in df.itertuples()]
    fig, ax = plt.subplots(figsize=(7.0, 2.0))
    ax.bar(range(len(df)), df["first_soh"], color=colors)
    ax.axhline(80, color="k", ls="--", lw=0.7)
    ax.text(len(df) - 0.6, 82, "80% EOL", ha="right", fontsize=6)
    ax.set_xticks(range(len(df)))
    ax.set_xticklabels([b.replace("B0", "") for b in df["battery_id"]], rotation=90, fontsize=5.5)
    ax.set_ylabel("First-cycle SOH (%)")
    ax.set_xlabel("NASA cell (B0xxx); red = EOL assigned at cycle 1")
    ax.grid(axis="y", lw=0.3)
    savefig(fig, out, "initial_soh")
    print(f"  cells with EOL at cycle 1: {sum(c == '#c00000' for c in colors)} of {len(df)}")


def oof_plots(csv, out):
    df = pd.read_csv(csv)
    for task, unit in [("SOH", "%"), ("RUL", "cycles")]:
        for model, g in df[df.task == task].groupby("model"):
            tag = f"{task}_{model}".replace(" ", "_")
            lo, hi = min(g.y_true.min(), g.y_pred.min()), max(g.y_true.max(), g.y_pred.max())
            fig, ax = plt.subplots(figsize=(3.0, 3.0))
            ax.scatter(g.y_true, g.y_pred, s=4, alpha=0.5, color=COLORS[0])
            ax.plot([lo, hi], [lo, hi], "k--", lw=0.7)
            ax.set_xlabel(f"Actual {task} ({unit})"); ax.set_ylabel(f"Predicted {task} ({unit})"); ax.grid(lw=0.3)
            savefig(fig, out, f"actual_vs_pred_{tag}")
            fig, ax = plt.subplots(figsize=(3.4, 2.0))
            ax.hist(g.y_pred - g.y_true, bins=40, color=COLORS[1])
            ax.axvline(0, color="k", lw=0.7)
            ax.set_xlabel(f"Residual, predicted - actual ({unit})"); ax.set_ylabel("Count")
            savefig(fig, out, f"residuals_{tag}")
            pb = g.assign(ae=(g.y_pred - g.y_true).abs()).groupby("battery_id")["ae"].mean().sort_index()
            fig, ax = plt.subplots(figsize=(7.0, 2.0))
            ax.bar(range(len(pb)), pb.values, color=COLORS[0])
            ax.set_xticks(range(len(pb)))
            ax.set_xticklabels([b.replace("B0", "") for b in pb.index], rotation=90, fontsize=5.5)
            ax.set_ylabel(f"MAE ({unit})"); ax.grid(axis="y", lw=0.3)
            savefig(fig, out, f"per_battery_{tag}")


# ---------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--log", default=os.path.join("training_log", "training_log.txt"))
    ap.add_argument("--summary", default=os.path.join("data", "processed", "battery_summary.csv"))
    ap.add_argument("--oof", default=None)
    ap.add_argument("--out", default="plots")
    a = ap.parse_args()
    here = os.path.dirname(os.path.abspath(__file__))
    for attr in ("log", "summary", "out"):
        p = getattr(a, attr)
        if p and not os.path.isabs(p):
            setattr(a, attr, os.path.join(here, p))
    if a.oof and not os.path.isabs(a.oof):
        a.oof = os.path.join(here, a.oof)
    if not os.path.exists(a.log):
        raise SystemExit(f"Log file not found: {a.log}\nSave the console output of 'Train SOH/RUL Models' there "
                         f"(or pass --log path).")
    if a.summary and not os.path.exists(a.summary):
        print(f"  (summary csv not found: {a.summary} - skipping initial_soh)")
        a.summary = None
    os.makedirs(a.out, exist_ok=True)

    res, epoch_mae = parse_log(a.log)
    res = clean(res)
    for t in res:
        for m, v in res[t].items():
            print(f"  {t} {m}: {len(v['MAE'])} folds, mean MAE {np.mean(v['MAE']):.4f} "
                  f"+/- {np.std(v['MAE'], ddof=1):.4f}" if len(v["MAE"]) > 1 else f"  {t} {m}: {v}")
    if res["SOH"]:
        fold_bars(res["SOH"], "SOH MAE (pp)", a.out, "soh_folds")
    if res["RUL"]:
        fold_bars(res["RUL"], "RUL MAE (cycles, log)", a.out, "rul_folds", log=True)
    if res["SOH"] and res["RUL"]:
        summary_plot(res, a.out)
    cv = np.mean(res["RUL"]["CNN-BiLSTM"]["MAE"]) if "CNN-BiLSTM" in res["RUL"] else None
    train_curve(epoch_mae, cv, a.out)
    if a.summary:
        initial_soh(a.summary, a.out)
    if a.oof:
        oof_plots(a.oof, a.out)
    print(f"done -> {os.path.abspath(a.out)}")


if __name__ == "__main__":
    main()