# ============================================================
# AUTOMATED SOH + RUL MODEL TEST
# FINAL VERSION
#
# SOH:
#   XGBoost
#   Random Forest
#   Gradient Boosting
#
# RUL:
#   Random Forest
#   Extra Trees
#   CNN-BiLSTM
#
# NOTE:
# These are DATASET-WIDE / IN-SAMPLE verification results
# because the final saved models were trained using all data.
# The stacking section below fits the ensemble on the full dataset and
# reports in-sample verification metrics, not independent generalization.
# Scientific model selection should use battery-wise GroupKFold validation.
# ============================================================

import os
import json
import warnings

import joblib
import numpy as np
import pandas as pd

from sklearn.base import clone
from sklearn.ensemble import StackingRegressor
from sklearn.linear_model import Ridge

from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)

from tensorflow.keras.models import load_model


warnings.filterwarnings("ignore")


# ============================================================
# PATHS
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.abspath(__file__)
)

DATA_PATH = os.path.join(
    BASE_DIR,
    "data",
    "processed",
    "hybrid_cycle_dataset.csv"
)

MODELS_DIR = os.path.join(
    BASE_DIR,
    "models"
)

RESULTS_DIR = os.path.join(
    BASE_DIR,
    "data",
    "results"
)


os.makedirs(
    RESULTS_DIR,
    exist_ok=True
)


# ============================================================
# SETTINGS
# ============================================================

SEQUENCE_LENGTH = 20

FEATURES = [
    "voltage_mean",
    "voltage_min",
    "voltage_max",
    "voltage_std",
    "current_mean",
    "current_abs_mean",
    "current_rms",
    "current_std",
    "temperature_mean",
    "temperature_min",
    "temperature_max",
    "temperature_std",
    "duration_min",
    "power_mean",
    "power_abs_mean"
]


# ============================================================
# HEADER
# ============================================================

print("\n")
print("=" * 75)
print("AUTOMATED SOH + RUL MODEL TEST")
print("=" * 75)

print("\nSOH Models:")
print("  XGBoost")
print("  Random Forest")
print("  Gradient Boosting")
print("  Stacking Ensemble (RF + BaggingTree + ExtraTrees)")

print("\nRUL Models:")
print("  Random Forest")
print("  Extra Trees")
print("  CNN-BiLSTM")
print("  Stacking Ensemble (BaggingTree + HistGradientBoosting)")

print("\n" + "=" * 75)


# ============================================================
# LOAD DATA
# ============================================================

print("\nLoading dataset...")


if not os.path.exists(DATA_PATH):

    raise FileNotFoundError(
        f"Dataset not found:\n{DATA_PATH}"
    )


df = pd.read_csv(
    DATA_PATH
)


df = df.replace(
    [np.inf, -np.inf],
    np.nan
)


df = df.dropna(
    subset=FEATURES + [
        "soh",
        "rul",
        "battery_id",
        "cycle"
    ]
)


df = df.sort_values(
    [
        "battery_id",
        "cycle"
    ]
).reset_index(
    drop=True
)


print(
    "Dataset shape:",
    df.shape
)

print(
    "Battery groups:",
    df["battery_id"].nunique()
)


# ============================================================
# HELPER FUNCTION
# ============================================================

def calculate_metrics(
    y_true,
    y_pred
):

    mask = (
        np.isfinite(y_true)
        &
        np.isfinite(y_pred)
    )

    y_true = np.asarray(
        y_true
    )[mask]

    y_pred = np.asarray(
        y_pred
    )[mask]

    mae = mean_absolute_error(
        y_true,
        y_pred
    )

    rmse = np.sqrt(
        mean_squared_error(
            y_true,
            y_pred
        )
    )

    r2 = r2_score(
        y_true,
        y_pred
    )

    return (
        mae,
        rmse,
        r2
    )


# ============================================================
# ============================================================
# SOH TESTING
# ============================================================
# ============================================================

print("\n")
print("=" * 75)
print("SOH MODEL TESTING")
print("=" * 75)


X_soh = df[
    FEATURES
].values.astype(
    np.float32
)

y_soh = df[
    "soh"
].values.astype(
    np.float32
)


# ============================================================
# SOH MODEL FILES
# ============================================================

soh_model_files = {

    "XGBoost":
        "soh_XGBoost.joblib",

    "RandomForest":
        "soh_RandomForest.joblib",

    "GradientBoosting":
        "soh_GradientBoosting.joblib"
}


soh_results = []


# ============================================================
# TEST EACH SOH MODEL
# ============================================================

for model_name, filename in (
    soh_model_files.items()
):

    model_path = os.path.join(
        MODELS_DIR,
        filename
    )

    print("\n")
    print("-" * 75)
    print(
        f"Testing SOH: {model_name}"
    )
    print("-" * 75)

    if not os.path.exists(
        model_path
    ):

        print(
            "WARNING: Model not found:",
            model_path
        )

        continue


    try:

        model = joblib.load(
            model_path
        )

        predictions = model.predict(
            X_soh
        )

        predictions = np.asarray(
            predictions
        ).reshape(-1)


        mae, rmse, r2 = calculate_metrics(
            y_soh,
            predictions
        )


        soh_results.append({

            "Task": "SOH",

            "Model": model_name,

            "MAE": mae,

            "RMSE": rmse,

            "R2": r2,

            "Samples": len(
                predictions
            )
        })


        print(
            f"MAE  = {mae:.6f}"
        )

        print(
            f"RMSE = {rmse:.6f}"
        )

        print(
            f"R²   = {r2:.6f}"
        )


        # ----------------------------------------------------
        # SAVE PREDICTIONS
        # ----------------------------------------------------

        prediction_df = pd.DataFrame({

            "battery_id":
                df["battery_id"],

            "cycle":
                df["cycle"],

            "Actual_SOH":
                y_soh,

            "Predicted_SOH":
                predictions
        })


        prediction_path = os.path.join(
            RESULTS_DIR,
            f"automated_SOH_{model_name}.csv"
        )


        try:

            prediction_df.to_csv(
                prediction_path,
                index=False
            )

        except PermissionError:

            prediction_path = os.path.join(
                RESULTS_DIR,
                f"automated_SOH_{model_name}_new.csv"
            )

            prediction_df.to_csv(
                prediction_path,
                index=False
            )


        print(
            "Predictions saved:",
            prediction_path
        )


    except Exception as e:

        print(
            f"ERROR testing {model_name}:"
        )

        print(
            str(e)
        )



# ============================================================
# SOH STACKING ENSEMBLE
# Base models: RandomForest, BaggingTree, ExtraTrees
# Meta-model: Ridge regression
# ============================================================

print("\n")
print("=" * 75)
print("SOH STACKING ENSEMBLE")
print("=" * 75)

soh_stack_specs = [
    ("RandomForest", "soh_RandomForest.joblib"),
    ("BaggingTree", "soh_BaggingTree.joblib"),
    ("ExtraTrees", "soh_ExtraTrees.joblib"),
]

try:
    soh_estimators = []
    for estimator_name, filename in soh_stack_specs:
        model_path = os.path.join(MODELS_DIR, filename)
        if not os.path.exists(model_path):
            raise FileNotFoundError(
                f"Required SOH stacking base model is missing: {model_path}\n"
                "Run the model-training option in main.py first."
            )
        soh_estimators.append(
            (estimator_name.lower(), clone(joblib.load(model_path)))
        )

    soh_stack = StackingRegressor(
        estimators=soh_estimators,
        final_estimator=Ridge(alpha=1.0),
        cv=5,
        n_jobs=-1,
        passthrough=False,
    )
    soh_stack.fit(X_soh, y_soh)
    soh_stack_predictions = np.asarray(soh_stack.predict(X_soh)).reshape(-1)
    mae, rmse, r2 = calculate_metrics(y_soh, soh_stack_predictions)

    soh_results.append({
        "Task": "SOH",
        "Model": "Stacking Ensemble (RF + Bagging + ExtraTrees)",
        "MAE": mae,
        "RMSE": rmse,
        "R2": r2,
        "Samples": len(soh_stack_predictions),
    })

    print(f"MAE  = {mae:.6f}")
    print(f"RMSE = {rmse:.6f}")
    print(f"R²   = {r2:.6f}")

    prediction_df = pd.DataFrame({
        "battery_id": df["battery_id"],
        "cycle": df["cycle"],
        "Actual_SOH": y_soh,
        "Predicted_SOH_Stacking": soh_stack_predictions,
    })
    prediction_path = os.path.join(
        RESULTS_DIR, "automated_SOH_Stacking_Ensemble.csv"
    )
    try:
        prediction_df.to_csv(prediction_path, index=False)
    except PermissionError:
        prediction_path = os.path.join(
            RESULTS_DIR, "automated_SOH_Stacking_Ensemble_new.csv"
        )
        prediction_df.to_csv(prediction_path, index=False)
    print("Stacking predictions saved:", prediction_path)

    # Save the fitted ensemble for later inference.
    stack_model_path = os.path.join(MODELS_DIR, "soh_Stacking_Ensemble.joblib")
    joblib.dump(soh_stack, stack_model_path)
    print("Fitted stacking model saved:", stack_model_path)

except Exception as e:
    print("SOH stacking ensemble could not be evaluated:")
    print(str(e))


# ============================================================
# SOH SUMMARY
# ============================================================

soh_results_df = pd.DataFrame(
    soh_results
)


print("\n")
print("=" * 75)
print("SOH MODEL SUMMARY")
print("=" * 75)


if len(soh_results_df) > 0:

    print(
        soh_results_df[
            [
                "Model",
                "MAE",
                "RMSE",
                "R2"
            ]
        ].to_string(
            index=False
        )
    )


# ============================================================
# ============================================================
# RUL TRADITIONAL MODEL TESTING
# ============================================================
# ============================================================

print("\n")
print("=" * 75)
print("RUL TRADITIONAL MODEL TESTING")
print("=" * 75)


X_rul = df[
    FEATURES
].values.astype(
    np.float32
)

y_rul = df[
    "rul"
].values.astype(
    np.float32
)


rul_model_files = {

    "RandomForest":
        "rul_RandomForest.joblib",

    "ExtraTrees":
        "rul_ExtraTrees.joblib"
}


rul_results = []


# ============================================================
# TEST RANDOM FOREST + EXTRA TREES
# ============================================================

for model_name, filename in (
    rul_model_files.items()
):

    model_path = os.path.join(
        MODELS_DIR,
        filename
    )

    print("\n")
    print("-" * 75)
    print(
        f"Testing RUL: {model_name}"
    )
    print("-" * 75)


    if not os.path.exists(
        model_path
    ):

        print(
            "WARNING: Model not found:",
            model_path
        )

        continue


    try:

        model = joblib.load(
            model_path
        )

        predictions = model.predict(
            X_rul
        )

        predictions = np.asarray(
            predictions
        ).reshape(-1)


        mae, rmse, r2 = calculate_metrics(
            y_rul,
            predictions
        )


        rul_results.append({

            "Task": "RUL",

            "Model": model_name,

            "MAE": mae,

            "RMSE": rmse,

            "R2": r2,

            "Samples": len(
                predictions
            )
        })


        print(
            f"MAE  = {mae:.6f}"
        )

        print(
            f"RMSE = {rmse:.6f}"
        )

        print(
            f"R²   = {r2:.6f}"
        )


        prediction_df = pd.DataFrame({

            "battery_id":
                df["battery_id"],

            "cycle":
                df["cycle"],

            "Actual_RUL":
                y_rul,

            "Predicted_RUL":
                predictions
        })


        prediction_path = os.path.join(
            RESULTS_DIR,
            f"automated_RUL_{model_name}.csv"
        )


        try:

            prediction_df.to_csv(
                prediction_path,
                index=False
            )

        except PermissionError:

            prediction_path = os.path.join(
                RESULTS_DIR,
                f"automated_RUL_{model_name}_new.csv"
            )

            prediction_df.to_csv(
                prediction_path,
                index=False
            )


        print(
            "Predictions saved:",
            prediction_path
        )


    except Exception as e:

        print(
            f"ERROR testing {model_name}:"
        )

        print(
            str(e)
        )



# ============================================================
# RUL STACKING ENSEMBLE
# Base models: BaggingTree, HistGradientBoosting
# Meta-model: Ridge regression
# CNN-BiLSTM remains a separately evaluated sequence model.
# ============================================================

print("\n")
print("=" * 75)
print("RUL STACKING ENSEMBLE")
print("=" * 75)

rul_stack_specs = [
    ("BaggingTree", "rul_BaggingTree.joblib"),
    ("HistGradientBoosting", "rul_HistGradientBoosting.joblib"),
]

try:
    rul_estimators = []
    for estimator_name, filename in rul_stack_specs:
        model_path = os.path.join(MODELS_DIR, filename)
        if not os.path.exists(model_path):
            raise FileNotFoundError(
                f"Required RUL stacking base model is missing: {model_path}\n"
                "Run the model-training option in main.py first."
            )
        rul_estimators.append(
            (estimator_name.lower(), clone(joblib.load(model_path)))
        )

    rul_stack = StackingRegressor(
        estimators=rul_estimators,
        final_estimator=Ridge(alpha=1.0),
        cv=5,
        n_jobs=-1,
        passthrough=False,
    )
    rul_stack.fit(X_rul, y_rul)
    rul_stack_predictions = np.asarray(rul_stack.predict(X_rul)).reshape(-1)
    mae, rmse, r2 = calculate_metrics(y_rul, rul_stack_predictions)

    rul_results.append({
        "Task": "RUL",
        "Model": "Stacking Ensemble (Bagging + HistGradientBoosting)",
        "MAE": mae,
        "RMSE": rmse,
        "R2": r2,
        "Samples": len(rul_stack_predictions),
    })

    print(f"MAE  = {mae:.6f}")
    print(f"RMSE = {rmse:.6f}")
    print(f"R²   = {r2:.6f}")

    prediction_df = pd.DataFrame({
        "battery_id": df["battery_id"],
        "cycle": df["cycle"],
        "Actual_RUL": y_rul,
        "Predicted_RUL_Stacking": rul_stack_predictions,
    })
    prediction_path = os.path.join(
        RESULTS_DIR, "automated_RUL_Stacking_Ensemble.csv"
    )
    try:
        prediction_df.to_csv(prediction_path, index=False)
    except PermissionError:
        prediction_path = os.path.join(
            RESULTS_DIR, "automated_RUL_Stacking_Ensemble_new.csv"
        )
        prediction_df.to_csv(prediction_path, index=False)
    print("Stacking predictions saved:", prediction_path)

    # Save the fitted ensemble for later inference.
    stack_model_path = os.path.join(MODELS_DIR, "rul_Stacking_Ensemble.joblib")
    joblib.dump(rul_stack, stack_model_path)
    print("Fitted stacking model saved:", stack_model_path)

except Exception as e:
    print("RUL stacking ensemble could not be evaluated:")
    print(str(e))


# ============================================================
# ============================================================
# CREATE CNN-BiLSTM SEQUENCES
# ============================================================
# ============================================================

print("\n")
print("=" * 75)
print("CREATING CNN-BiLSTM RUL SEQUENCES")
print("=" * 75)


def create_sequences(
    dataframe,
    features,
    target,
    sequence_length
):

    X_sequences = []

    y_sequences = []

    battery_ids = []

    cycles = []


    for battery_id, battery_df in (
        dataframe.groupby(
            "battery_id"
        )
    ):

        battery_df = battery_df.sort_values(
            "cycle"
        ).reset_index(
            drop=True
        )


        X = battery_df[
            features
        ].values.astype(
            np.float32
        )

        y = battery_df[
            target
        ].values.astype(
            np.float32
        )


        if len(battery_df) < sequence_length:

            continue


        for i in range(
            sequence_length - 1,
            len(battery_df)
        ):

            sequence = X[
                i - sequence_length + 1:
                i + 1
            ]


            X_sequences.append(
                sequence
            )

            y_sequences.append(
                y[i]
            )

            battery_ids.append(
                battery_id
            )

            cycles.append(
                battery_df.loc[
                    i,
                    "cycle"
                ]
            )


    return (

        np.asarray(
            X_sequences,
            dtype=np.float32
        ),

        np.asarray(
            y_sequences,
            dtype=np.float32
        ),

        np.asarray(
            battery_ids
        ),

        np.asarray(
            cycles
        )
    )


(
    X_rul_seq,
    y_rul_seq,
    seq_battery_ids,
    seq_cycles
) = create_sequences(

    df,

    FEATURES,

    "rul",

    SEQUENCE_LENGTH
)


print(
    "Sequence shape:",
    X_rul_seq.shape
)

print(
    "Target shape:",
    y_rul_seq.shape
)

print(
    "Number of sequences:",
    len(
        X_rul_seq
    )
)


# ============================================================
# ============================================================
# CNN-BiLSTM TEST
# ============================================================
# ============================================================

print("\n")
print("=" * 75)
print("CNN-BiLSTM RUL TEST")
print("=" * 75)


cnn_model_path = os.path.join(
    MODELS_DIR,
    "rul_CNN_BiLSTM.keras"
)

cnn_scaler_path = os.path.join(
    MODELS_DIR,
    "rul_CNN_BiLSTM_scaler.joblib"
)


if (
    not os.path.exists(
        cnn_model_path
    )
    or
    not os.path.exists(
        cnn_scaler_path
    )
):

    print(
        "\nCNN-BiLSTM model/scaler not found."
    )

    print(
        "Expected:"
    )

    print(
        cnn_model_path
    )

    print(
        cnn_scaler_path
    )

else:

    try:

        print(
            "\nLoading CNN-BiLSTM..."
        )


        cnn_model = load_model(
            cnn_model_path
        )


        cnn_scaler = joblib.load(
            cnn_scaler_path
        )


        print(
            "CNN-BiLSTM loaded successfully."
        )


        # ----------------------------------------------------
        # SCALE SEQUENCES
        # ----------------------------------------------------

        n_features = (
            X_rul_seq.shape[2]
        )


        X_rul_seq_scaled = (
            cnn_scaler.transform(

                X_rul_seq.reshape(
                    -1,
                    n_features
                )
            )
            .reshape(
                X_rul_seq.shape
            )
        )


        print(
            "Scaled sequence shape:",
            X_rul_seq_scaled.shape
        )


        # ----------------------------------------------------
        # PREDICT
        # ----------------------------------------------------

        cnn_predictions = (
            cnn_model.predict(

                X_rul_seq_scaled,

                verbose=0
            )
            .reshape(-1)
        )


        # ----------------------------------------------------
        # METRICS
        # ----------------------------------------------------

        mae, rmse, r2 = calculate_metrics(

            y_rul_seq,

            cnn_predictions
        )


        rul_results.append({

            "Task": "RUL",

            "Model": "CNN-BiLSTM",

            "MAE": mae,

            "RMSE": rmse,

            "R2": r2,

            "Samples": len(
                cnn_predictions
            )
        })


        print("\nCNN-BiLSTM RESULTS")

        print(
            f"MAE  = {mae:.6f}"
        )

        print(
            f"RMSE = {rmse:.6f}"
        )

        print(
            f"R²   = {r2:.6f}"
        )


        # ----------------------------------------------------
        # CHECK NEGATIVE RUL
        # ----------------------------------------------------

        negative_count = np.sum(
            cnn_predictions < 0
        )


        print(
            "\nNegative predictions:",
            negative_count
        )


        if negative_count > 0:

            print(
                "Note: negative RUL values "
                "are possible from unconstrained regression."
            )


        # ----------------------------------------------------
        # SAVE CNN PREDICTIONS
        # ----------------------------------------------------

        cnn_prediction_df = pd.DataFrame({

            "battery_id":
                seq_battery_ids,

            "cycle":
                seq_cycles,

            "Actual_RUL":
                y_rul_seq,

            "Predicted_RUL":
                cnn_predictions
        })


        cnn_prediction_path = os.path.join(
            RESULTS_DIR,
            "automated_RUL_CNN_BiLSTM.csv"
        )


        try:

            cnn_prediction_df.to_csv(
                cnn_prediction_path,
                index=False
            )

        except PermissionError:

            cnn_prediction_path = os.path.join(
                RESULTS_DIR,
                "automated_RUL_CNN_BiLSTM_new.csv"
            )

            cnn_prediction_df.to_csv(
                cnn_prediction_path,
                index=False
            )


        print(
            "CNN-BiLSTM predictions saved:",
            cnn_prediction_path
        )


    except Exception as e:

        print(
            "\nERROR testing CNN-BiLSTM:"
        )

        print(
            str(e)
        )


# ============================================================
# RUL SUMMARY
# ============================================================

rul_results_df = pd.DataFrame(
    rul_results
)


print("\n")
print("=" * 75)
print("FINAL RUL MODEL TEST SUMMARY")
print("=" * 75)


if len(rul_results_df) > 0:

    print(
        rul_results_df[
            [
                "Model",
                "MAE",
                "RMSE",
                "R2"
            ]
        ].to_string(
            index=False
        )
    )


# ============================================================
# COMBINED RESULTS
# ============================================================

all_results = pd.concat(

    [
        soh_results_df,
        rul_results_df
    ],

    ignore_index=True
)


summary_path = os.path.join(
    RESULTS_DIR,
    "automated_model_test_summary.csv"
)


try:

    all_results.to_csv(
        summary_path,
        index=False
    )

except PermissionError:

    summary_path = os.path.join(
        RESULTS_DIR,
        "automated_model_test_summary_new.csv"
    )

    all_results.to_csv(
        summary_path,
        index=False
    )


print("\n")
print(
    "Combined summary saved:"
)

print(
    summary_path
)


# ============================================================
# FINAL OUTPUT
# ============================================================

print("\n")
print("=" * 75)
print("AUTOMATED TEST COMPLETED")
print("=" * 75)


print("\nSOH RESULTS:")

if len(soh_results_df) > 0:

    print(
        soh_results_df[
            [
                "Model",
                "MAE",
                "RMSE",
                "R2"
            ]
        ].to_string(
            index=False
        )
    )


print("\nRUL RESULTS:")

if len(rul_results_df) > 0:

    print(
        rul_results_df[
            [
                "Model",
                "MAE",
                "RMSE",
                "R2"
            ]
        ].to_string(
            index=False
        )
    )


print("\n")
print("=" * 75)
print("IMPORTANT")
print("=" * 75)

print(
    """
These results are dataset-wide/in-sample verification
results because the final saved models were trained using
the complete dataset.

For scientific model selection, use the battery-wise
5-fold GroupKFold results produced by:

    python src/models.py

Do NOT use the in-sample result alone to claim that a model
generalizes better than another model.
"""
)


print("=" * 75)
print("DONE")
print("=" * 75)