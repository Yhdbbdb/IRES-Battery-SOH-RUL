"""Visualize the battery-wise 5-fold split used in src/models.py.

Run from the project root:
    python visualize_folds.py

The chart and CSV are saved under results/.
"""

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import GroupKFold

from config import DATASET_CSV, FEATURES, RESULTS_DIR


def main() -> None:
    dataset_path = Path(DATASET_CSV)
    if not dataset_path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {dataset_path}\n"
            "Check DATASET_CSV in config.py and run dataset preparation first."
        )

    df = pd.read_csv(dataset_path)
    required = {"battery_id", "soh", "rul", *FEATURES}
    missing = sorted(required.difference(df.columns))
    if missing:
        raise ValueError("Dataset is missing required columns: " + ", ".join(missing))

    # Mirror the eligible rows used by models.py for SOH and RUL.
    df["battery_id"] = df["battery_id"].astype(str)
    soh = df.dropna(subset=["soh", *FEATURES]).copy()
    rul = df.dropna(subset=["rul", *FEATURES]).copy()
    rul = rul[pd.to_numeric(rul["rul"], errors="coerce") >= 0]

    tasks = {"SOH": soh, "RUL": rul}
    fold_rows = []

    for task_name, task_df in tasks.items():
        battery_ids = task_df["battery_id"].to_numpy()
        unique_batteries = sorted(set(battery_ids))
        if len(unique_batteries) < 5:
            raise ValueError(
                f"{task_name} has only {len(unique_batteries)} distinct batteries; "
                "GroupKFold with 5 folds requires at least 5."
            )

        splitter = GroupKFold(n_splits=5)
        # X/y values do not affect GroupKFold assignment; groups do.
        for fold_num, (train_idx, val_idx) in enumerate(
            splitter.split(task_df, groups=battery_ids), start=1
        ):
            train_groups = sorted(set(battery_ids[train_idx]))
            val_groups = sorted(set(battery_ids[val_idx]))
            train_rows = len(train_idx)
            val_rows = len(val_idx)

            print(f"\n{task_name} — Fold {fold_num}/5")
            print(f"  Train: {train_rows} rows, {len(train_groups)} batteries")
            print("  Train battery IDs:", ", ".join(train_groups))
            print(f"  Validation: {val_rows} rows, {len(val_groups)} batteries")
            print("  Validation battery IDs:", ", ".join(val_groups))

            for split_name, indices, groups in (
                ("Train", train_idx, train_groups),
                ("Validation", val_idx, val_groups),
            ):
                for battery in groups:
                    rows_for_battery = int((battery_ids[indices] == battery).sum())
                    fold_rows.append(
                        {
                            "task": task_name,
                            "fold": fold_num,
                            "split": split_name,
                            "battery_id": battery,
                            "rows": rows_for_battery,
                        }
                    )

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    csv_path = Path(RESULTS_DIR) / "fold_assignments.csv"
    pd.DataFrame(fold_rows).to_csv(csv_path, index=False)

    # Show the actual role of every battery in every fold: train, validation,
    # or ineligible. This makes the 4-fold train / 1-fold validation rotation
    # explicit instead of showing only each battery's held-out fold number.
    from matplotlib.colors import ListedColormap
    import numpy as np

    assignments = (
        pd.DataFrame(fold_rows)
        .sort_values(["task", "battery_id", "fold"])
    )
    batteries = sorted(assignments["battery_id"].unique())
    tasks_order = ["SOH", "RUL"]
    # Code: 0=ineligible, 1=train, 2=validation. Ten columns: five per task.
    role_grid = np.zeros((len(batteries), 10), dtype=int)
    row_for_battery = {battery: i for i, battery in enumerate(batteries)}
    task_offset = {"SOH": 0, "RUL": 5}
    for item in fold_rows:
        row = row_for_battery[item["battery_id"]]
        col = task_offset[item["task"]] + item["fold"] - 1
        role_grid[row, col] = 2 if item["split"] == "Validation" else 1

    fig_height = max(6.0, 0.31 * len(batteries) + 2.4)
    fig, ax = plt.subplots(figsize=(16, fig_height))
    cmap = ListedColormap(["#E6E8EB", "#7BA7D1", "#E8833A"])
    ax.imshow(role_grid, cmap=cmap, vmin=0, vmax=2, aspect="auto")
    ax.set_yticks(range(len(batteries)), batteries)
    ax.set_xticks(range(10), [f"Fold {n}" for _ in tasks_order for n in range(1, 6)])
    ax.set_ylabel("Battery ID")
    ax.set_xlabel("Fold number within prediction target")
    ax.set_title("Train and validation batteries by fold", fontsize=14,
                 weight="bold", pad=12)
    ax.set_xticks([4.5], minor=True)
    ax.grid(which="minor", axis="x", color="#26384A", linewidth=2)
    ax.tick_params(which="minor", bottom=False)
    ax.set_xlim(-0.5, 9.5)
    ax.set_ylim(len(batteries) - 0.5, -0.5)
    # Labels inside cells make the distinction independent of color.
    for row in range(len(batteries)):
        for col in range(10):
            role = role_grid[row, col]
            label = "—" if role == 0 else ("TR" if role == 1 else "VAL")
            color = "#666666" if role == 0 else "white"
            ax.text(col, row, label, ha="center", va="center", fontsize=7.5,
                    color=color, weight="bold" if role else "normal")
    # Explicit group headers above each set of five fold columns.
    ax.text(2, 1.075, "SOH MODEL", transform=ax.get_xaxis_transform(), ha="center",
            va="bottom", fontsize=12, weight="bold", color="#26384A")
    ax.text(7, 1.075, "RUL MODEL", transform=ax.get_xaxis_transform(), ha="center",
            va="bottom", fontsize=12, weight="bold", color="#26384A")

    # Add per-fold counts so users can see the exact held-out set sizes.
    validation = pd.DataFrame(fold_rows).query("split == 'Validation'")
    count_table = validation.groupby(["task", "fold"]).agg(
        batteries=("battery_id", "nunique"), rows=("rows", "sum")
    )
    for task, offset in task_offset.items():
        for fold in range(1, 6):
            entry = count_table.loc[(task, fold)]
            ax.text(offset + fold - 1, -0.048,
                    f"Val: {int(entry.batteries)} batteries\n{int(entry.rows):,} rows",
                    transform=ax.get_xaxis_transform(), ha="center", va="top",
                    fontsize=7.5, color="#4D5966", clip_on=False)

    legend_items = [
        plt.Rectangle((0, 0), 1, 1, color="#7BA7D1", label="Train: included in model fitting"),
        plt.Rectangle((0, 0), 1, 1, color="#E8833A", label="Validation: held out for this fold"),
        plt.Rectangle((0, 0), 1, 1, color="#E6E8EB", label="—: no eligible rows for this target"),
    ]
    fig.legend(handles=legend_items, loc="lower center", ncol=3, frameon=False,
               bbox_to_anchor=(0.5, 0.005), fontsize=9)
    fig.suptitle("Battery-wise 5-fold cross-validation", fontsize=17, weight="bold", y=0.985)
    fig.text(0.5, 0.955,
             "Each fold trains on four groups and validates on the remaining group; "
             "battery cycles never cross between train and validation.",
             ha="center", fontsize=10, color="#4D5966")
    fig.subplots_adjust(left=0.08, right=0.98, top=0.87, bottom=0.22)

    plot_path = Path(RESULTS_DIR) / "fold_assignments.png"
    fig.savefig(plot_path, dpi=220, bbox_inches="tight", facecolor="white")
    print(f"\nSaved fold table: {csv_path}")
    print(f"Saved visualization: {plot_path}")
    plt.show()


if __name__ == "__main__":
    main()
