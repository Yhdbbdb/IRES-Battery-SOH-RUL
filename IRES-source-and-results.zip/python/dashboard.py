"""
dashboard.py
============================================================
HYBRID BATTERY SOH / RUL PREDICTION SYSTEM

Architecture:

Arduino UNO
    ↓
Serial Telemetry
    ↓
Real-Time Dashboard  ← ALWAYS works independently
    ↓
Predictor
    ↓
Complete discharge cycle
    ↓
SOH / RUL ML prediction

Serial packet accepted:

    4.036,4.030,8.066,-0.435,31.40

or:

    DATA,4.036,4.030,8.066,-0.435,31.40

Battery:
    2S
    4300 mAh per cell
    4300 mAh pack capacity for a 2S series pack

Current convention:
    Battery mode is determined from pack-voltage trend, not current.
    Rising pack voltage -> CHARGING
    Falling pack voltage -> DISCHARGING
    Stable pack voltage -> IDLE
============================================================
"""

import time
import traceback

import pandas as pd
import streamlit as st


# ============================================================
# PAGE CONFIG
# ============================================================

st.set_page_config(
    page_title="Hybrid Battery SOH / RUL",
    page_icon="🔋",
    layout="wide",
    initial_sidebar_state="expanded",
)


# ============================================================
# CONFIG
# ============================================================

try:
    from config import (
        SERIAL_PORT,
        SERIAL_BAUD,
        EOL_SOH,
        REALTIME_ROLLING_WINDOW,
    )
except Exception:
    SERIAL_PORT = "COM8"
    SERIAL_BAUD = 115200
    EOL_SOH = 80.0
    REALTIME_ROLLING_WINDOW = 100


# ============================================================
# ARDUINO IMPORT
# ============================================================

ARDUINO_IMPORT_ERROR = None

try:
    from src.arduino_serial import ArduinoReader
except Exception as exc:
    try:
        from arduino_serial import ArduinoReader
    except Exception as exc2:
        ArduinoReader = None
        ARDUINO_IMPORT_ERROR = (
            f"{type(exc).__name__}: {exc}\n"
            f"Fallback import also failed: "
            f"{type(exc2).__name__}: {exc2}"
        )


# ============================================================
# PREDICTOR IMPORT
# ============================================================

PREDICTOR_IMPORT_ERROR = None

try:
    from src.realtime_prediction import Predictor
except Exception as exc:
    try:
        from realtime_prediction import Predictor
    except Exception as exc2:
        Predictor = None
        PREDICTOR_IMPORT_ERROR = (
            f"{type(exc).__name__}: {exc}\n"
            f"Fallback import also failed: "
            f"{type(exc2).__name__}: {exc2}"
        )


# ============================================================
# SESSION STATE
# ============================================================

DEFAULTS = {
    "arduino_reader": None,
    "predictor": None,
    "monitoring": False,

    "latest_telemetry": None,
    "latest_result": None,
    "previous_pack_voltage": None,

    "history": [],

    "telemetry_count": 0,
    "ml_update_count": 0,

    "last_error": None,
    "last_ml_error": None,

    "cycle_number": 0,
    "voltage_cycle_stage": "WAITING_FOR_CHARGE_PEAK",
    "voltage_cycle_count": 0,
    "voltage_cycle_low_v": 6.80,
    "voltage_cycle_high_v": 8.15,
    "soc": None,
    "soh": None,
    "rul": None,
    "health_status": "Waiting",
}

for key, value in DEFAULTS.items():
    if key not in st.session_state:
        st.session_state[key] = value


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def disconnect_reader():
    """Safely disconnect Arduino."""

    reader = st.session_state.get("arduino_reader")

    if reader is not None:
        try:
            reader.disconnect()
        except Exception:
            pass

    st.session_state.arduino_reader = None


def reset_system():
    """Reset dashboard state."""

    disconnect_reader()

    st.session_state.predictor = None
    st.session_state.monitoring = False

    st.session_state.latest_telemetry = None
    st.session_state.latest_result = None
    st.session_state.previous_pack_voltage = None
    st.session_state.history = []

    st.session_state.telemetry_count = 0
    st.session_state.ml_update_count = 0

    st.session_state.last_error = None
    st.session_state.last_ml_error = None

    st.session_state.cycle_number = 0
    st.session_state.voltage_cycle_stage = "WAITING_FOR_CHARGE_PEAK"
    st.session_state.voltage_cycle_count = 0
    st.session_state.soc = None
    st.session_state.soh = None
    st.session_state.rul = None
    st.session_state.health_status = "Waiting"


def safe_float(value, default=None):
    try:
        return float(value)
    except Exception:
        return default


def value_or_dash(value, suffix="", decimals=2):
    if value is None:
        return "--"

    try:
        return f"{float(value):.{decimals}f}{suffix}"
    except Exception:
        return "--"


def current_mode(sample):
    """Determine operating mode from consecutive pack-voltage readings.

    A rise means charging, a fall means discharging, and a small change
    means idle. This is a voltage-trend estimate, not a definitive charge
    detector: load changes and voltage noise can affect the result.
    """
    pack = safe_float(sample.get("pack_voltage"))
    if pack is None:
        return "UNKNOWN"

    previous_pack = st.session_state.get("previous_pack_voltage")
    st.session_state.previous_pack_voltage = pack

    if previous_pack is None:
        return "WAITING"

    voltage_change = pack - previous_pack
    threshold = 0.005  # 5 mV; increase if readings are noisy

    if voltage_change > threshold:
        return "CHARGING"
    if voltage_change < -threshold:
        return "DISCHARGING"
    return "IDLE"


def update_voltage_cycle_detector(pack_voltage):
    """Count a complete simulated voltage cycle using pack-voltage limits.

    A cycle is counted only after voltage reaches the charge peak and then
    falls to the lower threshold. This is a simulator/demo cycle counter,
    not a validated capacity-based cycle counter for a real battery.
    For the simulator's approximate 2S range, defaults are 8.15 V high and
    6.80 V low. Adjust these in the sidebar for a different simulator range.
    """
    pack = safe_float(pack_voltage)
    if pack is None:
        return st.session_state.voltage_cycle_count

    high_v = safe_float(st.session_state.get("voltage_cycle_high_v"), 8.15)
    low_v = safe_float(st.session_state.get("voltage_cycle_low_v"), 6.80)
    stage = st.session_state.get("voltage_cycle_stage", "WAITING_FOR_CHARGE_PEAK")

    if stage == "WAITING_FOR_CHARGE_PEAK" and pack >= high_v:
        st.session_state.voltage_cycle_stage = "WAITING_FOR_DISCHARGE_LOW"
    elif stage == "WAITING_FOR_DISCHARGE_LOW" and pack <= low_v:
        st.session_state.voltage_cycle_count += 1
        st.session_state.voltage_cycle_stage = "WAITING_FOR_CHARGE_PEAK"

    return st.session_state.voltage_cycle_count


def make_raw_telemetry(sample):
    """Convert ArduinoReader output into a clean dashboard record."""

    cell1 = safe_float(sample.get("cell1_voltage"), 0.0)
    cell2 = safe_float(sample.get("cell2_voltage"), 0.0)
    # No pack-voltage sensor is installed. Reconstruct pack voltage
    # from the two individual cell-voltage sensors.
    pack = cell1 + cell2
    current = safe_float(sample.get("current"), 0.0)
    temperature = safe_float(sample.get("temperature"), 0.0)
    ambient_temperature = safe_float(sample.get("ambient_temperature"))
    humidity = safe_float(sample.get("humidity"))

    # With no LM35, use DHT11 ambient temperature when available.
    if ambient_temperature is not None:
        temperature = ambient_temperature

    imbalance = abs(cell1 - cell2)

    power = pack * abs(current)

    return {
        "timestamp": sample.get("timestamp", time.time()),

        "cell1_voltage": cell1,
        "cell2_voltage": cell2,
        "pack_voltage": pack,
        "current": current,
        "temperature": temperature,
        "ambient_temperature": ambient_temperature,
        "humidity": humidity,

        # Ignore serial-reader current-based mode; use voltage trend.
        "battery_mode": current_mode({"pack_voltage": pack}),

        "cell_imbalance": safe_float(
            sample.get("cell_imbalance"),
            imbalance,
        ),

        "power_w": safe_float(
            sample.get("power_w"),
            power,
        ),

        # SIMULATION-FRIENDLY SOC ESTIMATE:
        # Maps per-cell voltage 3.30 V -> 0% and 4.15 V -> 100%.
        # This is only an approximate display estimate, not a validated
        # electrochemical SOC estimator for real Li-ion cells.
        "soc": max(0.0, min(100.0, (
            (((cell1 - 3.30) / (4.15 - 3.30) * 100.0) +
             ((cell2 - 3.30) / (4.15 - 3.30) * 100.0)) / 2.0
        ))),
    }


def merge_prediction(raw, result):
    """
    Combine raw Arduino telemetry with predictor output.

    Raw sensor values always remain available even if
    predictor output is incomplete.
    """

    combined = dict(raw)

    if isinstance(result, dict):
        combined.update(result)

    # The dashboard mode must remain based on pack-voltage trend.
    combined["battery_mode"] = raw.get("battery_mode", "UNKNOWN")

    # Use voltage-derived SOC for the synthetic UNO simulator so SOC does
    # not remain at a stale/invalid 0.0 from an unrelated ML model output.
    # Replace this with a validated estimator for real battery use.
    combined["soc"] = raw.get("soc")

    return combined


# ============================================================
# SIDEBAR
# ============================================================

st.sidebar.title("⚙️ System Control")

port = st.sidebar.text_input(
    "Arduino COM Port",
    value=str(SERIAL_PORT),
)

baud = st.sidebar.number_input(
    "Baud Rate",
    min_value=9600,
    max_value=250000,
    value=int(SERIAL_BAUD),
    step=100,
)

st.sidebar.divider()

start = st.sidebar.button(
    "▶ Start Monitoring",
    use_container_width=True,
)

stop = st.sidebar.button(
    "⏹ Stop Monitoring",
    use_container_width=True,
)

reset = st.sidebar.button(
    "🔄 Reset",
    use_container_width=True,
)

st.sidebar.divider()

st.sidebar.subheader("System Information")

st.sidebar.write("Battery configuration: 2S")
st.sidebar.write("Cell capacity: 4300 mAh")
st.sidebar.write("Pack capacity: 4300 mAh")
st.sidebar.caption("Simulator voltage-cycle thresholds (pack voltage)")
st.session_state.voltage_cycle_low_v = st.sidebar.number_input("Cycle low threshold (V)", min_value=5.0, max_value=8.0, value=float(st.session_state.voltage_cycle_low_v), step=0.05)
st.session_state.voltage_cycle_high_v = st.sidebar.number_input("Cycle high threshold (V)", min_value=7.0, max_value=9.0, value=float(st.session_state.voltage_cycle_high_v), step=0.05)
st.sidebar.write("EOL SOH: 80%")
st.sidebar.write(f"Serial: {port}")
st.sidebar.write(f"Baud: {int(baud)}")


# ============================================================
# RESET BUTTON
# ============================================================

if reset:

    reset_system()

    st.rerun()


# ============================================================
# START MONITORING
# ============================================================

if start:

    # Reset only runtime telemetry/prediction state.
    disconnect_reader()

    st.session_state.predictor = None
    st.session_state.history = []

    st.session_state.latest_telemetry = None
    st.session_state.latest_result = None
    st.session_state.previous_pack_voltage = None
    st.session_state.voltage_cycle_stage = "WAITING_FOR_CHARGE_PEAK"
    st.session_state.voltage_cycle_count = 0

    st.session_state.telemetry_count = 0
    st.session_state.ml_update_count = 0

    st.session_state.last_error = None
    st.session_state.last_ml_error = None

    # --------------------------------------------------------
    # Arduino is REQUIRED for real-time monitoring.
    # Predictor is OPTIONAL.
    # --------------------------------------------------------

    try:

        if ArduinoReader is None:
            raise RuntimeError(
                "ArduinoReader could not be imported.\n\n"
                + str(ARDUINO_IMPORT_ERROR)
            )

        reader = ArduinoReader(
            port=str(port).strip(),
            baudrate=int(baud),
            timeout=0.25,
        )

        reader.connect()

        st.session_state.arduino_reader = reader
        st.session_state.monitoring = True

    except Exception as exc:

        st.session_state.monitoring = False

        st.session_state.last_error = (
            f"Arduino connection error: "
            f"{type(exc).__name__}: {exc}"
        )

    # --------------------------------------------------------
    # Predictor is OPTIONAL.
    # If it fails, telemetry still works.
    # --------------------------------------------------------

    if st.session_state.monitoring:

        if Predictor is not None:

            try:

                st.session_state.predictor = Predictor()

            except Exception as exc:

                st.session_state.predictor = None

                st.session_state.last_ml_error = (
                    f"Predictor initialization warning: "
                    f"{type(exc).__name__}: {exc}"
                )

        else:

            st.session_state.last_ml_error = (
                "Predictor unavailable. "
                "Real-time Arduino telemetry will continue."
            )


# ============================================================
# STOP MONITORING
# ============================================================

if stop:

    disconnect_reader()

    st.session_state.monitoring = False


# ============================================================
# REAL-TIME ARDUINO READING
# ============================================================

if st.session_state.monitoring:

    reader = st.session_state.arduino_reader
    predictor = st.session_state.predictor

    try:

        # ----------------------------------------------------
        # READ ONE SERIAL SAMPLE
        # ----------------------------------------------------

        sample = reader.read_sample(
            max_attempts=1
        )

        # ----------------------------------------------------
        # VALID ARDUINO DATA RECEIVED
        # ----------------------------------------------------

        if sample is not None:

            raw = make_raw_telemetry(sample)
            detected_cycles = update_voltage_cycle_detector(raw.get("pack_voltage"))
            raw["voltage_cycle_count"] = detected_cycles
            raw["voltage_cycle_stage"] = st.session_state.voltage_cycle_stage

            # =================================================
            # IMPORTANT:
            # SAVE RAW TELEMETRY FIRST.
            # ML CAN NEVER BLOCK LIVE SENSOR DISPLAY.
            # =================================================

            st.session_state.latest_telemetry = raw
            st.session_state.soc = raw.get("soc")

            st.session_state.telemetry_count += 1

            # =================================================
            # PREDICTOR
            # =================================================

            if predictor is not None:

                try:

                    result = predictor.update(sample)

                    if result is not None:

                        combined = merge_prediction(
                            raw,
                            result,
                        )

                        st.session_state.latest_result = (
                            combined
                        )

                        st.session_state.history.append(
                            combined
                        )

                        # Keep memory reasonable.
                        st.session_state.history = (
                            st.session_state.history[-1000:]
                        )

                        st.session_state.ml_update_count += 1

                        # -------------------------------------
                        # Save known ML state
                        # -------------------------------------

                        if result.get("soc") is not None:
                            st.session_state.soc = (
                                safe_float(result.get("soc"))
                            )

                        if result.get("soh") is not None:
                            st.session_state.soh = (
                                safe_float(result.get("soh"))
                            )

                        if result.get("rul") is not None:
                            st.session_state.rul = (
                                safe_float(result.get("rul"))
                            )

                        if result.get("cycle_number") is not None:
                            try:
                                st.session_state.cycle_number = int(
                                    result.get("cycle_number")
                                )
                            except Exception:
                                pass

                        if result.get("health_status") is not None:
                            st.session_state.health_status = (
                                result.get("health_status")
                            )

                except Exception as exc:

                    # -----------------------------------------
                    # ML ERROR ONLY
                    # DO NOT STOP ARDUINO
                    # -----------------------------------------

                    st.session_state.last_ml_error = (
                        f"ML warning: "
                        f"{type(exc).__name__}: {exc}"
                    )

            # Clear old Arduino error after valid packet.
            st.session_state.last_error = None

    except Exception as exc:

        # ----------------------------------------------------
        # Arduino error
        # ----------------------------------------------------

        st.session_state.last_error = (
            f"Arduino error: "
            f"{type(exc).__name__}: {exc}"
        )

        # Do not immediately destroy the reader.
        # The next Streamlit refresh will try again.


# ============================================================
# LATEST DATA
# ============================================================

raw = st.session_state.latest_telemetry
ml = st.session_state.latest_result

if ml is not None:
    latest = ml
else:
    latest = raw

history = st.session_state.history


# ============================================================
# TITLE
# ============================================================

st.markdown(
    """
    <h1>🔋 Hybrid Battery SOH / RUL Prediction System</h1>
    """,
    unsafe_allow_html=True,
)

st.caption(
    "Arduino → Real-Time Telemetry → Battery Mode → "
    "Discharge Cycle → 15 Features → SOH / RUL ML"
)


# ============================================================
# STATUS
# ============================================================

st.subheader("System Status")

s1, s2, s3, s4 = st.columns(4)


with s1:

    if st.session_state.monitoring:

        st.success("🟢 Arduino Connected")

    else:

        st.error("🔴 Arduino Offline")


with s2:

    mode = "WAITING"

    if latest is not None:
        mode = latest.get(
            "battery_mode",
            "UNKNOWN",
        )

    st.metric(
        "Battery Mode",
        mode,
    )


with s3:

    cycle = max(
        int(st.session_state.cycle_number or 0),
        int(st.session_state.voltage_cycle_count or 0),
    )

    if latest is not None:
        try:
            model_cycle = int(latest.get("cycle_number", 0) or 0)
            cycle = max(cycle, model_cycle)
        except Exception:
            pass

    st.metric(
        "Discharge Cycle",
        cycle,
    )


with s4:

    st.metric(
        "ML Updates",
        st.session_state.ml_update_count,
    )


# ============================================================
# LIVE TELEMETRY
# ============================================================

st.subheader("🔌 Live Battery Telemetry")

if latest is not None:

    c1, c2, c3, c4, c5, c6 = st.columns(6)

    with c1:

        st.metric(
            "Cell 1",
            value_or_dash(
                latest.get("cell1_voltage"),
                " V",
                3,
            ),
        )

    with c2:

        st.metric(
            "Cell 2",
            value_or_dash(
                latest.get("cell2_voltage"),
                " V",
                3,
            ),
        )

    with c3:

        st.metric(
            "Pack",
            value_or_dash(
                latest.get("pack_voltage"),
                " V",
                3,
            ),
        )

    with c4:

        st.metric(
            "Current",
            value_or_dash(
                latest.get("current"),
                " A",
                3,
            ),
        )

    with c5:

        st.metric(
            "Temperature",
            value_or_dash(
                latest.get("temperature"),
                " °C",
                2,
            ),
        )

    with c6:

        st.metric(
            "Humidity",
            value_or_dash(latest.get("humidity"), " %", 1),
        )

    c6, c7, c8 = st.columns(3)

    with c6:

        st.metric(
            "Power",
            value_or_dash(
                latest.get("power_w"),
                " W",
                2,
            ),
        )

    with c7:

        st.metric(
            "Cell Imbalance",
            value_or_dash(
                (
                    safe_float(
                        latest.get(
                            "cell_imbalance"
                        ),
                        0.0,
                    )
                    * 1000.0
                ),
                " mV",
                1,
            ),
        )

    with c8:

        st.metric(
            "Mode",
            latest.get(
                "battery_mode",
                "UNKNOWN",
            ),
        )

else:

    st.info(
        "Waiting for Arduino measurements..."
    )


st.caption(
    "Real-time Arduino samples received: "
    f"{st.session_state.telemetry_count}"
)


# ============================================================
# BATTERY STATE
# ============================================================

st.subheader("🔋 Battery State")

b1, b2, b3, b4 = st.columns(4)


# ------------------------------------------------------------
# SOC
# ------------------------------------------------------------

with b2:

    soc = st.session_state.soc

    if latest is not None and latest.get("soc") is not None:
        soc = safe_float(latest.get("soc"), soc)

    if soc is not None:
        st.metric("SOC", f"{soc:.1f}%")
    else:
        st.metric("SOC", "--")


# ------------------------------------------------------------
# SOH
# ------------------------------------------------------------

with b3:

    soh = st.session_state.soh

    if latest is not None and latest.get("soh") is not None:
        soh = safe_float(latest.get("soh"), soh)

    if soh is not None:
        st.metric("SOH", f"{soh:.2f}%")
    else:
        st.metric("SOH", "--")


# ------------------------------------------------------------
# RUL — SHOW FIRST IN BATTERY STATE
# ------------------------------------------------------------

with b1:

    rul = st.session_state.rul

    if latest is not None and latest.get("rul") is not None:
        rul = safe_float(latest.get("rul"), rul)

    if rul is not None:
        st.metric("Estimated RUL", f"{rul:.1f} cycles")
    else:
        st.metric("Estimated RUL", "Collecting cycles")

    st.caption("Sequence model uses 20 cycle samples.")


# ------------------------------------------------------------
# HEALTH
# ------------------------------------------------------------

with b4:

    health = st.session_state.health_status

    if latest is not None:

        health = latest.get(
            "health_status",
            health,
        )

    if health is None:
        health = "Telemetry Active"

    st.metric(
        "Health",
        health,
    )


# Explain the RUL model's required sequence length.
# The configured CNN-BiLSTM sequence length is 20 cycles; this is a
# minimum history requirement, not a guarantee of accuracy.
completed_cycles = safe_float(st.session_state.cycle_number, 0) or 0
detected_cycles = int(st.session_state.voltage_cycle_count or 0)
if detected_cycles < 20:
    st.info(
        f"Simulator voltage-cycle progress: {min(detected_cycles, 20)}/20 cycles detected. "
        "A demo cycle is counted when pack voltage reaches the high threshold and later falls to the low threshold. "
        "This display counter does not automatically create the Predictor's 20 labelled cycle-feature samples. "
        "SOH/RUL remain unavailable until the ML predictor produces a valid result."
    )
else:
    st.caption(
        "20 simulator voltage cycles detected. This alone does not guarantee a valid RUL prediction; "
        "the ML model still needs its expected cycle-feature sequence and representative labelled training data."
    )


# ============================================================
# CYCLE INFORMATION
# ============================================================

st.subheader("🔄 Cycle Information")

q1, q2, q3, q4 = st.columns(4)

with q1:

    st.metric(
        "Cycle Number",
        st.session_state.cycle_number,
    )

with q2:

    progress = None

    if latest is not None:
        progress = latest.get(
            "cycle_progress"
        )

    st.metric(
        "Cycle Progress",
        value_or_dash(
            progress,
            "%",
            1,
        ),
    )

with q3:

    discharged = None

    if latest is not None:
        discharged = latest.get(
            "discharged_capacity_mah"
        )

    st.metric(
        "Discharged Capacity",
        value_or_dash(
            discharged,
            " mAh",
            1,
        ),
    )

with q4:

    remaining = None

    if latest is not None:
        remaining = latest.get(
            "remaining_capacity_mah"
        )

    st.metric(
        "Remaining Capacity",
        value_or_dash(
            remaining,
            " mAh",
            1,
        ),
    )


# ============================================================
# ML STATUS
# ============================================================

st.subheader("🤖 Machine Learning Status")

if st.session_state.last_ml_error:

    st.warning(
        st.session_state.last_ml_error
    )

elif st.session_state.predictor is None:

    st.info(
        "ML predictor is not available. "
        "Arduino real-time telemetry is still active."
    )

else:

    st.success(
        "ML predictor connected. "
        "SOH/RUL values appear when valid predictions "
        "are produced."
    )


# ============================================================
# ERROR STATUS
# ============================================================

if st.session_state.last_error:

    st.error(
        st.session_state.last_error
    )


# ============================================================
# RAW TELEMETRY TABLE
# ============================================================

with st.expander(
    "📋 Latest Telemetry Data"
):

    if history:

        columns = [
            "timestamp",
            "battery_mode",
            "cycle_number",
            "cycle_progress",
            "soc",
            "cell1_voltage",
            "cell2_voltage",
            "pack_voltage",
            "current",
            "temperature",
            "power_w",
            "cell_imbalance",
            "discharged_capacity_mah",
            "remaining_capacity_mah",
            "soh",
            "rul",
        ]

        available = [
            column
            for column in columns
            if column in history[-1]
        ]

        table = pd.DataFrame(
            history
        )[
            available
        ].tail(30)

        st.dataframe(
            table,
            use_container_width=True,
            hide_index=True,
        )

    elif raw is not None:

        st.dataframe(
            pd.DataFrame([raw]),
            use_container_width=True,
            hide_index=True,
        )

    else:

        st.info(
            "No telemetry received."
        )


# ============================================================
# SERIAL DEBUG
# ============================================================

with st.expander(
    "🔧 Serial Debug"
):

    reader = st.session_state.arduino_reader

    if reader is not None:

        try:

            info = reader.information()

            st.write(
                "Port:",
                info.get("port"),
            )

            st.write(
                "Baud:",
                info.get("baudrate"),
            )

            st.write(
                "Connected:",
                info.get("connected"),
            )

            st.write(
                "Samples received:",
                info.get("samples_received"),
            )

            st.write(
                "Last raw line:",
                info.get("last_raw_line"),
            )

            st.write(
                "Last error:",
                info.get("last_error"),
            )

        except Exception as exc:

            st.write(
                f"Debug error: {exc}"
            )

    else:

        st.info(
            "Arduino reader is not initialized."
        )


# ============================================================
# MODEL INFORMATION
# ============================================================

with st.expander(
    "🧠 Model Information"
):

    st.write(
        "SOH model: Random Forest"
    )

    st.write(
        "RUL model: CNN-BiLSTM"
    )

    st.write(
        "RUL sequence length: 20 cycles"
    )

    st.write(
        "Common feature count: 15"
    )

    st.write(
        "SOH EOL threshold:",
        f"{EOL_SOH:.1f}%",
    )

    st.write(
        "Real-time rolling window:",
        REALTIME_ROLLING_WINDOW,
    )


# ============================================================
# FOOTER
# ============================================================

st.divider()

st.caption(
    "Hybrid Battery SOH / RUL Prediction System | "
    "Arduino UNO → Python → ML"
)


# ============================================================
# AUTO REFRESH
# ============================================================
#
# The important point:
# Arduino telemetry is saved BEFORE ML is called.
#
# Therefore:
#
# Arduino working + ML working     -> telemetry + SOH/RUL
# Arduino working + ML unavailable -> telemetry only
#
# ============================================================

if st.session_state.monitoring:

    time.sleep(0.5)

    st.rerun()
