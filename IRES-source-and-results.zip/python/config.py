# ============================================================
# config.py
# CENTRAL CONFIGURATION
# Hybrid Battery SOH / RUL Prediction System
# ============================================================
#
# Keep all shared paths, battery settings, ML feature definitions,
# serial settings, and model artifact names in one place.
#
# Current ML architecture:
#   SOH -> RandomForest
#   RUL -> CNN-BiLSTM
#
# Battery:
#   2S Li-ion
#   Cell capacity = 1200 mAh
#   Pack capacity = 1200 mAh (series connection)
# ============================================================

from pathlib import Path
import os

# ============================================================
# 1. PROJECT PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

DATA_DIR = BASE_DIR / "data"
PROCESSED_DIR = DATA_DIR / "processed"
RAW_DIR = DATA_DIR / "raw"
REALTIME_DIR = DATA_DIR / "realtime"

MODEL_DIR = BASE_DIR / "models"
RESULTS_DIR = BASE_DIR / "results"
PLOTS_DIR = BASE_DIR / "plots"
REPORTS_DIR = BASE_DIR / "reports"
LOGS_DIR = BASE_DIR / "training_log"

# ============================================================
# 2. DATASET PATHS
# ============================================================

NASA_DIR = Path(
    os.environ.get(
        "NASA_DATA_PATH",
        r"C:\Users\nithi\Documents\IRES\5.+Battery+Data+Set\5. Battery Data Set\all",
    )
)

NH_DIR = Path(
    os.environ.get(
        "NH_ECYCLE_PATH",
        r"C:\Users\nithi\Documents\IRES\NH E-CYCLE DATASET",
    )
)

# Main processed dataset used by models.py
DATASET_CSV = (
        PROCESSED_DIR / "hybrid_cycle_dataset.csv"
)

BATTERY_SUMMARY_CSV = (
        PROCESSED_DIR / "battery_summary.csv"
)

NASA_PROCESSED_FILE = (
        PROCESSED_DIR / "nasa_features.csv"
)

NH_PROCESSED_FILE = (
        PROCESSED_DIR / "nh_ecycle_features.csv"
)

# ============================================================
# 3. REAL-TIME DATA FILES
# ============================================================

REALTIME_DATA_DIR = REALTIME_DIR

REALTIME_LOG_FILE = (
        REALTIME_DIR / "realtime_data.csv"
)

# ============================================================
# 4. BATTERY DEFINITIONS
# ============================================================

# 2S pack: two cells in series.
BATTERY_SERIES_CELLS = 2

# Actual cell capacity used by this project.
CELL_CAPACITY_MAH = 1200.0

# IMPORTANT:
# In a series pack, voltage adds but Ah capacity does not.
PACK_CAPACITY_MAH = CELL_CAPACITY_MAH
PACK_CAPACITY_AH = PACK_CAPACITY_MAH / 1000.0

# Nominal/reference capacity used when a fallback is required.
DEFAULT_RATED_CAPACITY_AH = PACK_CAPACITY_AH

# Cell voltage limits used for the real-time SOC display.
FULL_CELL_VOLTAGE = 4.20
EMPTY_CELL_VOLTAGE = 2.80

# ============================================================
# 5. SOH / RUL DEFINITIONS
# ============================================================

# Project EOL definition.
# SOH <= 80% is considered End of Life.
EOL_SOH = 80.0

# Health display thresholds.
HEALTH_THRESHOLDS = {
    "EXCELLENT": 90.0,
    "GOOD": 80.0,
    "AGING": 70.0,
    "POOR": 60.0,
}

# Early warning thresholds.
SOH_APPROACHING_EOL_WARNING = 85.0
RUL_SERVICE_WARNING_CYCLES = 30

# ============================================================
# 6. EXACT ML FEATURE SCHEMA
# ============================================================
#
# These 15 features are the common feature vector used by the
# current training/realtime pipeline.
#
# DO NOT change the order unless models.py and the trained model
# artifacts are retrained with the same new order.
# ============================================================

FEATURES = [
    # Voltage
    "voltage_mean",
    "voltage_min",
    "voltage_max",
    "voltage_std",

    # Current
    "current_mean",
    "current_abs_mean",
    "current_rms",
    "current_std",

    # Temperature
    "temperature_mean",
    "temperature_min",
    "temperature_max",
    "temperature_std",

    # Time
    "duration_min",

    # Power
    "power_mean",
    "power_abs_mean",
]

# ============================================================
# 7. REAL-TIME SETTINGS
# ============================================================

# Number of completed discharge cycles required by the
# CNN-BiLSTM RUL model.
SEQUENCE_LENGTH = 20
RUL_SEQUENCE_LENGTH = SEQUENCE_LENGTH

# Number of recent raw samples retained for UI/diagnostics.
REALTIME_ROLLING_WINDOW = 100

# Number of SOH results retained for trend display.
SOH_HISTORY_WINDOW = 20

# Minimum raw samples needed to create a completed cycle feature.
MIN_CYCLE_SAMPLES = 10

# Current deadband.
CURRENT_DEADBAND_A = 0.05

# SOC thresholds used by the real-time cycle state machine.
FULL_SOC_THRESHOLD = 95.0
EMPTY_SOC_THRESHOLD = 0.5

# Consecutive near-empty samples required before a cycle is
# considered complete.
EMPTY_CONFIRMATION_SAMPLES = 3

# Current sign convention:
#   +1 -> discharge current is positive
#   -1 -> discharge current is negative
#
# The current realtime code currently assumes negative current
# during discharge. Verify this against the Arduino sketch.
DISCHARGE_CURRENT_SIGN = -1

# ============================================================
# 8. ARDUINO SERIAL SETTINGS
# ============================================================

SERIAL_PORT = os.environ.get(
    "SERIAL_PORT",
    "COM8",
)

SERIAL_BAUD = int(
    os.environ.get(
        "SERIAL_BAUD",
        "115200",
    )
)

SERIAL_READ_INTERVAL = 0.5

# ============================================================
# 9. GENERAL ML SETTINGS
# ============================================================

RANDOM_STATE = 42

N_SPLITS = 5

# ============================================================
# 10. MODEL ARTIFACTS
# ============================================================

# Primary SOH model used in real time.
SOH_MODEL_FILE = (
        MODEL_DIR / "soh_RandomForest.joblib"
)

# Primary RUL model used in real time.
RUL_MODEL_FILE = (
        MODEL_DIR / "rul_CNN_BiLSTM.keras"
)

RUL_SCALER_FILE = (
        MODEL_DIR / "rul_CNN_BiLSTM_scaler.joblib"
)

RUL_METADATA_FILE = (
        MODEL_DIR / "rul_CNN_BiLSTM_metadata.json"
)

# Alternative trained SOH models.
SOH_ALTERNATIVE_MODEL_FILES = [
    MODEL_DIR / "soh_BaggingTree.joblib",
    MODEL_DIR / "soh_ExtraTrees.joblib",
]

# Alternative traditional RUL models.
RUL_ALTERNATIVE_MODEL_FILES = [
    MODEL_DIR / "rul_BaggingTree.joblib",
    MODEL_DIR / "rul_HistGradientBoosting.joblib",
]

# Compatibility aliases used by older scripts.
SOH_MODEL_PATH = SOH_MODEL_FILE
RUL_MODEL_PATH = RUL_MODEL_FILE
SOH_SCALER_PATH = MODEL_DIR / "soh_scaler.joblib"
RUL_SCALER_PATH = RUL_SCALER_FILE
FEATURE_COLUMNS_PATH = MODEL_DIR / "feature_columns.joblib"
METADATA_PATH = RUL_METADATA_FILE

# ============================================================
# 11. MODEL SELECTION / TRAINING OUTPUT
# ============================================================

MODEL_SELECTION_FILE = (
        MODEL_DIR / "model_selection_results.json"
)

MODEL_METADATA_FILE = (
        MODEL_DIR / "model_metadata.json"
)

# ============================================================
# 12. RESULT FILES
# ============================================================

METRICS_FILE = (
        RESULTS_DIR / "metrics.json"
)

SOH_PREDICTIONS_FILE = (
        RESULTS_DIR / "soh_predictions.csv"
)

RUL_PREDICTIONS_FILE = (
        RESULTS_DIR / "rul_predictions.csv"
)

SOH_PLOT_FILE = (
        RESULTS_DIR / "soh_actual_vs_predicted.png"
)

RUL_PLOT_FILE = (
        RESULTS_DIR / "rul_actual_vs_predicted.png"
)

SOH_ERROR_PLOT_FILE = (
        RESULTS_DIR / "soh_error.png"
)

RUL_ERROR_PLOT_FILE = (
        RESULTS_DIR / "rul_error.png"
)

# ============================================================
# 13. LOGGING
# ============================================================

LOG_FILE = (
        LOGS_DIR / "system.log"
)

# ============================================================
# 14. DATA QUALITY LIMITS
# ============================================================

MIN_VALID_SOH = 0.0
MAX_VALID_SOH = 100.0

MIN_VALID_CAPACITY_AH = 0.001

# ============================================================
# 15. CREATE REQUIRED DIRECTORIES
# ============================================================

for _directory in (
        DATA_DIR,
        PROCESSED_DIR,
        RAW_DIR,
        REALTIME_DIR,
        MODEL_DIR,
        RESULTS_DIR,
        PLOTS_DIR,
        REPORTS_DIR,
        LOGS_DIR,
):
    _directory.mkdir(
        parents=True,
        exist_ok=True,
    )
