# ============================================================
# dataset_preparation.py
# HYBRID BATTERY SOH / RUL PREDICTION SYSTEM
#
# Sources:
#   1. NASA .MAT battery dataset
#   2. Processed *_discharge_soh.csv files aka mam's dataset from sastra
#
# Output:
#   data/processed/hybrid_cycle_dataset.csv
#   data/processed/battery_summary.csv
#
# ============================================================

from pathlib import Path
import warnings

import numpy as np
import pandas as pd

try:
    from scipy.io import loadmat
except ImportError:
    loadmat = None

from config import (
    NASA_DIR,
    NH_DIR,
    DATASET_CSV,
    BATTERY_SUMMARY_CSV,
    EOL_SOH,
    MIN_VALID_CAPACITY_AH,
    MIN_VALID_SOH,
    MAX_VALID_SOH,
)

warnings.filterwarnings("ignore")


# ============================================================
# COMMON FEATURE COLUMNS
# ============================================================

FEATURE_COLUMNS = [
    "voltage_mean",
    "voltage_min",
    "voltage_max",
    "voltage_std",

    "current_mean",
    "current_abs_mean",
    "current_rms",
    "current_std",

    "temperature_mean",
    "temperature_min",
    "temperature_max",
    "temperature_std",

    "duration_min",

    "power_mean",
    "power_abs_mean",
]


# ============================================================
# SAFE UTILITIES
# ============================================================

def safe_float(value):
    """Safely convert a MATLAB/numpy value to float."""

    try:
        arr = np.asarray(value).squeeze()

        if arr.size == 0:
            return np.nan

        return float(arr.flat[0])

    except Exception:
        return np.nan


def matlab_array(value):
    """Convert MATLAB data to a 1-D numpy array."""

    try:
        if value is None:
            return np.array([], dtype=float)

        arr = np.asarray(value).squeeze()

        if arr.size == 0:
            return np.array([], dtype=float)

        return np.atleast_1d(arr)

    except Exception:
        return np.array([], dtype=float)


def get_field(obj, name):
    """
    Read a field from:
        - scipy mat_struct
        - dictionary
        - numpy structured array
    """

    try:

        if hasattr(obj, name):
            return getattr(obj, name)

        if isinstance(obj, dict):
            return obj.get(name, None)

        if isinstance(obj, np.ndarray):

            if obj.dtype.names and name in obj.dtype.names:
                return obj[name]

    except Exception:
        pass

    return None


def finite_array(values):
    """Return numeric finite values only."""

    values = pd.to_numeric(
        pd.Series(values),
        errors="coerce"
    )

    return values[
        np.isfinite(values)
    ].to_numpy(float)


# ============================================================
# TIME / INTEGRATION UTILITIES
# ============================================================

def calculate_duration_minutes(time_values):
    """Calculate cycle duration in minutes."""

    t = finite_array(time_values)

    if len(t) < 2:
        return 0.0

    return max(
        0.0,
        float(
            (np.max(t) - np.min(t)) / 60.0
        )
    )


def calculate_integrated_charge(time_values, current_values):
    """
    Calculate absolute Ah using trapezoidal integration.
    """

    t = np.asarray(time_values, dtype=float)
    i = np.asarray(current_values, dtype=float)

    n = min(len(t), len(i))

    if n < 2:
        return np.nan

    t = t[:n]
    i = i[:n]

    valid = (
        np.isfinite(t)
        &
        np.isfinite(i)
    )

    if valid.sum() < 2:
        return np.nan

    t = t[valid]
    i = i[valid]

    order = np.argsort(t)

    t = t[order]
    i = i[order]

    dt = np.diff(t)

    valid_dt = dt > 0

    if not valid_dt.any():
        return np.nan

    charge = np.sum(
        np.abs(
            (i[:-1] + i[1:]) / 2.0
            *
            np.where(
                valid_dt,
                dt,
                0.0
            )
        )
    )

    return float(
        charge / 3600.0
    )


# ============================================================
# MATLAB BATTERY STRUCTURE
# ============================================================

def find_battery_struct(mat, battery_name):
    """Find the battery structure in a NASA MAT file."""

    # Exact variable first
    if battery_name in mat:

        obj = mat[battery_name]

        if get_field(obj, "cycle") is not None:
            return obj

    # Search remaining variables
    for key, value in mat.items():

        if str(key).startswith("__"):
            continue

        if get_field(value, "cycle") is not None:
            return value

    return None


def get_cycle_array(battery):
    """Extract battery cycle array."""

    cycles = get_field(
        battery,
        "cycle"
    )

    if cycles is None:
        return []

    try:

        cycles = np.asarray(
            cycles,
            dtype=object
        ).squeeze()

        return np.atleast_1d(
            cycles
        )

    except Exception:
        return []


# ============================================================
# NASA DISCHARGE EXTRACTION
# ============================================================

def extract_discharge_cycle(cycle):
    """
    Extract one NASA discharge cycle.
    """

    try:

        cycle_type = get_field(
            cycle,
            "type"
        )

        if cycle_type is None:
            return None

        # MATLAB strings can arrive in many forms
        if isinstance(cycle_type, np.ndarray):

            flattened = cycle_type.squeeze()

            if flattened.dtype.kind in (
                "U",
                "S"
            ):
                cycle_type = "".join(
                    np.asarray(
                        flattened
                    ).astype(str).flatten()
                )

            else:
                cycle_type = str(
                    flattened
                )

        else:
            cycle_type = str(
                cycle_type
            )

        cycle_type = (
            cycle_type
            .strip()
            .lower()
        )

        if "discharge" not in cycle_type:
            return None

        data = get_field(
            cycle,
            "data"
        )

        if data is None:
            return None

        voltage = matlab_array(
            get_field(
                data,
                "Voltage_measured"
            )
        )

        current = matlab_array(
            get_field(
                data,
                "Current_measured"
            )
        )

        temperature = matlab_array(
            get_field(
                data,
                "Temperature_measured"
            )
        )

        time = matlab_array(
            get_field(
                data,
                "Time"
            )
        )

        capacity = safe_float(
            get_field(
                data,
                "Capacity"
            )
        )

        if voltage.size == 0:
            return None

        n = len(voltage)

        # Missing current
        if current.size == 0:

            current = np.full(
                n,
                np.nan
            )

        # Missing temperature
        if temperature.size == 0:

            temperature = np.full(
                n,
                np.nan
            )

        # Missing time
        if time.size == 0:

            time = np.arange(
                n,
                dtype=float
            )

        # Same length
        n = min(
            len(voltage),
            len(current),
            len(temperature),
            len(time)
        )

        if n < 3:
            return None

        voltage = np.asarray(
            voltage[:n],
            dtype=float
        )

        current = np.asarray(
            current[:n],
            dtype=float
        )

        temperature = np.asarray(
            temperature[:n],
            dtype=float
        )

        time = np.asarray(
            time[:n],
            dtype=float
        )

        # ----------------------------------------------------
        # Capacity fallback
        # ----------------------------------------------------

        if not np.isfinite(capacity):

            capacity = calculate_integrated_charge(
                time,
                current
            )

        if not np.isfinite(capacity):
            return None

        if capacity <= 0:
            return None

        return {
            "voltage": voltage,
            "current": current,
            "temperature": temperature,
            "time": time,
            "capacity": float(capacity),
        }

    except Exception:
        return None


# ============================================================
# FEATURE EXTRACTION
# ============================================================

def make_cycle_features(
    battery_id,
    cycle_number,
    record
):
    """Convert one raw discharge cycle into one feature row."""

    voltage = np.asarray(
        record["voltage"],
        dtype=float
    )

    current = np.asarray(
        record["current"],
        dtype=float
    )

    temperature = np.asarray(
        record["temperature"],
        dtype=float
    )

    time_values = np.asarray(
        record["time"],
        dtype=float
    )

    capacity = float(
        record["capacity"]
    )

    # --------------------------------------------------------
    # Valid masks
    # --------------------------------------------------------

    v = finite_array(
        voltage
    )

    i = finite_array(
        current
    )

    temp = finite_array(
        temperature
    )

    if len(v) < 3:
        return None

    # Power uses matching finite voltage/current samples
    n = min(
        len(voltage),
        len(current)
    )

    vv = voltage[:n]
    ii = current[:n]

    valid_power = (
        np.isfinite(vv)
        &
        np.isfinite(ii)
    )

    power = (
        vv[valid_power]
        *
        ii[valid_power]
    )

    if len(power) == 0:
        power = np.array([np.nan])

    return {

        "battery_id":
            str(battery_id),

        "source":
            "NASA",

        "cycle":
            float(cycle_number),

        "capacity_ah":
            capacity,

        # Voltage
        "voltage_mean":
            float(np.nanmean(v)),

        "voltage_min":
            float(np.nanmin(v)),

        "voltage_max":
            float(np.nanmax(v)),

        "voltage_std":
            float(np.nanstd(v)),

        # Current
        "current_mean":
            float(np.nanmean(i)),

        "current_abs_mean":
            float(
                np.nanmean(
                    np.abs(i)
                )
            ),

        "current_rms":
            float(
                np.sqrt(
                    np.nanmean(
                        i ** 2
                    )
                )
            ),

        "current_std":
            float(np.nanstd(i)),

        # Temperature
        "temperature_mean":
            float(np.nanmean(temp)),

        "temperature_min":
            float(np.nanmin(temp)),

        "temperature_max":
            float(np.nanmax(temp)),

        "temperature_std":
            float(np.nanstd(temp)),

        # Time
        "duration_min":
            calculate_duration_minutes(
                time_values
            ),

        # Power
        "power_mean":
            float(np.nanmean(power)),

        "power_abs_mean":
            float(
                np.nanmean(
                    np.abs(power)
                )
            ),
    }


# ============================================================
# NASA FILE SEARCH
# ============================================================

def find_mat_files():

    root = Path(
        NASA_DIR
    )

    if not root.exists():

        raise FileNotFoundError(
            f"NASA directory does not exist:\n{root}"
        )

    return sorted(
        root.rglob("*.mat")
    )


# ============================================================
# LOAD NASA
# ============================================================

def load_nasa():

    if loadmat is None:

        raise ImportError(
            "scipy is not installed.\n"
            "Run: pip install scipy"
        )

    files = find_mat_files()

    print(
        f"NASA files found: {len(files)}"
    )

    rows = []

    for number, file in enumerate(
        files,
        start=1
    ):

        battery_id = file.stem

        print(
            f"NASA [{number}/{len(files)}] "
            f"Reading {file.name}"
        )

        try:

            mat = loadmat(
                file,
                squeeze_me=True,
                struct_as_record=False
            )

            battery = find_battery_struct(
                mat,
                battery_id
            )

            if battery is None:

                print(
                    "  WARNING: battery structure not found"
                )

                continue

            cycles = get_cycle_array(
                battery
            )

            if len(cycles) == 0:

                print(
                    "  WARNING: cycle array empty"
                )

                continue

            count = 0

            # The raw NASA cycle array includes charge and impedance
            # operations. RUL must be measured in discharge cycles only.
            discharge_cycle_number = 0

            for cycle in cycles:

                record = extract_discharge_cycle(
                    cycle
                )

                if record is None:
                    continue

                discharge_cycle_number += 1

                row = make_cycle_features(
                    battery_id,
                    discharge_cycle_number,
                    record
                )

                if row is None:
                    continue

                rows.append(
                    row
                )

                count += 1

            print(
                f"  Discharge cycles extracted: {count}"
            )

        except Exception as exc:

            print(
                f"  ERROR: {file.name}"
            )

            print(
                f"  {type(exc).__name__}: {exc}"
            )

    result = pd.DataFrame(
        rows
    )

    print()
    print(
        f"NASA discharge cycles: {len(result):,}"
    )

    return result


# ============================================================
# PROCESSED CSV SEARCH
# ============================================================

def find_processed_csvs():

    roots = [
        Path(NASA_DIR),
        Path(NH_DIR),
    ]

    files = []

    for root in roots:

        if not root.exists():
            continue

        files.extend(
            root.rglob(
                "*_discharge_soh.csv"
            )
        )

    return sorted(
        set(files)
    )


# ============================================================
# LOAD PROCESSED CSV
# ============================================================

def load_processed_csvs():

    files = find_processed_csvs()

    print()
    print(
        f"Processed CSV files found: {len(files)}"
    )

    rows = []

    for file in files:

        try:

            d = pd.read_csv(
                file
            )

            required = [
                "terminal_voltage",
                "terminal_current",
                "temperature",
                "capacity",
                "cycle",
            ]

            missing = [
                c for c in required
                if c not in d.columns
            ]

            if missing:

                print(
                    f"  Skip {file.name}: "
                    f"missing {missing}"
                )

                continue

            voltage = pd.to_numeric(
                d["terminal_voltage"],
                errors="coerce"
            )

            current = pd.to_numeric(
                d["terminal_current"],
                errors="coerce"
            )

            temperature = pd.to_numeric(
                d["temperature"],
                errors="coerce"
            )

            capacity = pd.to_numeric(
                d["capacity"],
                errors="coerce"
            )

            if "time" in d.columns:

                time_values = pd.to_numeric(
                    d["time"],
                    errors="coerce"
                )

            else:

                time_values = pd.Series(
                    np.arange(
                        len(d),
                        dtype=float
                    ),
                    index=d.index
                )

            # Direct SOH if supplied
            if "SOH" in d.columns:

                direct_soh = pd.to_numeric(
                    d["SOH"],
                    errors="coerce"
                )

            else:

                direct_soh = pd.Series(
                    np.nan,
                    index=d.index,
                    dtype=float
                )

            battery_id = file.stem.replace(
                "_discharge_soh",
                ""
            )

            cycle_numeric = pd.to_numeric(
                d["cycle"],
                errors="coerce"
            )

            for cycle_id, group in d.groupby(
                cycle_numeric,
                sort=True
            ):

                if not np.isfinite(
                    cycle_id
                ):
                    continue

                idx = group.index

                v = voltage.loc[
                    idx
                ].to_numpy(float)

                i = current.loc[
                    idx
                ].to_numpy(float)

                temp = temperature.loc[
                    idx
                ].to_numpy(float)

                t = time_values.loc[
                    idx
                ].to_numpy(float)

                cap_values = capacity.loc[
                    idx
                ]

                cap_values = cap_values[
                    np.isfinite(
                        cap_values
                    )
                    &
                    (
                        cap_values
                        >
                        MIN_VALID_CAPACITY_AH
                    )
                ]

                if len(cap_values) == 0:
                    continue

                # Use the last valid capacity value in cycle
                capacity_value = float(
                    cap_values.iloc[-1]
                )

                # Direct SOH
                soh_values = direct_soh.loc[
                    idx
                ]

                soh_values = soh_values[
                    np.isfinite(
                        soh_values
                    )
                ]

                if len(soh_values) > 0:

                    soh_value = float(
                        soh_values.iloc[-1]
                    )

                else:

                    soh_value = np.nan

                # ------------------------------------------------
                # Power
                # ------------------------------------------------

                n = min(
                    len(v),
                    len(i)
                )

                vv = v[:n]
                ii = i[:n]

                valid = (
                    np.isfinite(vv)
                    &
                    np.isfinite(ii)
                )

                if valid.sum() == 0:
                    continue

                p = (
                    vv[valid]
                    *
                    ii[valid]
                )

                # ------------------------------------------------
                # Feature row
                # ------------------------------------------------

                row = {

                    "battery_id":
                        battery_id,

                    "source":
                        "CSV",

                    "cycle":
                        float(cycle_id),

                    "capacity_ah":
                        capacity_value,

                    "voltage_mean":
                        float(
                            np.nanmean(v)
                        ),

                    "voltage_min":
                        float(
                            np.nanmin(v)
                        ),

                    "voltage_max":
                        float(
                            np.nanmax(v)
                        ),

                    "voltage_std":
                        float(
                            np.nanstd(v)
                        ),

                    "current_mean":
                        float(
                            np.nanmean(i)
                        ),

                    "current_abs_mean":
                        float(
                            np.nanmean(
                                np.abs(i)
                            )
                        ),

                    "current_rms":
                        float(
                            np.sqrt(
                                np.nanmean(
                                    i ** 2
                                )
                            )
                        ),

                    "current_std":
                        float(
                            np.nanstd(i)
                        ),

                    "temperature_mean":
                        float(
                            np.nanmean(temp)
                        ),

                    "temperature_min":
                        float(
                            np.nanmin(temp)
                        ),

                    "temperature_max":
                        float(
                            np.nanmax(temp)
                        ),

                    "temperature_std":
                        float(
                            np.nanstd(temp)
                        ),

                    "duration_min":
                        calculate_duration_minutes(
                            t
                        ),

                    "power_mean":
                        float(
                            np.nanmean(p)
                        ),

                    "power_abs_mean":
                        float(
                            np.nanmean(
                                np.abs(p)
                            )
                        ),

                    "soh_direct":
                        soh_value,
                }

                rows.append(
                    row
                )

        except Exception as exc:

            print(
                f"  CSV error: {file.name} | "
                f"{type(exc).__name__}: {exc}"
            )

    result = pd.DataFrame(
        rows
    )

    print(
        f"Processed CSV cycle rows: {len(result):,}"
    )

    return result


# ============================================================
# SOH CALCULATION
# ============================================================

def calculate_soh(d):
    """
    Calculate SOH robustly.

    Priority:

    1. Valid direct SOH from processed CSV.
    2. Capacity-based SOH using the maximum valid observed
       capacity of that battery as its healthy reference.

    Invalid SOH values outside 0-100 are discarded.
    """

    d = d.copy()

    d["capacity_ah"] = pd.to_numeric(
        d["capacity_ah"],
        errors="coerce"
    )

    # Remove impossible capacity
    d.loc[
        d["capacity_ah"]
        <=
        MIN_VALID_CAPACITY_AH,
        "capacity_ah"
    ] = np.nan

    # --------------------------------------------------------
    # IMPORTANT:
    # Use maximum valid observed capacity per battery
    # instead of the first row.
    #
    # This avoids the previous situation where a later
    # reference/diagnostic cycle could cause SOH > 100%.
    # --------------------------------------------------------

    reference_capacity = (
        d.groupby(
            "battery_id"
        )["capacity_ah"]
        .transform("max")
    )

    calculated_soh = (
        100.0
        *
        d["capacity_ah"]
        /
        reference_capacity.replace(
            0,
            np.nan
        )
    )

    # --------------------------------------------------------
    # Direct SOH
    # --------------------------------------------------------

    if "soh_direct" in d.columns:

        direct_soh = pd.to_numeric(
            d["soh_direct"],
            errors="coerce"
        )

        # Invalid direct values
        direct_soh.loc[
            (
                direct_soh
                <
                MIN_VALID_SOH
            )
            |
            (
                direct_soh
                >
                MAX_VALID_SOH
            )
        ] = np.nan

    else:

        direct_soh = pd.Series(
            np.nan,
            index=d.index,
            dtype=float
        )

    # --------------------------------------------------------
    # Direct SOH has priority
    # --------------------------------------------------------

    d["soh"] = direct_soh.fillna(
        calculated_soh
    )

    # Final validation
    d.loc[
        (
            d["soh"]
            <
            MIN_VALID_SOH
        )
        |
        (
            d["soh"]
            >
            MAX_VALID_SOH
        ),
        "soh"
    ] = np.nan

    return d


# ============================================================
# RUL CALCULATION
# ============================================================

def calculate_rul(
    d,
    eol_soh=EOL_SOH
):
    """
    Calculate RUL only for batteries that actually reach
    the specified EOL threshold.

    RUL = EOL cycle - current cycle.

    Batteries that never reach EOL remain right-censored
    and receive NaN RUL.
    """

    d = d.copy()

    d["rul"] = np.nan

    for battery_id, group in d.groupby(
        "battery_id"
    ):

        group = group.sort_values(
            "cycle"
        )

        valid = group[
            group["soh"].notna()
        ]

        if valid.empty:
            continue

        # First cycle at or below EOL
        eol = valid[
            valid["soh"] <= eol_soh
        ]

        if eol.empty:
            # Right censored
            continue

        eol_cycle = float(
            eol[
                "cycle"
            ].iloc[0]
        )

        rul = (
            eol_cycle
            -
            group[
                "cycle"
            ].astype(float)
        )

        rul = rul.clip(
            lower=0
        )

        d.loc[
            group.index,
            "rul"
        ] = rul.values

    return d


# ============================================================
# CLEAN DATASET
# ============================================================

def clean_dataset(d):

    d = d.copy()

    numeric_columns = [
        "cycle",
        "capacity_ah",
        *FEATURE_COLUMNS,
        "soh_direct",
        "soh",
        "rul",
    ]

    for column in numeric_columns:

        if column in d.columns:

            d[column] = pd.to_numeric(
                d[column],
                errors="coerce"
            )

    # --------------------------------------------------------
    # Remove invalid capacity
    # --------------------------------------------------------

    d.loc[
        d["capacity_ah"]
        <=
        MIN_VALID_CAPACITY_AH,
        "capacity_ah"
    ] = np.nan

    # --------------------------------------------------------
    # Required fields
    # --------------------------------------------------------

    d = d.dropna(
        subset=[
            "battery_id",
            "cycle",
            "capacity_ah",
            "soh",
        ]
    )

    # --------------------------------------------------------
    # Remove impossible SOH
    # --------------------------------------------------------

    d = d[
        (
            d["soh"]
            >=
            MIN_VALID_SOH
        )
        &
        (
            d["soh"]
            <=
            MAX_VALID_SOH
        )
    ]

    # --------------------------------------------------------
    # Sort
    # --------------------------------------------------------

    d = d.sort_values(
        [
            "battery_id",
            "cycle",
        ]
    )

    # --------------------------------------------------------
    # Duplicate battery/cycle
    # --------------------------------------------------------

    d = d.drop_duplicates(
        subset=[
            "battery_id",
            "cycle",
        ],
        keep="last"
    )

    # --------------------------------------------------------
    # Reset index
    # --------------------------------------------------------

    d = d.reset_index(
        drop=True
    )

    return d


# ============================================================
# BATTERY SUMMARY
# ============================================================

def make_battery_summary(d):

    rows = []

    for battery_id, group in d.groupby(
        "battery_id"
    ):

        group = group.sort_values(
            "cycle"
        )

        valid_rul = group[
            group["rul"].notna()
        ]

        eol_reached = (
            len(valid_rul) > 0
        )

        eol_cycle = np.nan

        if eol_reached:

            eol_rows = group[
                group["soh"] <= EOL_SOH
            ]

            if not eol_rows.empty:

                eol_cycle = float(
                    eol_rows[
                        "cycle"
                    ].iloc[0]
                )

        rows.append(
            {
                "battery_id":
                    battery_id,

                "source":
                    ",".join(
                        sorted(
                            group[
                                "source"
                            ]
                            .astype(str)
                            .unique()
                        )
                    ),

                "cycles":
                    int(
                        len(group)
                    ),

                "first_cycle":
                    float(
                        group[
                            "cycle"
                        ].iloc[0]
                    ),

                "last_cycle":
                    float(
                        group[
                            "cycle"
                        ].iloc[-1]
                    ),

                "first_soh":
                    float(
                        group[
                            "soh"
                        ].iloc[0]
                    ),

                "last_soh":
                    float(
                        group[
                            "soh"
                        ].iloc[-1]
                    ),

                "minimum_soh":
                    float(
                        group[
                            "soh"
                        ].min()
                    ),

                "maximum_soh":
                    float(
                        group[
                            "soh"
                        ].max()
                    ),

                "eol_reached":
                    bool(
                        eol_reached
                    ),

                "eol_cycle":
                    eol_cycle,
            }
        )

    return pd.DataFrame(
        rows
    )


# ============================================================
# MAIN LOAD FUNCTION
# ============================================================

def load():

    print()
    print("=" * 72)
    print(
        " HYBRID BATTERY SOH/RUL DATASET PREPARATION"
    )
    print("=" * 72)

    print()
    print("NASA path:")
    print(NASA_DIR)

    print()
    print("NH path:")
    print(NH_DIR)

    # ========================================================
    # NASA
    # ========================================================

    try:

        nasa = load_nasa()

    except Exception as exc:

        print()
        print(
            "NASA loading ERROR:"
        )

        print(
            type(exc).__name__,
            ":",
            exc
        )

        nasa = pd.DataFrame()

    # ========================================================
    # PROCESSED CSV
    # ========================================================

    csv_data = load_processed_csvs()

    # ========================================================
    # COMBINE
    # ========================================================

    datasets = []

    if not nasa.empty:
        datasets.append(
            nasa
        )

    if not csv_data.empty:
        datasets.append(
            csv_data
        )

    if not datasets:

        print()
        print("=" * 72)
        print(
            "ERROR: No usable battery lifecycle data found."
        )
        print("=" * 72)

        return None

    d = pd.concat(
        datasets,
        ignore_index=True,
        sort=False
    )

    # ========================================================
    # SOURCE PRIORITY
    # ========================================================
    #
    # Processed CSV contains direct SOH when available,
    # therefore it gets priority over NASA for the same
    # battery/cycle.
    #
    # ========================================================

    priority = {
        "NASA": 1,
        "CSV": 2,
    }

    d["_priority"] = (
        d["source"]
        .map(priority)
        .fillna(0)
    )

    d = d.sort_values(
        [
            "battery_id",
            "cycle",
            "_priority",
        ]
    )

    d = d.drop_duplicates(
        subset=[
            "battery_id",
            "cycle",
        ],
        keep="last"
    )

    d = d.drop(
        columns=[
            "_priority"
        ]
    )

    # ========================================================
    # SOH
    # ========================================================

    print()
    print(
        "Creating SOH labels..."
    )

    d = calculate_soh(
        d
    )

    # ========================================================
    # RUL
    # ========================================================

    print(
        "Creating RUL labels..."
    )

    d = calculate_rul(
        d,
        EOL_SOH
    )

    # ========================================================
    # CLEAN
    # ========================================================

    print(
        "Cleaning dataset..."
    )

    d = clean_dataset(
        d
    )

    # ========================================================
    # CHECK
    # ========================================================

    if d.empty:

        print()
        print("=" * 72)
        print(
            "ERROR: Dataset became empty after cleaning."
        )
        print("=" * 72)

        return None

    # ========================================================
    # SAVE DATASET
    # ========================================================

    output = Path(
        DATASET_CSV
    )

    output.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    d.to_csv(
        output,
        index=False
    )

    # ========================================================
    # BATTERY SUMMARY
    # ========================================================

    summary = make_battery_summary(
        d
    )

    summary_file = Path(
        BATTERY_SUMMARY_CSV
    )

    summary_file.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    summary.to_csv(
        summary_file,
        index=False
    )

    # ========================================================
    # REPORT
    # ========================================================

    print()
    print("=" * 72)
    print(
        " DATASET READY"
    )
    print("=" * 72)

    print(
        f"Rows: {len(d):,}"
    )

    print(
        f"Battery IDs: "
        f"{d['battery_id'].nunique():,}"
    )

    print(
        "Sources:",
        d[
            "source"
        ].value_counts().to_dict()
    )

    # --------------------------------------------------------
    # SOH statistics
    # --------------------------------------------------------

    print()
    print(
        "SOH statistics:"
    )

    print(
        d[
            "soh"
        ].describe()
    )

    # --------------------------------------------------------
    # RUL statistics
    # --------------------------------------------------------

    print()
    print(
        "RUL statistics:"
    )

    valid_rul = d[
        d["rul"].notna()
    ]

    if not valid_rul.empty:

        print(
            valid_rul[
                "rul"
            ].describe()
        )

    else:

        print(
            "No valid RUL labels."
        )

    # --------------------------------------------------------
    # EOL information
    # --------------------------------------------------------

    eol_batteries = int(
        summary[
            "eol_reached"
        ].sum()
    )

    censored_batteries = (
        len(summary)
        -
        eol_batteries
    )

    print()
    print(
        f"EOL threshold: {EOL_SOH}%"
    )

    print(
        f"Batteries reaching EOL: "
        f"{eol_batteries}"
    )

    print(
        f"Right-censored batteries: "
        f"{censored_batteries}"
    )

    # --------------------------------------------------------
    # Battery summary
    # --------------------------------------------------------

    print()
    print(
        "Battery summary:"
    )

    print(
        summary.to_string(
            index=False
        )
    )

    # ========================================================
    # FINAL VALIDATION
    # ========================================================

    print()
    print(
        "Feature columns:"
    )

    for feature in FEATURE_COLUMNS:

        status = (
            "OK"
            if feature in d.columns
            else "MISSING"
        )

        print(
            f"  {feature:<24} {status}"
        )

    print()
    print(
        "Dataset saved:"
    )

    print(
        output
    )

    print()
    print(
        "Battery summary saved:"
    )

    print(
        summary_file
    )

    print()
    print(
        "NH E-Cycle files are not mixed into the "
        "NASA lifecycle training table."
    )

    print(
        "They remain available for separate "
        "real-world operating-condition validation."
    )

    print()
    print("=" * 72)
    print(
        " DATASET PREPARATION COMPLETE"
    )
    print("=" * 72)

    return d


# ============================================================
# DIRECT EXECUTION
# ============================================================

if __name__ == "__main__":

    try:

        load()

    except Exception as exc:

        print()
        print("=" * 72)
        print(
            " DATASET ERROR"
        )
        print("=" * 72)

        print(
            type(exc).__name__,
            ":",
            exc
        )

        print()
        print(
            "Check config.py and dataset paths."
        )