"""
arduino_serial.py
=================

Arduino UNO -> Python real-time battery communication

Accepted Arduino lines (all auto-detected):

    4.036,4.030,8.066,-0.435,31.40                      (5 fields)
    4.036,4.030,8.066,-0.435,31.40,29.0,62.0            (7 fields, with DHT11)
    DATA,4.036,4.030,8.066,-0.435,31.40                 (DATA + 5)
    DATA,4.036,4.030,8.066,-0.435,31.40,29.0,62.0       (DATA + 7)

Fields:

    Cell 1 Voltage, Cell 2 Voltage, Pack Voltage, Current,
    Battery Temperature (LM35), [Ambient Temperature (DHT11), Humidity (DHT11)]

Current convention:

    Negative -> DISCHARGING
    Positive -> CHARGING
    Near zero -> IDLE

Returned sample dict keeps ALL the original keys, so existing project code
(dashboard.py etc.) keeps working. New keys added:

    ambient_temperature  (float or None)
    humidity             (float or None)
"""

import time
import math

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    serial = None
    list_ports = None


IGNORED_MESSAGES = {
    "BATTERY_MONITOR_READY",
    "READY",
    "STATUS",
    "START",
    "STARTING",
}


class ArduinoReader:

    def __init__(self, port="COM8", baudrate=115200, timeout=1.0):

        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout

        self.serial = None
        self.connected = False

        self.last_sample = None
        self.samples_received = 0

        self.last_error = None
        self.last_raw_line = ""

    # =========================================================
    # CONNECT
    # =========================================================

    def connect(self):

        if serial is None:
            raise ImportError(
                "PySerial is not installed.\n\nRun:\npip install pyserial"
            )

        if self.is_connected():
            return True

        try:
            print(f"[SERIAL] Connecting to {self.port} @ {self.baudrate}")

            self.serial = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                timeout=self.timeout,
                write_timeout=self.timeout,
            )

            # Arduino UNO resets after serial connection
            time.sleep(2.0)

            try:
                self.serial.reset_input_buffer()
            except Exception:
                pass

            self.connected = True
            self.last_error = None

            print("[SERIAL] Arduino connected")
            return True

        except Exception as e:
            self.connected = False
            self.serial = None
            self.last_error = str(e)

            raise ConnectionError(
                f"Cannot connect to Arduino on {self.port}\n"
                f"Error: {e}\n"
                "Close the Arduino Serial Monitor/Plotter and check the COM port."
            )

    # =========================================================
    # DISCONNECT
    # =========================================================

    def disconnect(self):

        try:
            if self.serial is not None and self.serial.is_open:
                self.serial.close()
        except Exception:
            pass

        self.serial = None
        self.connected = False

    def is_connected(self):

        try:
            return (
                self.connected
                and self.serial is not None
                and self.serial.is_open
            )
        except Exception:
            return False

    # =========================================================
    # READ RAW LINE
    # =========================================================

    def read_line(self):

        if not self.is_connected():
            self.connect()

        try:
            raw = self.serial.readline()

            if not raw:
                return None

            line = raw.decode("utf-8", errors="ignore").strip()
            self.last_raw_line = line

            if not line:
                return None

            return line

        except Exception as e:
            self.last_error = str(e)
            self.disconnect()
            raise ConnectionError(
                "Arduino serial connection lost:\n" + str(e)
            )

    # =========================================================
    # PARSE SAMPLE
    # =========================================================

    @staticmethod
    def parse_sample(line):

        if line is None:
            return None

        line = str(line).replace("\r", "").replace("\n", "").strip()

        if not line:
            return None

        if line.upper() in IGNORED_MESSAGES:
            return None

        parts = [x.strip() for x in line.split(",")]

        # Optional "DATA" prefix
        if parts[0].upper() == "DATA":
            parts = parts[1:]

        # 5 fields = battery only, 7 fields = battery + DHT11
        if len(parts) not in (5, 7):
            return None

        try:
            values = [float(x) for x in parts]
        except (ValueError, TypeError):
            return None

        for value in values:
            if not math.isfinite(value):
                return None

        cell1, cell2, pack, current, temperature = values[:5]

        # -----------------------------------------------------
        # Battery validation
        # -----------------------------------------------------

        if not (0 <= cell1 <= 5.0):
            return None
        if not (0 <= cell2 <= 5.0):
            return None
        if not (0 <= pack <= 10.5):
            return None
        if not (-100 <= current <= 100):
            return None
        if not (-40 <= temperature <= 125):
            return None

        # -----------------------------------------------------
        # DHT11 (optional)
        # -----------------------------------------------------

        ambient = None
        humidity = None

        if len(values) == 7:
            amb, hum = values[5], values[6]

            # Arduino sends 0.0,0.0 until the first successful DHT read,
            # so treat that as "not available yet" instead of real data.
            dht_not_ready = (amb == 0.0 and hum == 0.0)

            if not dht_not_ready:
                if not (-40 <= amb <= 80):
                    return None
                if not (0 <= hum <= 100):
                    return None

                ambient = amb
                humidity = hum

        # -----------------------------------------------------
        # Derived values
        # -----------------------------------------------------

        if current < -0.05:
            mode = "DISCHARGING"
        elif current > 0.05:
            mode = "CHARGING"
        else:
            mode = "IDLE"

        return {
            "timestamp": time.time(),
            "cell1_voltage": cell1,
            "cell2_voltage": cell2,
            "pack_voltage": pack,
            "current": current,
            "temperature": temperature,
            "ambient_temperature": ambient,
            "humidity": humidity,
            "battery_mode": mode,
            "cell_imbalance": abs(cell1 - cell2),
            "power_w": pack * abs(current),
        }

    # =========================================================
    # READ ONE SAMPLE
    # =========================================================

    def read_sample(self, max_attempts=20):

        if not self.is_connected():
            self.connect()

        for _ in range(max_attempts):

            line = self.read_line()

            if line is None:
                continue

            sample = self.parse_sample(line)

            if sample is not None:
                self.last_sample = sample
                self.samples_received += 1
                return sample

        return None

    def read_samples(self, count=10):

        result = []

        for _ in range(count):
            sample = self.read_sample()
            if sample is not None:
                result.append(sample)

        return result

    # =========================================================
    # PORTS
    # =========================================================

    @staticmethod
    def available_ports():

        if list_ports is None:
            return []

        result = []

        try:
            for port in list_ports.comports():
                result.append({
                    "device": port.device,
                    "description": port.description,
                    "manufacturer": port.manufacturer,
                })
        except Exception:
            return []

        return result

    @staticmethod
    def port_names():
        return [x["device"] for x in ArduinoReader.available_ports()]

    # =========================================================
    # INFORMATION
    # =========================================================

    def information(self):

        return {
            "port": self.port,
            "baudrate": self.baudrate,
            "connected": self.is_connected(),
            "samples_received": self.samples_received,
            "last_sample": self.last_sample,
            "last_raw_line": self.last_raw_line,
            "last_error": self.last_error,
        }

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.disconnect()


# =============================================================
# DIRECT SERIAL TEST
# =============================================================

if __name__ == "__main__":

    PORT = "COM8"
    BAUD = 115200

    print("=" * 70)
    print("        ARDUINO UNO REAL-TIME SERIAL TEST")
    print("=" * 70)
    print("Port     :", PORT)
    print("Baudrate :", BAUD)
    print("Ports found:", ArduinoReader.port_names())
    print()

    reader = ArduinoReader(port=PORT, baudrate=BAUD)

    try:
        reader.connect()
        print("Arduino CONNECTED. Waiting for data...")
        print("Expected: 4.036,4.030,8.066,-0.435,31.40,29.0,62.0")

        while True:

            sample = reader.read_sample(max_attempts=20)

            if sample is None:
                print("[WAITING] Raw:", reader.last_raw_line)
                continue

            amb = sample["ambient_temperature"]
            hum = sample["humidity"]

            print()
            print("-" * 60)
            print(f"Cell 1      : {sample['cell1_voltage']:.3f} V")
            print(f"Cell 2      : {sample['cell2_voltage']:.3f} V")
            print(f"Pack        : {sample['pack_voltage']:.3f} V")
            print(f"Current     : {sample['current']:.3f} A")
            print(f"Battery Temp: {sample['temperature']:.2f} C")
            print("Ambient Temp: " + (f"{amb:.1f} C" if amb is not None else "waiting for DHT11"))
            print("Humidity    : " + (f"{hum:.0f} %" if hum is not None else "waiting for DHT11"))
            print(f"Power       : {sample['power_w']:.2f} W")
            print(f"Imbalance   : {sample['cell_imbalance'] * 1000:.1f} mV")
            print(f"Mode        : {sample['battery_mode']}")
            print(f"Samples     : {reader.samples_received}")
            print("-" * 60)

    except KeyboardInterrupt:
        print("\nStopping...")

    except Exception as e:
        print("=" * 70)
        print("SERIAL ERROR")
        print("=" * 70)
        print(e)

    finally:
        reader.disconnect()
        print("Arduino disconnected.")
