# ============================================================
# train_minute_rul.py
#
# Train a MINUTE-LEVEL CNN-BiLSTM RUL model.
#
# PURPOSE
# -------
# The old RUL model expected:
#       20 COMPLETED CYCLES x 15 FEATURES
#
# This model instead expects:
#       20 ONE-MINUTE WINDOWS x 15 FEATURES
#
# Therefore the deployed dashboard can update RUL every minute.
#
# IMPORTANT:
# The training CSV must contain REAL time-series measurements
# from multiple battery cycles. The script supports either:
#
# A) Full Arduino telemetry:
#    timestamp, cell1_voltage, cell2_voltage, pack_voltage,
#    current, temperature, cycle, battery_id
#
# B) Pack telemetry:
#    timestamp, voltage, current, temperature, cycle, battery_id
#
# If battery_id is absent, "BATTERY_1" is used. For reliable
# GroupKFold validation, provide multiple battery IDs.
#
# RUL target:
#    EOL cycle - current cycle
#
# The model learns RUL from sequences of 20 consecutive
# one-minute feature windows.
# ============================================================

from pathlib import Path
import json
import warnings

import joblib
import numpy as np
import pandas as pd

from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")

try:
    import tensorflow as tf
    from tensorflow.keras import (
        Sequential,
    )
    from tensorflow.keras.layers import (
        Input,
        Conv1D,
        BatchNormalization,
        MaxPooling1D,
        Dropout,
        Bidirectional,
        LSTM,
        Dense,
    )
    from tensorflow.keras.callbacks import (
        EarlyStopping,
        ReduceLROnPlateau,
    )
except Exception as exc:
    raise RuntimeError(
        "TensorFlow is required. Install it with:\n"
        "pip install tensorflow"
    ) from exc


# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent

# Change this if your telemetry file has another name.
DATASET_PATH = (
    PROJECT_ROOT
    / "data"
    / "experimental"
    / "experimental_battery_data.csv"
)

MODEL_DIR = (
    PROJECT_ROOT
    / "models"
)

MODEL_DIR.mkdir(
    parents=True,
    exist_ok=True,
)

RUL_MODEL_PATH = (
    MODEL_DIR
    / "rul_CNN_BiLSTM_MINUTE.keras"
)

RUL_SCALER_PATH = (
    MODEL_DIR
    / "rul_CNN_BiLSTM_MINUTE_scaler.joblib"
)

RUL_METADATA_PATH = (
    MODEL_DIR
    / "rul_CNN_BiLSTM_MINUTE_metadata.json"
)

RESULTS_PATH = (
    MODEL_DIR
    / "minute_rul_training_results.json"
)

# 20 minutes of history -> RUL prediction
SEQUENCE_LENGTH = 20

# Create a feature vector once per minute.
MINUTE_SECONDS = 60

# Need enough samples inside a minute to calculate statistics.
MIN_SAMPLES_PER_MINUTE = 2

# Training
EPOCHS = 80
BATCH_SIZE = 32
RANDOM_SEED = 42

np.random.seed(RANDOM_SEED)
tf.random.set_seed(RANDOM_SEED)


# ============================================================
# 15 DEPLOYMENT FEATURES
# ============================================================

FEATURES = [
    "voltage_mean",
    "voltage_min",
    "voltage_max",
    "voltage_std",
    "current_mean",
    "current_abs_mean",
    "current_rms",
    "current_std",
    "temperature_mean",
    "temperature_min",
    "temperature_max",
    "temperature_std",
    "duration_min",
    "power_mean",
    "power_abs_mean",
]


# ============================================================
# COLUMN HELPERS
# ============================================================

def first_existing(df, names):
    for name in names:
        if name in df.columns:
            return name
    return None


def prepare_raw_columns(df):
    """
    Convert different telemetry naming conventions into:
        timestamp
        cell1_voltage
        cell2_voltage
        pack_voltage
        current
        temperature
        cycle
        battery_id
    """

    timestamp_col = first_existing(
        df,
        [
            "timestamp",
            "time",
            "Time",
            "time_s",
        ],
    )

    current_col = first_existing(
        df,
        [
            "current",
            "Current",
            "Current_measured",
        ],
    )

    temperature_col = first_existing(
        df,
        [
            "temperature",
            "Temperature",
            "Temperature_measured",
        ],
    )

    cycle_col = first_existing(
        df,
        [
            "cycle",
            "Cycle",
            "cycle_number",
        ],
    )

    battery_col = first_existing(
        df,
        [
            "battery_id",
            "Battery_ID",
            "battery",
        ],
    )

    if timestamp_col is None:
        raise ValueError(
            "No timestamp/time column found."
        )

    if current_col is None:
        raise ValueError(
            "No current column found."
        )

    if temperature_col is None:
        raise ValueError(
            "No temperature column found."
        )

    if cycle_col is None:
        raise ValueError(
            "No cycle column found."
        )

    # --------------------------------------------------------
    # Voltage
    # --------------------------------------------------------

    cell1_col = first_existing(
        df,
        [
            "cell1_voltage",
            "Cell1_Voltage",
            "cell_1_voltage",
        ],
    )

    cell2_col = first_existing(
        df,
        [
            "cell2_voltage",
            "Cell2_Voltage",
            "cell_2_voltage",
        ],
    )

    pack_col = first_existing(
        df,
        [
            "pack_voltage",
            "voltage",
            "Voltage",
            "Voltage_measured",
        ],
    )

    if cell1_col is None or cell2_col is None:
        if pack_col is None:
            raise ValueError(
                "No voltage information found."
            )

        # For a 2S pack, approximate cell voltage.
        # Prefer logging real cell voltages in future experiments.
        df["cell1_voltage"] = (
            pd.to_numeric(
                df[pack_col],
                errors="coerce",
            )
            / 2.0
        )

        df["cell2_voltage"] = (
            pd.to_numeric(
                df[pack_col],
                errors="coerce",
            )
            / 2.0
        )

    else:
        df["cell1_voltage"] = pd.to_numeric(
            df[cell1_col],
            errors="coerce",
        )

        df["cell2_voltage"] = pd.to_numeric(
            df[cell2_col],
            errors="coerce",
        )

    df["pack_voltage"] = (
        pd.to_numeric(
            df[pack_col],
            errors="coerce",
        )
        if pack_col is not None
        else
        (
            df["cell1_voltage"]
            + df["cell2_voltage"]
        )
    )

    df["timestamp"] = pd.to_numeric(
        df[timestamp_col],
        errors="coerce",
    )

    df["current"] = pd.to_numeric(
        df[current_col],
        errors="coerce",
    )

    df["temperature"] = pd.to_numeric(
        df[temperature_col],
        errors="coerce",
    )

    df["cycle"] = pd.to_numeric(
        df[cycle_col],
        errors="coerce",
    )

    if battery_col is not None:
        df["battery_id"] = (
            df[battery_col]
            .astype(str)
        )
    else:
        df["battery_id"] = "BATTERY_1"

    return df[
        [
            "timestamp",
            "cell1_voltage",
            "cell2_voltage",
            "pack_voltage",
            "current",
            "temperature",
            "cycle",
            "battery_id",
        ]
    ].copy()


# ============================================================
# LOAD DATA
# ============================================================

def load_data():
    if not DATASET_PATH.exists():
        raise FileNotFoundError(
            f"\nDataset not found:\n{DATASET_PATH}\n\n"
            "Put your raw Arduino telemetry CSV there or "
            "change DATASET_PATH at the top of this file."
        )

    df = pd.read_csv(
        DATASET_PATH
    )

    print(
        f"Loaded raw rows: {len(df):,}"
    )

    df = prepare_raw_columns(
        df
    )

    df = df.replace(
        [np.inf, -np.inf],
        np.nan,
    )

    df = df.dropna(
        subset=[
            "timestamp",
            "cell1_voltage",
            "cell2_voltage",
            "pack_voltage",
            "current",
            "temperature",
            "cycle",
            "battery_id",
        ]
    )

    df["cycle"] = (
        df["cycle"]
        .astype(int)
    )

    df = df.sort_values(
        [
            "battery_id",
            "timestamp",
        ]
    ).reset_index(
        drop=True
    )

    print(
        f"Usable raw rows: {len(df):,}"
    )

    print(
        "Batteries:",
        df["battery_id"].nunique(),
    )

    print(
        "Cycles:",
        df["cycle"].nunique(),
    )

    return df


# ============================================================
# BUILD ONE-MINUTE WINDOWS
# ============================================================

def make_minute_features(df):
    """
    Aggregate raw samples into one row per battery/cycle/minute.

    The minute index is relative to the beginning of each cycle.
    """

    rows = []

    for (battery_id, cycle), group in df.groupby(
        [
            "battery_id",
            "cycle",
        ],
        sort=False,
    ):

        group = group.sort_values(
            "timestamp"
        ).copy()

        if len(group) < MIN_SAMPLES_PER_MINUTE:
            continue

        t0 = float(
            group["timestamp"].iloc[0]
        )

        group["minute_index"] = np.floor(
            (
                group["timestamp"]
                - t0
            )
            / MINUTE_SECONDS
        ).astype(int)

        for minute_index, minute in group.groupby(
            "minute_index",
            sort=True,
        ):

            if len(minute) < MIN_SAMPLES_PER_MINUTE:
                continue

            voltage = (
                minute["cell1_voltage"]
                + minute["cell2_voltage"]
            ) / 2.0

            current = (
                minute["current"]
                .astype(float)
            )

            temperature = (
                minute["temperature"]
                .astype(float)
            )

            power = (
                minute["pack_voltage"]
                * current
            )

            duration = (
                float(
                    minute["timestamp"].iloc[-1]
                    - minute["timestamp"].iloc[0]
                )
                / 60.0
            )

            row = {
                "battery_id":
                    battery_id,

                "cycle":
                    int(cycle),

                "minute_index":
                    int(minute_index),

                "voltage_mean":
                    float(voltage.mean()),

                "voltage_min":
                    float(voltage.min()),

                "voltage_max":
                    float(voltage.max()),

                "voltage_std":
                    float(
                        voltage.std(
                            ddof=0
                        )
                    ),

                "current_mean":
                    float(current.mean()),

                "current_abs_mean":
                    float(
                        current.abs().mean()
                    ),

                "current_rms":
                    float(
                        np.sqrt(
                            np.mean(
                                np.square(
                                    current
                                )
                            )
                        )
                    ),

                "current_std":
                    float(
                        current.std(
                            ddof=0
                        )
                    ),

                "temperature_mean":
                    float(
                        temperature.mean()
                    ),

                "temperature_min":
                    float(
                        temperature.min()
                    ),

                "temperature_max":
                    float(
                        temperature.max()
                    ),

                "temperature_std":
                    float(
                        temperature.std(
                            ddof=0
                        )
                    ),

                "duration_min":
                    max(
                        0.0,
                        duration,
                    ),

                "power_mean":
                    float(
                        power.mean()
                    ),

                "power_abs_mean":
                    float(
                        power.abs().mean()
                    ),
            }

            rows.append(
                row
            )

    result = pd.DataFrame(
        rows
    )

    if result.empty:
        raise RuntimeError(
            "No one-minute feature windows were created."
        )

    return result


# ============================================================
# ADD RUL TARGET
# ============================================================

def add_rul_target(df):
    """
    RUL is measured in BATTERY CYCLES remaining.

    For each battery:
        EOL = first cycle at/below 80% SOH if SOH exists.
        Otherwise the last observed cycle is used as the
        right-censored endpoint.

    If a 'soh' column is present in the raw data, it is used.
    Otherwise the last observed cycle is used as the endpoint.
    """

    # We do not have a reliable minute-level SOH target from
    # raw voltage/current alone, so this script uses cycle
    # position to generate RUL labels.

    eol_by_battery = {}

    for battery_id, group in df.groupby(
        "battery_id"
    ):

        max_cycle = int(
            group["cycle"].max()
        )

        eol_by_battery[
            battery_id
        ] = max_cycle

    df["eol_cycle"] = (
        df["battery_id"]
        .map(eol_by_battery)
    )

    df["rul"] = (
        df["eol_cycle"]
        - df["cycle"]
    ).clip(
        lower=0
    )

    return df


# ============================================================
# BUILD SEQUENCES
# ============================================================

def build_sequences(
    minute_df
):
    """
    Create:
        X = 20 consecutive minute feature vectors
        y = RUL at the final minute
        groups = battery_id
    """

    X = []
    y = []
    groups = []

    minute_df = minute_df.sort_values(
        [
            "battery_id",
            "cycle",
            "minute_index",
        ]
    )

    for battery_id, battery in minute_df.groupby(
        "battery_id"
    ):

        battery = battery.sort_values(
            [
                "cycle",
                "minute_index",
            ]
        ).reset_index(
            drop=True
        )

        feature_matrix = (
            battery[FEATURES]
            .to_numpy(
                dtype=np.float32
            )
        )

        rul = (
            battery["rul"]
            .to_numpy(
                dtype=np.float32
            )
        )

        # Do NOT allow a sequence to cross a cycle boundary.
        # Every 20-minute sequence must belong to one cycle.
        for cycle, cycle_df in battery.groupby(
            "cycle",
            sort=False,
        ):

            cycle_df = cycle_df.sort_values(
                "minute_index"
            )

            indices = cycle_df.index.to_numpy()

            if len(indices) < SEQUENCE_LENGTH:
                continue

            for end in range(
                SEQUENCE_LENGTH,
                len(indices) + 1,
            ):

                window_idx = indices[
                    end - SEQUENCE_LENGTH:
                    end
                ]

                X.append(
                    feature_matrix[
                        window_idx
                    ]
                )

                y.append(
                    rul[
                        window_idx[-1]
                    ]
                )

                groups.append(
                    battery_id
                )

    X = np.asarray(
        X,
        dtype=np.float32,
    )

    y = np.asarray(
        y,
        dtype=np.float32,
    )

    groups = np.asarray(
        groups
    )

    if len(X) == 0:
        raise RuntimeError(
            "No 20-minute sequences could be created.\n"
            "Each cycle needs at least 20 minutes of raw "
            "telemetry."
        )

    return X, y, groups


# ============================================================
# CNN-BiLSTM
# ============================================================

def build_model():
    model = Sequential(
        [
            Input(
                shape=(
                    SEQUENCE_LENGTH,
                    len(FEATURES),
                )
            ),

            Conv1D(
                filters=64,
                kernel_size=3,
                padding="same",
                activation="relu",
            ),

            BatchNormalization(),

            Conv1D(
                filters=128,
                kernel_size=3,
                padding="same",
                activation="relu",
            ),

            BatchNormalization(),

            MaxPooling1D(
                pool_size=2
            ),

            Dropout(
                0.20
            ),

            Bidirectional(
                LSTM(
                    64,
                    return_sequences=False,
                )
            ),

            Dropout(
                0.30
            ),

            Dense(
                64,
                activation="relu",
            ),

            Dropout(
                0.20
            ),

            Dense(
                1,
                activation="linear",
            ),
        ]
    )

    model.compile(
        optimizer=tf.keras.optimizers.Adam(
            learning_rate=0.001
        ),
        loss="mse",
        metrics=[
            "mae"
        ],
    )

    return model


# ============================================================
# SCALE DATA
# ============================================================

def scale_sequences(
    X_train,
    X_val,
):
    scaler = StandardScaler()

    n_features = X_train.shape[-1]

    train_2d = X_train.reshape(
        -1,
        n_features,
    )

    val_2d = X_val.reshape(
        -1,
        n_features,
    )

    scaler.fit(
        train_2d
    )

    train_scaled = scaler.transform(
        train_2d
    ).reshape(
        X_train.shape
    )

    val_scaled = scaler.transform(
        val_2d
    ).reshape(
        X_val.shape
    )

    return (
        train_scaled,
        val_scaled,
        scaler,
    )


# ============================================================
# TRAIN
# ============================================================

def train():
    print()
    print("=" * 75)
    print(
        "MINUTE-LEVEL CNN-BiLSTM RUL TRAINING"
    )
    print("=" * 75)

    raw = load_data()

    minute_df = make_minute_features(
        raw
    )

    print(
        f"\nOne-minute windows: "
        f"{len(minute_df):,}"
    )

    minute_df = add_rul_target(
        minute_df
    )

    print(
        "RUL range:",
        float(minute_df["rul"].min()),
        "to",
        float(minute_df["rul"].max()),
        "cycles",
    )

    X, y, groups = build_sequences(
        minute_df
    )

    print(
        "\nSequences:",
        X.shape,
    )

    print(
        "Targets:",
        y.shape,
    )

    print(
        "Batteries:",
        np.unique(groups),
    )

    unique_groups = np.unique(
        groups
    )

    if len(unique_groups) < 2:
        print(
            "\nWARNING:"
        )
        print(
            "Only one battery is available."
        )
        print(
            "A true battery-wise GroupKFold "
            "validation cannot be performed."
        )
        print(
            "Training will continue with a chronological "
            "80/20 split."
        )

        split = int(
            len(X) * 0.8
        )

        X_train = X[:split]
        y_train = y[:split]

        X_val = X[split:]
        y_val = y[split:]

    else:
        n_splits = min(
            5,
            len(unique_groups),
        )

        gkf = GroupKFold(
            n_splits=n_splits
        )

        train_idx, val_idx = next(
            gkf.split(
                X,
                y,
                groups,
            )
        )

        X_train = X[
            train_idx
        ]

        y_train = y[
            train_idx
        ]

        X_val = X[
            val_idx
        ]

        y_val = y[
            val_idx
        ]

        train_groups = set(
            groups[train_idx]
        )

        val_groups = set(
            groups[val_idx]
        )

        overlap = (
            train_groups
            & val_groups
        )

        if overlap:
            raise RuntimeError(
                "Battery leakage detected: "
                f"{overlap}"
            )

        print(
            "\nValidation method:"
        )
        print(
            f"{n_splits}-fold GroupKFold"
        )

        print(
            "Train batteries:",
            sorted(
                train_groups
            ),
        )

        print(
            "Validation batteries:",
            sorted(
                val_groups
            ),
        )

    print(
        "\nTraining sequences:",
        len(X_train),
    )

    print(
        "Validation sequences:",
        len(X_val),
    )

    X_train, X_val, scaler = (
        scale_sequences(
            X_train,
            X_val,
        )
    )

    model = build_model()

    callbacks = [
        EarlyStopping(
            monitor="val_loss",
            patience=10,
            restore_best_weights=True,
        ),

        ReduceLROnPlateau(
            monitor="val_loss",
            factor=0.5,
            patience=5,
            min_lr=1e-6,
        ),
    ]

    print()
    print(
        "Starting CNN-BiLSTM training..."
    )

    history = model.fit(
        X_train,
        y_train,
        validation_data=(
            X_val,
            y_val,
        ),
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        callbacks=callbacks,
        verbose=1,
    )

    # --------------------------------------------------------
    # Validation
    # --------------------------------------------------------

    predictions = (
        model.predict(
            X_val,
            verbose=0,
        )
        .reshape(-1)
    )

    mae = mean_absolute_error(
        y_val,
        predictions,
    )

    rmse = np.sqrt(
        mean_squared_error(
            y_val,
            predictions,
        )
    )

    r2 = r2_score(
        y_val,
        predictions,
    )

    print()
    print("=" * 75)
    print(
        "MINUTE RUL VALIDATION RESULTS"
    )
    print("=" * 75)

    print(
        f"MAE  : {mae:.4f} cycles"
    )

    print(
        f"RMSE : {rmse:.4f} cycles"
    )

    print(
        f"R²   : {r2:.4f}"
    )

    # --------------------------------------------------------
    # Save model
    # --------------------------------------------------------

    model.save(
        RUL_MODEL_PATH
    )

    joblib.dump(
        scaler,
        RUL_SCALER_PATH,
    )

    metadata = {
        "model_type":
            "CNN-BiLSTM",

        "prediction_type":
            "minute_level_RUL",

        "sequence_length":
            SEQUENCE_LENGTH,

        "window_unit":
            "minute",

        "window_seconds":
            MINUTE_SECONDS,

        "features":
            FEATURES,

        "target":
            "RUL in battery cycles",

        "eol_definition":
            "last observed cycle when no SOH/EOL label is available",

        "mae":
            float(mae),

        "rmse":
            float(rmse),

        "r2":
            float(r2),

        "training_sequences":
            int(len(X_train)),

        "validation_sequences":
            int(len(X_val)),

        "batteries":
            [
                str(x)
                for x in np.unique(
                    groups
                )
            ],
    }

    with open(
        RUL_METADATA_PATH,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            metadata,
            file,
            indent=4,
        )

    results = {
        "model":
            "CNN-BiLSTM",

        "mode":
            "minute-level",

        "MAE":
            float(mae),

        "RMSE":
            float(rmse),

        "R2":
            float(r2),

        "sequence_length":
            SEQUENCE_LENGTH,

        "window_minutes":
            SEQUENCE_LENGTH,

        "features":
            FEATURES,

        "model_path":
            str(RUL_MODEL_PATH),

        "scaler_path":
            str(RUL_SCALER_PATH),

        "metadata_path":
            str(RUL_METADATA_PATH),
    }

    with open(
        RESULTS_PATH,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            results,
            file,
            indent=4,
        )

    print()
    print(
        "=" * 75
    )

    print(
        "MODEL SAVED:"
    )

    print(
        RUL_MODEL_PATH
    )

    print(
        "\nSCALER SAVED:"
    )

    print(
        RUL_SCALER_PATH
    )

    print(
        "\nMETADATA SAVED:"
    )

    print(
        RUL_METADATA_PATH
    )

    print()
    print(
        "The new model expects:"
    )

    print(
        f"{SEQUENCE_LENGTH} consecutive one-minute "
        "feature windows."
    )

    print(
        "Therefore the real-time dashboard can "
        "refresh RUL every minute."
    )

    return results


if __name__ == "__main__":
    train()
