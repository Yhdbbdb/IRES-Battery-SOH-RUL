# ============================================================
# features.py
# HYBRID BATTERY SOH / RUL PREDICTION SYSTEM
#
# Historical training:
# NASA + NH E-CYCLE
#        ↓
# Complete discharge cycle
#        ↓
# 15 statistical features
#
# Real-time:
# Arduino
#        ↓
# Complete discharge cycle
#        ↓
# Same 15 features
#        ↓
# ML model
# ============================================================

import numpy as np
import pandas as pd

from config import FEATURES


# ============================================================
# COMMON FEATURE CALCULATION
# ============================================================

def calculate_common_features(
    voltage,
    current,
    temperature,
    time_values=None,
):
    """
    Calculate the exact 15 ML features used by the
    historical training pipeline.
    """

    v = np.asarray(voltage, dtype=float)
    i = np.asarray(current, dtype=float)
    temp = np.asarray(temperature, dtype=float)

    # --------------------------------------------------------
    # Validate
    # --------------------------------------------------------

    if len(v) == 0:
        raise ValueError("Voltage data is empty.")

    if len(v) != len(i) or len(v) != len(temp):
        raise ValueError(
            "Voltage, current and temperature lengths differ."
        )

    valid = (
        np.isfinite(v)
        & np.isfinite(i)
        & np.isfinite(temp)
    )

    v = v[valid]
    i = i[valid]
    temp = temp[valid]

    if len(v) < 3:
        raise ValueError(
            "At least 3 valid samples are required."
        )

    # --------------------------------------------------------
    # Power
    #
    # IMPORTANT:
    # Historical model uses CELL / TERMINAL voltage.
    # Therefore real-time also uses average cell voltage,
    # NOT 2S pack voltage.
    # --------------------------------------------------------

    power = v * i

    # --------------------------------------------------------
    # Duration
    # --------------------------------------------------------

    duration_min = 0.0

    if time_values is not None:

        t = np.asarray(
            time_values,
            dtype=float
        )

        if len(t) == len(valid):

            t = t[valid]

        t = t[np.isfinite(t)]

        if len(t) >= 2:

            duration_min = max(
                0.0,
                float(
                    (
                        np.max(t)
                        -
                        np.min(t)
                    )
                    / 60.0
                )
            )

    # --------------------------------------------------------
    # FEATURES
    # --------------------------------------------------------

    features = {

        # Voltage
        "voltage_mean":
            float(np.mean(v)),

        "voltage_min":
            float(np.min(v)),

        "voltage_max":
            float(np.max(v)),

        "voltage_std":
            float(np.std(v)),

        # Current
        "current_mean":
            float(np.mean(i)),

        "current_abs_mean":
            float(np.mean(np.abs(i))),

        "current_rms":
            float(
                np.sqrt(
                    np.mean(i ** 2)
                )
            ),

        "current_std":
            float(np.std(i)),

        # Temperature
        "temperature_mean":
            float(np.mean(temp)),

        "temperature_min":
            float(np.min(temp)),

        "temperature_max":
            float(np.max(temp)),

        "temperature_std":
            float(np.std(temp)),

        # Duration
        "duration_min":
            float(duration_min),

        # Power
        "power_mean":
            float(np.mean(power)),

        "power_abs_mean":
            float(np.mean(np.abs(power))),
    }

    # --------------------------------------------------------
    # Check schema
    # --------------------------------------------------------

    missing = [
        f
        for f in FEATURES
        if f not in features
    ]

    if missing:

        raise RuntimeError(
            "Missing ML features: "
            f"{missing}"
        )

    return {
        f: float(features[f])
        for f in FEATURES
    }


# ============================================================
# HISTORICAL CYCLE FEATURES
# ============================================================

def cycle_features(df):

    if df is None:
        return None

    if len(df) < 3:
        return None

    d = df.copy()

    # --------------------------------------------------------
    # Normalize column names
    # --------------------------------------------------------

    rename_map = {

        "terminal_voltage":
            "voltage",

        "Voltage_measured":
            "voltage",

        "terminal_current":
            "current",

        "Current_measured":
            "current",

        "Temperature_measured":
            "temperature",

        "temp":
            "temperature",
    }

    d = d.rename(
        columns=rename_map
    )

    required = [
        "voltage",
        "current",
        "temperature",
    ]

    for column in required:

        if column not in d.columns:
            return None

        d[column] = pd.to_numeric(
            d[column],
            errors="coerce"
        )

    # --------------------------------------------------------
    # Time
    # --------------------------------------------------------

    if "time" in d.columns:

        d["time"] = pd.to_numeric(
            d["time"],
            errors="coerce"
        )

    else:

        d["time"] = np.arange(
            len(d),
            dtype=float
        )

    # --------------------------------------------------------
    # Remove invalid rows
    # --------------------------------------------------------

    d = d.dropna(
        subset=[
            "voltage",
            "current",
            "temperature",
            "time",
        ]
    )

    if len(d) < 3:
        return None

    return calculate_common_features(
        d["voltage"].to_numpy(float),
        d["current"].to_numpy(float),
        d["temperature"].to_numpy(float),
        d["time"].to_numpy(float),
    )


# ============================================================
# REAL-TIME COMPLETE-CYCLE FEATURES
# ============================================================

def realtime_features(history):

    """
    Convert a COMPLETE Arduino discharge cycle into
    the same 15 features used by the ML model.

    Arduino provides:

        cell1_voltage
        cell2_voltage
        pack_voltage
        current
        temperature

    The ML model uses:

        average cell voltage
        current
        temperature
        duration

    Average cell voltage is used because the NASA training
    data is cell/terminal-voltage based, not 2S pack voltage.
    """

    if history is None:
        raise ValueError("History is empty.")

    if len(history) < 3:
        raise ValueError(
            "At least 3 samples are required."
        )

    d = pd.DataFrame(history)

    required = [
        "cell1_voltage",
        "cell2_voltage",
        "current",
        "temperature",
    ]

    missing = [
        c
        for c in required
        if c not in d.columns
    ]

    if missing:

        raise ValueError(
            "Arduino history missing: "
            f"{missing}"
        )

    # --------------------------------------------------------
    # Numeric conversion
    # --------------------------------------------------------

    for column in required:

        d[column] = pd.to_numeric(
            d[column],
            errors="coerce"
        )

    # --------------------------------------------------------
    # Timestamp
    # --------------------------------------------------------

    if "timestamp" in d.columns:

        d["timestamp"] = pd.to_numeric(
            d["timestamp"],
            errors="coerce"
        )

    else:

        d["timestamp"] = np.arange(
            len(d),
            dtype=float
        )

    # --------------------------------------------------------
    # Average CELL voltage
    # --------------------------------------------------------

    d["voltage"] = (
        d["cell1_voltage"]
        +
        d["cell2_voltage"]
    ) / 2.0

    # --------------------------------------------------------
    # Remove invalid
    # --------------------------------------------------------

    d = d.dropna(
        subset=[
            "voltage",
            "current",
            "temperature",
            "timestamp",
        ]
    )

    if len(d) < 3:
        raise ValueError(
            "Not enough valid samples."
        )

    # --------------------------------------------------------
    # Convert Unix timestamp to seconds
    # --------------------------------------------------------

    t = d["timestamp"].to_numpy(float)

    return calculate_common_features(
        d["voltage"].to_numpy(float),
        d["current"].to_numpy(float),
        d["temperature"].to_numpy(float),
        t,
    )


# ============================================================
# HARDWARE FEATURES
# ============================================================

def hardware_features(history):

    if not history:
        return {}

    d = pd.DataFrame(history)

    result = {}

    # --------------------------------------------------------
    # Latest cell 1
    # --------------------------------------------------------

    if "cell1_voltage" in d.columns:

        values = pd.to_numeric(
            d["cell1_voltage"],
            errors="coerce"
        ).dropna()

        if len(values):

            result["cell1_voltage"] = float(
                values.iloc[-1]
            )

    # --------------------------------------------------------
    # Latest cell 2
    # --------------------------------------------------------

    if "cell2_voltage" in d.columns:

        values = pd.to_numeric(
            d["cell2_voltage"],
            errors="coerce"
        ).dropna()

        if len(values):

            result["cell2_voltage"] = float(
                values.iloc[-1]
            )

    # --------------------------------------------------------
    # Latest pack
    # --------------------------------------------------------

    if "pack_voltage" in d.columns:

        values = pd.to_numeric(
            d["pack_voltage"],
            errors="coerce"
        ).dropna()

        if len(values):

            result["pack_voltage"] = float(
                values.iloc[-1]
            )

    # --------------------------------------------------------
    # Latest current
    # --------------------------------------------------------

    if "current" in d.columns:

        values = pd.to_numeric(
            d["current"],
            errors="coerce"
        ).dropna()

        if len(values):

            result["current"] = float(
                values.iloc[-1]
            )

    # --------------------------------------------------------
    # Latest temperature
    # --------------------------------------------------------

    if "temperature" in d.columns:

        values = pd.to_numeric(
            d["temperature"],
            errors="coerce"
        ).dropna()

        if len(values):

            result["temperature"] = float(
                values.iloc[-1]
            )

    # --------------------------------------------------------
    # Cell imbalance
    # --------------------------------------------------------

    if (
        "cell1_voltage" in d.columns
        and
        "cell2_voltage" in d.columns
    ):

        c1 = pd.to_numeric(
            d["cell1_voltage"],
            errors="coerce"
        )

        c2 = pd.to_numeric(
            d["cell2_voltage"],
            errors="coerce"
        )

        valid = c1.notna() & c2.notna()

        if valid.any():

            result["cell_imbalance"] = float(
                abs(
                    c1[valid].iloc[-1]
                    -
                    c2[valid].iloc[-1]
                )
            )

    # --------------------------------------------------------
    # Power
    # --------------------------------------------------------

    if (
        "pack_voltage" in d.columns
        and
        "current" in d.columns
    ):

        v = pd.to_numeric(
            d["pack_voltage"],
            errors="coerce"
        )

        i = pd.to_numeric(
            d["current"],
            errors="coerce"
        )

        valid = v.notna() & i.notna()

        if valid.any():

            result["power_w"] = float(
                v[valid].iloc[-1]
                *
                i[valid].iloc[-1]
            )

    return result


# ============================================================
# FEATURE DATAFRAME
# ============================================================

def feature_dataframe(feature_dict):

    missing = [
        f
        for f in FEATURES
        if f not in feature_dict
    ]

    if missing:

        raise ValueError(
            "Missing model features: "
            f"{missing}"
        )

    return pd.DataFrame(
        [[
            float(feature_dict[f])
            for f in FEATURES
        ]],
        columns=FEATURES
    )


# ============================================================
# VALIDATE
# ============================================================

def validate_features(feature_dict):

    if not isinstance(
        feature_dict,
        dict
    ):

        raise TypeError(
            "Features must be a dictionary."
        )

    missing = [
        f
        for f in FEATURES
        if f not in feature_dict
    ]

    if missing:

        raise ValueError(
            f"Missing features: {missing}"
        )

    for f in FEATURES:

        value = float(
            feature_dict[f]
        )

        if not np.isfinite(value):

            raise ValueError(
                f"Invalid feature: {f}"
            )

    return True


# ============================================================
# TEST
# ============================================================

if __name__ == "__main__":

    print("=" * 60)
    print("FEATURE ENGINEERING TEST")
    print("=" * 60)

    history = []

    for k in range(100):

        history.append(
            {
                "cell1_voltage":
                    4.2 - (k / 100),

                "cell2_voltage":
                    4.19 - (k / 100),

                "pack_voltage":
                    8.39 - (2 * k / 100),

                "current":
                    -1.0,

                "temperature":
                    30.0,

                "timestamp":
                    k * 0.5,
            }
        )

    features = realtime_features(history)

    validate_features(features)

    print("\nGenerated features:\n")

    for key, value in features.items():

        print(
            f"{key:<24}: {value:.6f}"
        )

    print("\nFeature count:", len(features))
    print("Expected:", len(FEATURES))

    print("\nFEATURE TEST PASSED")