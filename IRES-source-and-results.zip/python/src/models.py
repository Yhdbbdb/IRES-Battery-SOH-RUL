# ============================================================
# models.py
# HYBRID BATTERY SOH / RUL MULTI-MODEL + STACKING ENSEMBLE
#
# SOH: 3 selected traditional regression models
# RUL: 2 selected traditional models + CNN-BiLSTM (3 total)
#
#SOH: Random Forest, Bagging Trees and Extra Trees.
#RUL: Bagging Trees, Histogram Gradient Boosting and CNN-BiLSTM.
#
# VALIDATION:
#   Battery-wise GroupKFold
#
# RUL SEQUENCE:
#   20 cycles
#
# TARGET COLUMNS:
#   soh
#   rul
# ============================================================

from pathlib import Path
import json
import warnings
from typing import Any

import joblib
import numpy as np
import pandas as pd

from sklearn.base import clone

from sklearn.ensemble import (
    RandomForestRegressor,
    ExtraTreesRegressor,
    GradientBoostingRegressor,
    HistGradientBoostingRegressor,
    AdaBoostRegressor,
    BaggingRegressor,
    StackingRegressor,
    RandomForestRegressor,
)
from sklearn.tree import DecisionTreeRegressor, ExtraTreeRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.svm import SVR
from sklearn.linear_model import (
    LinearRegression, Ridge, Lasso, ElasticNet, BayesianRidge,
    HuberRegressor, SGDRegressor, TheilSenRegressor, RANSACRegressor
)
from sklearn.neural_network import MLPRegressor
from sklearn.cross_decomposition import PLSRegression
from sklearn.impute import SimpleImputer

from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)

from sklearn.model_selection import GroupKFold

from sklearn.pipeline import make_pipeline

from sklearn.preprocessing import StandardScaler


# ============================================================
# CONFIG
# ============================================================

from config import (
    FEATURES,
    DATASET_CSV,
    MODEL_DIR,
    RESULTS_DIR,
    RANDOM_STATE,
    EOL_SOH
)


warnings.filterwarnings("ignore")


MODEL_DIR = Path(MODEL_DIR)
RESULTS_DIR = Path(RESULTS_DIR)

MODEL_DIR.mkdir(
    parents=True,
    exist_ok=True
)

RESULTS_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ============================================================
# OPTIONAL XGBOOST
# ============================================================

XGBRegressor = None

try:
    from xgboost import XGBRegressor
    HAVE_XGB = True
except ImportError:
    HAVE_XGB = False
    XGBRegressor = None

    print(
        "\nWARNING: XGBoost is not installed."
    )


# ============================================================
# TENSORFLOW
# ============================================================

tf = None
Sequential = None
Input = None
Conv1D = None
BatchNormalization = None
MaxPooling1D = None
Dropout = None
LSTM = None
Bidirectional = None
Dense = None
EarlyStopping = None

try:

    import tensorflow as tf

    from tensorflow.keras import Sequential

    from tensorflow.keras.layers import (
        Input,
        Conv1D,
        BatchNormalization,
        MaxPooling1D,
        Dropout,
        LSTM,
        Bidirectional,
        Dense
    )

    from tensorflow.keras.callbacks import (
        EarlyStopping
    )

    HAVE_TF = True

    tf.keras.utils.set_random_seed(
        RANDOM_STATE
    )

except ImportError:

    HAVE_TF = False
    tf = None
    Sequential = None
    Input = None
    Conv1D = None
    BatchNormalization = None
    MaxPooling1D = None
    Dropout = None
    LSTM = None
    Bidirectional = None
    Dense = None
    EarlyStopping = None

    print(
        "\nWARNING: TensorFlow is not installed."
    )


# ============================================================
# RUL CONFIGURATION
# ============================================================

RUL_SEQUENCE_LENGTH = 20

RUL_EPOCHS = 60

RUL_BATCH_SIZE = 32

RUL_PATIENCE = 10



def model_information():
    """Print the configured SOH/RUL models and saved artifact status."""
    print("\\n" + "=" * 72)
    print("HYBRID BATTERY MODEL INFORMATION")
    print("=" * 72)
    print("SOH models: RandomForest, BaggingTree, ExtraTrees")
    print("RUL models: BaggingTree, HistGradientBoosting, CNN-BiLSTM")
    print("Validation: 5-fold battery-wise GroupKFold")
    print(f"RUL sequence length: {RUL_SEQUENCE_LENGTH} cycles")
    print(f"Feature count: {len(FEATURES)}")
    print(f"Model directory: {MODEL_DIR}")
    print(f"Results directory: {RESULTS_DIR}")
    print("\\nSaved model files:")
    expected = [
        "soh_RandomForest.joblib",
        "soh_BaggingTree.joblib",
        "soh_ExtraTrees.joblib",
        "rul_BaggingTree.joblib",
        "rul_HistGradientBoosting.joblib",
        "rul_CNN_BiLSTM.keras",
    ]
    for filename in expected:
        path = MODEL_DIR / filename
        print(f"  [{'OK' if path.exists() else 'MISSING'}] {filename}")


def train():
    """Run model validation, final fitting, and result export."""

    # ============================================================
    # PRINT HEADER
    # ============================================================

    print()
    print("=" * 80)
    print("HYBRID BATTERY SOH + RUL MODEL TRAINING")
    print("=" * 80)

    print()
    print("SOH Models:")
    print("  1. Random Forest")
    print("  2. Bagging Tree")
    print("  3. Extra Trees")

    print()
    print("RUL Models:")
    print("  1. Bagging Tree")
    print("  2. HistGradientBoosting")
    print("  3. CNN-BiLSTM")

    print()
    print("Validation:")
    print("  Battery-wise GroupKFold")

    print()
    print(
        "RUL sequence length:",
        RUL_SEQUENCE_LENGTH
    )

    print()
    print(
        "Number of features:",
        len(FEATURES)
    )


    # ============================================================
    # METRICS
    # ============================================================

    def calculate_metrics(
        y_true,
        y_pred
    ):

        y_true = np.asarray(
            y_true,
            dtype=float
        )

        y_pred = np.asarray(
            y_pred,
            dtype=float
        )

        valid = (
            np.isfinite(y_true)
            &
            np.isfinite(y_pred)
        )

        y_true = y_true[valid]

        y_pred = y_pred[valid]

        if len(y_true) == 0:

            return {
                "MAE": np.nan,
                "RMSE": np.nan,
                "R2": np.nan
            }

        mae = mean_absolute_error(
            y_true,
            y_pred
        )

        rmse = np.sqrt(
            mean_squared_error(
                y_true,
                y_pred
            )
        )

        if (
            len(y_true) > 1
            and np.std(y_true) > 0
        ):

            r2 = r2_score(
                y_true,
                y_pred
            )

        else:

            r2 = np.nan

        return {

            "MAE": float(mae),

            "RMSE": float(rmse),

            "R2": float(r2)
        }


    # ============================================================
    # MODEL FACTORIES
    # ============================================================

    def build_rf() -> Any:

        return make_pipeline(

            SimpleImputer(
                strategy="median"
            ),

            RandomForestRegressor(

                n_estimators=300,

                max_depth=None,

                min_samples_leaf=2,

                max_features="sqrt",

                n_jobs=-1,

                random_state=RANDOM_STATE
            )
        )


    def build_gb() -> Any:

        return make_pipeline(

            SimpleImputer(
                strategy="median"
            ),

            GradientBoostingRegressor(

                n_estimators=300,

                learning_rate=0.03,

                max_depth=3,

                min_samples_leaf=3,

                subsample=0.85,

                loss="huber",

                random_state=RANDOM_STATE
            )
        )


    def build_stack() -> Any:
        """Stack tree models; outer evaluation remains battery-wise GroupKFold."""
        return StackingRegressor(
            estimators=[
                ("rf", build_rf()),
                ("gb", build_gb()),
            ],
            final_estimator=GradientBoostingRegressor(
                n_estimators=80,
                learning_rate=0.04,
                max_depth=2,
                random_state=RANDOM_STATE,
            ),
            cv=5,
            n_jobs=-1,
            passthrough=False,
        )


    def build_xgb() -> Any | None:

        if not HAVE_XGB:

            return None

        return make_pipeline(

            SimpleImputer(
                strategy="median"
            ),

            XGBRegressor(

                n_estimators=400,

                max_depth=5,

                learning_rate=0.03,

                subsample=0.85,

                colsample_bytree=0.85,

                objective="reg:squarederror",

                random_state=RANDOM_STATE,

                n_jobs=4,

                verbosity=0
            )
        )


    # ============================================================
    # 20-MODEL COMPARISON SUITE
    # ============================================================

    def build_model_suite() -> dict[str, Any]:
        """Return 20 distinct regression candidates with suitable preprocessing."""
        def pipe(estimator, scale=False):
            steps = [SimpleImputer(strategy="median")]
            if scale:
                steps.append(StandardScaler())
            steps.append(estimator)
            return make_pipeline(*steps)

        return {
            "RandomForest": pipe(RandomForestRegressor(n_estimators=250, min_samples_leaf=2, n_jobs=-1, random_state=RANDOM_STATE)),
            "ExtraTrees": pipe(ExtraTreesRegressor(n_estimators=250, min_samples_leaf=2, n_jobs=-1, random_state=RANDOM_STATE)),
            "GradientBoosting": pipe(GradientBoostingRegressor(n_estimators=200, learning_rate=0.04, max_depth=3, random_state=RANDOM_STATE)),
            "HistGradientBoosting": pipe(HistGradientBoostingRegressor(max_iter=200, learning_rate=0.06, max_leaf_nodes=15, random_state=RANDOM_STATE)),
            "AdaBoost": pipe(AdaBoostRegressor(n_estimators=150, learning_rate=0.04, random_state=RANDOM_STATE)),
            "BaggingTree": pipe(BaggingRegressor(n_estimators=100, n_jobs=-1, random_state=RANDOM_STATE)),
            "DecisionTree": pipe(DecisionTreeRegressor(min_samples_leaf=3, random_state=RANDOM_STATE)),
            "ExtraTree": pipe(ExtraTreeRegressor(min_samples_leaf=3, random_state=RANDOM_STATE)),
            "KNN": pipe(KNeighborsRegressor(n_neighbors=5, weights="distance"), scale=True),
            "SVR_RBF": pipe(SVR(kernel="rbf", C=10.0, epsilon=0.1), scale=True),
            "SVR_Linear": pipe(SVR(kernel="linear", C=1.0, epsilon=0.1), scale=True),
            "LinearRegression": pipe(LinearRegression(), scale=True),
            "Ridge": pipe(Ridge(alpha=1.0), scale=True),
            "Lasso": pipe(Lasso(alpha=0.01, max_iter=10000), scale=True),
            "ElasticNet": pipe(ElasticNet(alpha=0.01, l1_ratio=0.5, max_iter=10000), scale=True),
            "BayesianRidge": pipe(BayesianRidge(), scale=True),
            "Huber": pipe(HuberRegressor(max_iter=500), scale=True),
            "SGDRegressor": pipe(SGDRegressor(max_iter=3000, tol=1e-4, random_state=RANDOM_STATE), scale=True),
            "MLP": pipe(MLPRegressor(hidden_layer_sizes=(64, 32), max_iter=700, early_stopping=True, random_state=RANDOM_STATE), scale=True),
            "PLSRegression": pipe(PLSRegression(n_components=2, scale=False), scale=True),
        }


    # ============================================================
    # LOAD DATASET
    # ============================================================

    print()
    print("=" * 80)
    print("LOADING DATASET")
    print("=" * 80)

    print()
    print(
        "Dataset:",
        DATASET_CSV
    )


    df = pd.read_csv(
        DATASET_CSV
    )


    print()
    print(
        "Original dataset shape:",
        df.shape
    )


    # ============================================================
    # CHECK DATASET
    # ============================================================

    required_columns = [

        "battery_id",

        "cycle",

        "soh",

        "rul",

        *FEATURES
    ]


    missing_columns = [

        column

        for column in required_columns

        if column not in df.columns
    ]


    if missing_columns:

        raise ValueError(

            "Missing required columns:\n"

            + "\n".join(
                missing_columns
            )
        )


    print()
    print(
        "All required columns are present."
    )


    # ============================================================
    # CLEAN DATA
    # ============================================================

    df = df.replace(
        [np.inf, -np.inf],
        np.nan
    )


    for column in FEATURES:

        df[column] = pd.to_numeric(

            df[column],

            errors="coerce"
        )


    df["soh"] = pd.to_numeric(
        df["soh"],
        errors="coerce"
    )


    df["rul"] = pd.to_numeric(
        df["rul"],
        errors="coerce"
    )


    df["cycle"] = pd.to_numeric(
        df["cycle"],
        errors="coerce"
    )


    df["battery_id"] = (
        df["battery_id"]
        .astype(str)
    )


    # ============================================================
    # SORT
    # ============================================================

    df = df.sort_values(

        [
            "battery_id",
            "cycle"
        ]

    ).reset_index(
        drop=True
    )


    # ============================================================
    # BASIC INFORMATION
    # ============================================================

    print()
    print(
        "Total samples:",
        len(df)
    )

    print(
        "Battery groups:",
        df["battery_id"].nunique()
    )

    print(
        "SOH valid values:",
        df["soh"].notna().sum()
    )

    print(
        "RUL valid values:",
        df["rul"].notna().sum()
    )


    # ============================================================
    # SOH DATA
    # ============================================================

    soh_df = df.dropna(
        subset=[
            "soh",
            *FEATURES
        ]
    ).copy()


    X_soh = soh_df[
        FEATURES
    ].copy()


    y_soh = soh_df[
        "soh"
    ].to_numpy(
        dtype=float
    )


    groups_soh = soh_df[
        "battery_id"
    ].to_numpy()


    # ============================================================
    # RUL DATA
    # ============================================================

    rul_df = df.dropna(
        subset=[
            "rul",
            *FEATURES
        ]
    ).copy()


    rul_df = rul_df[
        rul_df["rul"] >= 0
    ].copy()


    X_rul = rul_df[
        FEATURES
    ].copy()


    y_rul = rul_df[
        "rul"
    ].to_numpy(
        dtype=float
    )


    groups_rul = rul_df[
        "battery_id"
    ].to_numpy()


    print()
    print(
        "SOH training samples:",
        len(soh_df)
    )

    print(
        "RUL training samples:",
        len(rul_df)
    )


    # ============================================================
    # ============================================================
    # SOH MODEL VALIDATION
    # ============================================================
    # ============================================================

    print()
    print("=" * 80)
    print("SOH 5-FOLD BATTERY-WISE GROUP VALIDATION")
    print("=" * 80)

    if len(np.unique(groups_soh)) < 5:
        raise ValueError(
            "SOH GroupKFold requires at least 5 distinct battery groups."
        )


    all_soh_candidates = build_model_suite()
    soh_models: dict[str, Any] = {
        name: all_soh_candidates[name]
        for name in ("RandomForest", "BaggingTree", "ExtraTrees")
    }
    print(f"SOH candidate models: {len(soh_models)}")


    soh_results = {}


    for model_name, model in soh_models.items():

        print()
        print("-" * 70)

        print(
            "SOH MODEL:",
            model_name
        )

        print("-" * 70)


        fold_metrics = []


        gkf = GroupKFold(
            n_splits=5
        )


        for fold, (
            train_idx,
            val_idx
        ) in enumerate(

            gkf.split(
                X_soh,
                y_soh,
                groups_soh
            ),

            start=1
        ):

            print(
                f"Fold {fold}/5"
            )


            train_groups = set(
                groups_soh[
                    train_idx
                ]
            )

            val_groups = set(
                groups_soh[
                    val_idx
                ]
            )


            if train_groups & val_groups:

                raise RuntimeError(
                    "Battery leakage detected!"
                )


            fold_model = clone(
                model
            )


            fold_model.fit(

                X_soh.iloc[
                    train_idx
                ],

                y_soh[
                    train_idx
                ]
            )


            prediction = fold_model.predict(

                X_soh.iloc[
                    val_idx
                ]
            )


            metrics = calculate_metrics(

                y_soh[
                    val_idx
                ],

                prediction
            )


            fold_metrics.append(
                metrics
            )


            print(
                f"  MAE  = "
                f"{metrics['MAE']:.4f}"
            )

            print(
                f"  RMSE = "
                f"{metrics['RMSE']:.4f}"
            )

            print(
                f"  R2   = "
                f"{metrics['R2']:.4f}"
            )


        soh_results[
            model_name
        ] = {

            "MAE":
                float(
                    np.mean(
                        [
                            x["MAE"]
                            for x in fold_metrics
                        ]
                    )
                ),

            "RMSE":
                float(
                    np.mean(
                        [
                            x["RMSE"]
                            for x in fold_metrics
                        ]
                    )
                ),

            "R2":
                float(
                    np.mean(
                        [
                            x["R2"]
                            for x in fold_metrics
                        ]
                    )
                ),

            "MAE_std":
                float(
                    np.std(
                        [
                            x["MAE"]
                            for x in fold_metrics
                        ]
                    )
                ),

            "RMSE_std":
                float(
                    np.std(
                        [
                            x["RMSE"]
                            for x in fold_metrics
                        ]
                    )
                ),

            "R2_std":
                float(
                    np.std(
                        [
                            x["R2"]
                            for x in fold_metrics
                        ]
                    )
                )
        }


    # ============================================================
    # SELECT SOH
    # ============================================================

    best_soh = min(

        soh_results,

        key=lambda name: (

            soh_results[name]["MAE"],

            soh_results[name]["RMSE"],

            -soh_results[name]["R2"]
        )
    )


    # ============================================================
    # SOH RESULTS
    # ============================================================

    print()
    print("=" * 80)
    print("SOH MODEL COMPARISON")
    print("=" * 80)

    print()

    print(
        f"{'Model':<25}"
        f"{'MAE':>12}"
        f"{'RMSE':>12}"
        f"{'R2':>12}"
    )

    print("-" * 61)


    for result_name, metrics in soh_results.items():

        print(

            f"{result_name:<25}"

            f"{metrics['MAE']:>12.4f}"

            f"{metrics['RMSE']:>12.4f}"

            f"{metrics['R2']:>12.4f}"
        )


    print()
    print(
        "SELECTED SOH MODEL:",
        best_soh
    )


    # ============================================================
    # ============================================================
    # RUL TRADITIONAL MODEL VALIDATION
    # ============================================================
    # ============================================================

    print()
    print("=" * 80)
    print("RUL 5-FOLD BATTERY-WISE GROUP VALIDATION")
    print("=" * 80)

    if len(np.unique(groups_rul)) < 5:
        raise ValueError(
            "RUL GroupKFold requires at least 5 distinct battery groups."
        )


    all_rul_candidates = build_model_suite()
    rul_models: dict[str, Any] = {
        name: all_rul_candidates[name]
        for name in ("BaggingTree", "HistGradientBoosting")
    }
    print(f"RUL traditional candidate models: {len(rul_models)}")
    print("RUL total models including CNN-BiLSTM: 3")


    rul_results = {}


    for model_name, model in rul_models.items():

        print()
        print("-" * 70)

        print(
            "RUL MODEL:",
            model_name
        )

        print("-" * 70)


        fold_metrics = []


        gkf = GroupKFold(
            n_splits=5
        )


        for fold, (
            train_idx,
            val_idx
        ) in enumerate(

            gkf.split(
                X_rul,
                y_rul,
                groups_rul
            ),

            start=1
        ):

            print(
                f"Fold {fold}/5"
            )


            train_groups = set(
                groups_rul[
                    train_idx
                ]
            )

            val_groups = set(
                groups_rul[
                    val_idx
                ]
            )


            if train_groups & val_groups:

                raise RuntimeError(
                    "Battery leakage detected!"
                )


            fold_model = clone(
                model
            )


            fold_model.fit(

                X_rul.iloc[
                    train_idx
                ],

                y_rul[
                    train_idx
                ]
            )


            prediction = fold_model.predict(

                X_rul.iloc[
                    val_idx
                ]
            )


            metrics = calculate_metrics(

                y_rul[
                    val_idx
                ],

                prediction
            )


            fold_metrics.append(
                metrics
            )


            print(
                f"  MAE  = "
                f"{metrics['MAE']:.4f}"
            )

            print(
                f"  RMSE = "
                f"{metrics['RMSE']:.4f}"
            )

            print(
                f"  R2   = "
                f"{metrics['R2']:.4f}"
            )


        rul_results[
            model_name
        ] = {

            "MAE":
                float(
                    np.mean(
                        [
                            x["MAE"]
                            for x in fold_metrics
                        ]
                    )
                ),

            "RMSE":
                float(
                    np.mean(
                        [
                            x["RMSE"]
                            for x in fold_metrics
                        ]
                    )
                ),

            "R2":
                float(
                    np.mean(
                        [
                            x["R2"]
                            for x in fold_metrics
                        ]
                    )
                ),

            "MAE_std":
                float(
                    np.std(
                        [
                            x["MAE"]
                            for x in fold_metrics
                        ]
                    )
                ),

            "RMSE_std":
                float(
                    np.std(
                        [
                            x["RMSE"]
                            for x in fold_metrics
                        ]
                    )
                ),

            "R2_std":
                float(
                    np.std(
                        [
                            x["R2"]
                            for x in fold_metrics
                        ]
                    )
                )
        }


    # ============================================================
    # ============================================================
    # CREATE CNN-BiLSTM SEQUENCES
    # ============================================================
    # ============================================================

    print()
    print("=" * 80)
    print("CREATING RUL CNN-BiLSTM SEQUENCES")
    print("=" * 80)


    def create_sequences(data):

        X_sequences = []

        y_sequences = []

        sequence_groups = []

        sequence_cycles = []


        data = data.sort_values(

            [
                "battery_id",
                "cycle"
            ]

        )


        for battery_id, battery_data in data.groupby(

            "battery_id",

            sort=False
        ):

            battery_data = battery_data.sort_values(
                "cycle"
            ).reset_index(
                drop=True
            )


            if len(battery_data) < RUL_SEQUENCE_LENGTH:

                continue


            X_battery = battery_data[
                FEATURES
            ].to_numpy(
                dtype=np.float32
            )


            y_battery = battery_data[
                "rul"
            ].to_numpy(
                dtype=np.float32
            )


            cycles_battery = battery_data[
                "cycle"
            ].to_numpy(
                dtype=np.float32
            )


            for end in range(

                RUL_SEQUENCE_LENGTH - 1,

                len(battery_data)
            ):

                start = (

                    end
                    -
                    RUL_SEQUENCE_LENGTH
                    +
                    1
                )


                X_window = X_battery[
                    start:end + 1
                ]


                target = y_battery[
                    end
                ]


                if not np.isfinite(
                    X_window
                ).all():

                    continue


                if not np.isfinite(
                    target
                ):

                    continue


                X_sequences.append(
                    X_window
                )


                y_sequences.append(
                    target
                )


                sequence_groups.append(
                    battery_id
                )


                sequence_cycles.append(
                    cycles_battery[end]
                )


        if len(X_sequences) == 0:

            raise RuntimeError(

                "No RUL sequences were created."
            )


        return (

            np.asarray(
                X_sequences,
                dtype=np.float32
            ),

            np.asarray(
                y_sequences,
                dtype=np.float32
            ),

            np.asarray(
                sequence_groups
            ),

            np.asarray(
                sequence_cycles
            )
        )


    (
        X_seq,
        y_seq,
        groups_seq,
        cycles_seq
    ) = create_sequences(
        rul_df
    )


    print()
    print(
        "Sequence shape:",
        X_seq.shape
    )

    print(
        "Target shape:",
        y_seq.shape
    )

    print(
        "Sequence battery groups:",
        len(
            np.unique(
                groups_seq
            )
        )
    )


    # ============================================================
    # CNN-BiLSTM ARCHITECTURE
    # ============================================================

    def build_cnn_bilstm(
        n_features
    ):

        model = Sequential([

            Input(
                shape=(
                    RUL_SEQUENCE_LENGTH,
                    n_features
                )
            ),


            Conv1D(

                filters=64,

                kernel_size=3,

                padding="same",

                activation="relu"
            ),


            BatchNormalization(),


            Conv1D(

                filters=128,

                kernel_size=3,

                padding="same",

                activation="relu"
            ),


            BatchNormalization(),


            MaxPooling1D(
                pool_size=2
            ),


            Dropout(
                0.20
            ),


            Bidirectional(

                LSTM(
                    64
                )
            ),


            Dropout(
                0.30
            ),


            Dense(

                64,

                activation="relu"
            ),


            Dropout(
                0.20
            ),


            Dense(

                1,

                activation="linear"
            )
        ])


        model.compile(

            optimizer=tf.keras.optimizers.Adam(

                learning_rate=0.001
            ),

            loss="mse",

            metrics=[
                "mae"
            ]
        )


        return model


    # ============================================================
    # CNN-BiLSTM VALIDATION
    # ============================================================

    cnn_bilstm_metrics = []


    if HAVE_TF:

        print()
        print("=" * 80)
        print("RUL CNN-BiLSTM 5-FOLD VALIDATION")
        print("=" * 80)


        gkf_seq = GroupKFold(
            n_splits=5
        )


        for fold, (
            train_idx,
            val_idx
        ) in enumerate(

            gkf_seq.split(

                X_seq,

                y_seq,

                groups_seq
            ),

            start=1
        ):

            print()
            print("-" * 70)

            print(
                f"CNN-BiLSTM FOLD "
                f"{fold}/5"
            )

            print("-" * 70)


            X_train = X_seq[
                train_idx
            ]

            X_val = X_seq[
                val_idx
            ]


            y_train = y_seq[
                train_idx
            ]

            y_val = y_seq[
                val_idx
            ]


            # ----------------------------------------------------
            # SCALE TRAINING DATA ONLY
            # ----------------------------------------------------

            scaler = StandardScaler()


            n_features = X_train.shape[
                -1
            ]


            X_train_2d = X_train.reshape(

                -1,

                n_features
            )


            X_val_2d = X_val.reshape(

                -1,

                n_features
            )


            scaler.fit(
                X_train_2d
            )


            X_train_scaled = scaler.transform(

                X_train_2d
            ).reshape(
                X_train.shape
            )


            X_val_scaled = scaler.transform(

                X_val_2d
            ).reshape(
                X_val.shape
            )


            # ----------------------------------------------------
            # BUILD MODEL
            # ----------------------------------------------------

            tf.keras.backend.clear_session()


            model = build_cnn_bilstm(

                n_features
            )


            early_stop = EarlyStopping(

                monitor="val_loss",

                patience=RUL_PATIENCE,

                restore_best_weights=True,

                verbose=0
            )


            # ----------------------------------------------------
            # TRAIN
            # ----------------------------------------------------

            model.fit(

                X_train_scaled,

                y_train,

                validation_data=(

                    X_val_scaled,

                    y_val
                ),

                epochs=RUL_EPOCHS,

                batch_size=RUL_BATCH_SIZE,

                callbacks=[
                    early_stop
                ],

                verbose=0
            )


            # ----------------------------------------------------
            # PREDICT
            # ----------------------------------------------------

            prediction = model.predict(

                X_val_scaled,

                verbose=0

            ).reshape(-1)


            metrics = calculate_metrics(

                y_val,

                prediction
            )


            cnn_bilstm_metrics.append(
                metrics
            )


            print(

                f"Fold {fold}: "

                f"MAE="
                f"{metrics['MAE']:.4f}, "

                f"RMSE="
                f"{metrics['RMSE']:.4f}, "

                f"R2="
                f"{metrics['R2']:.4f}"
            )


        # --------------------------------------------------------
        # CNN-BiLSTM AVERAGE
        # --------------------------------------------------------

        cnn_bilstm_result = {

            "MAE":
                float(
                    np.mean(
                        [
                            x["MAE"]
                            for x in cnn_bilstm_metrics
                        ]
                    )
                ),

            "RMSE":
                float(
                    np.mean(
                        [
                            x["RMSE"]
                            for x in cnn_bilstm_metrics
                        ]
                    )
                ),

            "R2":
                float(
                    np.mean(
                        [
                            x["R2"]
                            for x in cnn_bilstm_metrics
                        ]
                    )
                ),

            "MAE_std":
                float(
                    np.std(
                        [
                            x["MAE"]
                            for x in cnn_bilstm_metrics
                        ]
                    )
                ),

            "RMSE_std":
                float(
                    np.std(
                        [
                            x["RMSE"]
                            for x in cnn_bilstm_metrics
                        ]
                    )
                ),

            "R2_std":
                float(
                    np.std(
                        [
                            x["R2"]
                            for x in cnn_bilstm_metrics
                        ]
                    )
                )
        }


        rul_results[
            "CNN-BiLSTM"
        ] = cnn_bilstm_result


    else:

        print()
        print(
            "CNN-BiLSTM skipped:"
            " TensorFlow unavailable."
        )


    # ============================================================
    # RUL MODEL COMPARISON
    # ============================================================

    print()
    print("=" * 80)
    print("FINAL RUL MODEL COMPARISON")
    print("=" * 80)

    print()

    print(

        f"{'Model':<20}"

        f"{'MAE':>12}"

        f"{'RMSE':>12}"

        f"{'R2':>12}"
    )

    print("-" * 56)


    for result_name, metrics in rul_results.items():

        print(

            f"{result_name:<20}"

            f"{metrics['MAE']:>12.4f}"

            f"{metrics['RMSE']:>12.4f}"

            f"{metrics['R2']:>12.4f}"
        )


    # ============================================================
    # SELECT BEST RUL MODEL
    # ============================================================

    best_rul = min(

        rul_results,

        key=lambda name: (

            rul_results[name]["MAE"],

            rul_results[name]["RMSE"],

            -rul_results[name]["R2"]
        )
    )


    print()
    print("=" * 80)
    print(
        "SELECTED RUL MODEL:",
        best_rul
    )
    print("=" * 80)


    # ============================================================
    # TRAIN FINAL SOH MODELS
    # ============================================================

    print()
    print("=" * 80)
    print("TRAINING FINAL SOH MODELS")
    print("=" * 80)


    final_soh_models = {}


    for model_name, model in soh_models.items():

        print()
        print(
            "Training final SOH:",
            model_name
        )


        model.fit(

            X_soh,

            y_soh
        )


        save_path = (

            MODEL_DIR
            /
            f"soh_{model_name}.joblib"
        )


        joblib.dump(

            model,

            save_path
        )


        final_soh_models[
            model_name
        ] = str(
            save_path
        )


        print(
            "Saved:",
            save_path
        )


    # ============================================================
    # TRAIN FINAL TRADITIONAL RUL MODELS
    # ============================================================

    print()
    print("=" * 80)
    print("TRAINING FINAL RUL TRADITIONAL MODELS")
    print("=" * 80)


    for model_name, model in rul_models.items():

        print()
        print(
            "Training final RUL:",
            model_name
        )


        model.fit(

            X_rul,

            y_rul
        )


        save_path = (

            MODEL_DIR
            /
            f"rul_{model_name}.joblib"
        )


        joblib.dump(

            model,

            save_path
        )


        print(
            "Saved:",
            save_path
        )


    # ============================================================
    # TRAIN FINAL CNN-BiLSTM
    # ============================================================

    cnn_model_path = None
    cnn_scaler_path = None
    cnn_metadata_path = None


    if HAVE_TF:

        print()
        print("=" * 80)
        print("TRAINING FINAL CNN-BiLSTM")
        print("=" * 80)


        # --------------------------------------------------------
        # FIT FINAL SCALER ON ALL SEQUENCES
        # --------------------------------------------------------

        n_features = X_seq.shape[
            -1
        ]


        final_scaler = StandardScaler()


        X_seq_2d = X_seq.reshape(

            -1,

            n_features
        )


        final_scaler.fit(
            X_seq_2d
        )


        X_seq_scaled = final_scaler.transform(

            X_seq_2d

        ).reshape(
            X_seq.shape
        )


        # --------------------------------------------------------
        # BUILD FINAL MODEL
        # --------------------------------------------------------

        tf.keras.backend.clear_session()


        final_cnn_bilstm = build_cnn_bilstm(

            n_features
        )


        # --------------------------------------------------------
        # FINAL TRAINING
        # Train on all sequences after cross-validation.
        # No validation_split is used here because model evaluation
        # has already been performed with battery-wise GroupKFold.
        # --------------------------------------------------------

        final_cnn_bilstm.fit(
            X_seq_scaled,
            y_seq,
            epochs=RUL_EPOCHS,
            batch_size=RUL_BATCH_SIZE,
            verbose=1,
            shuffle=True
        )


        # --------------------------------------------------------
        # SAVE MODEL
        # --------------------------------------------------------

        cnn_model_path = (

            MODEL_DIR
            /
            "rul_CNN_BiLSTM.keras"
        )


        cnn_scaler_path = (

            MODEL_DIR
            /
            "rul_CNN_BiLSTM_scaler.joblib"
        )


        cnn_metadata_path = (

            MODEL_DIR
            /
            "rul_CNN_BiLSTM_metadata.json"
        )


        final_cnn_bilstm.save(

            cnn_model_path
        )


        joblib.dump(

            final_scaler,

            cnn_scaler_path
        )


        metadata = {

            "model_type":
                "CNN-BiLSTM",

            "sequence_length":
                RUL_SEQUENCE_LENGTH,

            "n_features":
                len(FEATURES),

            "features":
                list(FEATURES),

            "architecture": [

                "Conv1D 64",

                "BatchNormalization",

                "Conv1D 128",

                "BatchNormalization",

                "MaxPooling1D",

                "Dropout 0.20",

                "Bidirectional LSTM 64",

                "Dropout 0.30",

                "Dense 64 ReLU",

                "Dropout 0.20",

                "Dense 1 Linear"
            ],

            "epochs":
                RUL_EPOCHS,

            "batch_size":
                RUL_BATCH_SIZE,

            "patience":
                RUL_PATIENCE
        }


        with open(

            cnn_metadata_path,

            "w",

            encoding="utf-8"

        ) as file:

            json.dump(

                metadata,

                file,

                indent=4
            )


        print()
        print(
            "CNN-BiLSTM model saved:"
        )

        print(
            cnn_model_path
        )

        print()
        print(
            "CNN-BiLSTM scaler saved:"
        )

        print(
            cnn_scaler_path
        )

        print()
        print(
            "CNN-BiLSTM metadata saved:"
        )

        print(
            cnn_metadata_path
        )


    # ============================================================
    # SAVE MODEL SELECTION RESULTS
    # ============================================================

    results_json = {

        "SOH": {

            "models":
                soh_results,

            "selected_model":
                best_soh
        },

        "RUL": {

            "models":
                rul_results,

            "selected_model":
                best_rul
        },

        "configuration": {

            "validation":
                "5-Fold Battery-wise GroupKFold",

            "rul_sequence_length":
                RUL_SEQUENCE_LENGTH,

            "features":
                list(FEATURES),

            "eol_soh":
                EOL_SOH
        },

        "saved_models": {

            "SOH":
                final_soh_models,

            "RUL": {
                model_name: str(MODEL_DIR / f"rul_{model_name}.joblib")
                for model_name in rul_models
            } | {
                "CNN-BiLSTM": str(cnn_model_path) if cnn_model_path else None
            }
        }
    }


    json_path = (

        RESULTS_DIR
        /
        "model_selection_results.json"
    )


    with open(

        json_path,

        "w",

        encoding="utf-8"

    ) as file:

        json.dump(

            results_json,

            file,

            indent=4
        )


    # ============================================================
    # SAVE CSV
    # ============================================================

    rows = []


    for result_name, metrics in soh_results.items():

        rows.append({

            "Task":
                "SOH",

            "Model":
                result_name,

            "MAE":
                metrics["MAE"],

            "RMSE":
                metrics["RMSE"],

            "R2":
                metrics["R2"]
        })


    for result_name, metrics in rul_results.items():

        rows.append({

            "Task":
                "RUL",

            "Model":
                result_name,

            "MAE":
                metrics["MAE"],

            "RMSE":
                metrics["RMSE"],

            "R2":
                metrics["R2"]
        })


    results_df = pd.DataFrame(
        rows
    )


    csv_path = (

        RESULTS_DIR
        /
        "model_selection_results.csv"
    )


    # Excel or another process may lock the default CSV. If that happens,
    # preserve the training results in a uniquely named file instead of
    # terminating the completed training run.
    try:
        results_df.to_csv(csv_path, index=False)
        print("\nModel comparison CSV saved:", csv_path)
    except PermissionError:
        from datetime import datetime

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        fallback_csv_path = RESULTS_DIR / f"model_selection_results_{timestamp}.csv"
        try:
            results_df.to_csv(fallback_csv_path, index=False)
            print("\nWARNING: The default results CSV is locked or not writable.")
            print("Results saved to fallback CSV:", fallback_csv_path)
            print("Close the original CSV in Excel if you want to overwrite it next time.")
        except (PermissionError, OSError) as exc:
            print("\nWARNING: Could not save the CSV results:", exc)
            print("The model files and JSON results may still have been saved.")
    except OSError as exc:
        print("\nWARNING: Could not save the CSV results:", exc)
        print("The model files and JSON results may still have been saved.")


    # ============================================================
    # FINAL SUMMARY
    # ============================================================

    print()
    print("=" * 80)
    print("FINAL MODEL SUMMARY")
    print("=" * 80)


    print()
    print("SOH")
    print("-" * 40)

    print(
        "Best model:",
        best_soh
    )

    print(
        f"MAE : "
        f"{soh_results[best_soh]['MAE']:.4f}"
    )

    print(
        f"RMSE: "
        f"{soh_results[best_soh]['RMSE']:.4f}"
    )

    print(
        f"R2  : "
        f"{soh_results[best_soh]['R2']:.4f}"
    )


    print()
    print("RUL")
    print("-" * 40)

    print(
        "Best model:",
        best_rul
    )

    print(
        f"MAE : "
        f"{rul_results[best_rul]['MAE']:.4f}"
    )

    print(
        f"RMSE: "
        f"{rul_results[best_rul]['RMSE']:.4f}"
    )

    print(
        f"R2  : "
        f"{rul_results[best_rul]['R2']:.4f}"
    )


    print()
    print("=" * 80)
    print("SAVED RESULTS")
    print("=" * 80)

    print()
    print(
        "JSON:",
        json_path
    )

    print(
        "CSV:",
        csv_path
    )


    print()
    print("=" * 80)
    print("TRAINING COMPLETE")
    print("=" * 80)