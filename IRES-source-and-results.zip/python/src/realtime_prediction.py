# ============================================================
# realtime_prediction.py
# HYBRID BATTERY SOH / RUL REAL-TIME PREDICTION
#
# FINAL REAL-TIME PIPELINE
#
# Arduino
#   -> cell1 voltage
#   -> cell2 voltage
#   -> pack voltage
#   -> current
#   -> temperature
#
#       |
#       v
#
# Battery mode detection
#       |
#       v
# Complete discharge cycle
#       |
#       v
# 15 training features
#       |
#       +----> RandomForest SOH
#       |
#       +----> 20 completed cycles ----> CNN-BiLSTM RUL
#
# IMPORTANT:
# - No missing ML feature is silently filled with zero.
# - SOH is predicted only from a completed real discharge cycle.
# - RUL is predicted only after 20 completed real discharge cycles.
# - The RUL scaler is the scaler saved during training.
# ============================================================

import json
import time
import warnings
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

try:
    from tensorflow.keras.models import load_model
except Exception:
    load_model = None

warnings.filterwarnings("ignore")


# ============================================================
# CONFIG IMPORT
# ============================================================

try:
    from config import (
        MODEL_DIR,
        EOL_SOH,
        REALTIME_ROLLING_WINDOW,
    )
except Exception:
    PROJECT_ROOT = Path(__file__).resolve().parent.parent

    MODEL_DIR = PROJECT_ROOT / "models"
    EOL_SOH = 80.0
    REALTIME_ROLLING_WINDOW = 100


MODEL_DIR = Path(MODEL_DIR)


# ============================================================
# BATTERY CONFIGURATION
# ============================================================

# 2S Li-ion pack.
# These are used only for SOC display / cycle detection.
FULL_CELL_VOLTAGE = 4.20
EMPTY_CELL_VOLTAGE = 2.80

# IMPORTANT:
# 2 x 1200 mAh cells in SERIES = 1200 mAh pack capacity.
# Voltage adds in series; Ah capacity does not.
NOMINAL_CELL_CAPACITY_MAH = 1200.0
NOMINAL_CAPACITY_MAH = NOMINAL_CELL_CAPACITY_MAH

# RUL model was trained using 20-cycle sequences.
SEQUENCE_LENGTH = 20

# Ignore extremely short discharge events.
MIN_CYCLE_SAMPLES = 10

# Current deadband.
CURRENT_DEADBAND_A = 0.05

# ------------------------------------------------------------
# CURRENT SIGN CONVENTION
# ------------------------------------------------------------
#
# Set this according to the Arduino current-sensor convention.
#
# Current positive during DISCHARGE:
#     DISCHARGE_CURRENT_SIGN = +1
#
# Current negative during DISCHARGE:
#     DISCHARGE_CURRENT_SIGN = -1
#
# The previous project code used negative current for discharge.
# Therefore this version keeps -1 as the default.
#
# If your Serial Monitor shows:
#     -1.20 A while the battery is discharging
# keep -1.
#
# If it shows:
#     +1.20 A while discharging
# change to +1.
# ------------------------------------------------------------

DISCHARGE_CURRENT_SIGN = -1


# Start a discharge cycle only after the battery has been
# observed in a charged/recovered state, except for the very
# first cycle.
FULL_SOC_THRESHOLD = 95.0

# Cycle completion threshold.
EMPTY_SOC_THRESHOLD = 0.5

# Require a few consecutive samples near empty before ending
# a cycle. This prevents a single noisy voltage reading from
# ending the cycle.
EMPTY_CONFIRMATION_SAMPLES = 3


# ============================================================
# EXACT 15 FEATURES USED BY THE TRAINING PIPELINE
# ============================================================

FEATURES = [
    "voltage_mean",
    "voltage_min",
    "voltage_max",
    "voltage_std",

    "current_mean",
    "current_abs_mean",
    "current_rms",
    "current_std",

    "temperature_mean",
    "temperature_min",
    "temperature_max",
    "temperature_std",

    "duration_min",

    "power_mean",
    "power_abs_mean",
]


# ============================================================
# MODEL DIRECTORY
# ============================================================

def _find_model_dir():
    """Find the project model directory."""

    here = Path(__file__).resolve()
    project_root = here.parent.parent

    candidates = [
        MODEL_DIR,
        project_root / "models",
        here.parent / "models",
        project_root / "data" / "models",
    ]

    seen = set()

    for candidate in candidates:
        try:
            candidate = candidate.resolve()
        except Exception:
            continue

        if candidate in seen:
            continue

        seen.add(candidate)

        if candidate.exists() and candidate.is_dir():
            return candidate

    return Path(MODEL_DIR)


def _choose_soh_model(model_dir):
    """
    Select the SOH model.

    Current training output contains:
        soh_RandomForest.joblib

    RandomForest is therefore preferred.
    """

    names = [
        "soh_RandomForest.joblib",
        "soh_BaggingTree.joblib",
        "soh_ExtraTrees.joblib",
        "soh_GradientBoosting.joblib",
        "soh_XGBoost.joblib",
    ]

    for name in names:
        path = model_dir / name

        if path.exists():
            return path

    return None


# ============================================================
# PREDICTOR
# ============================================================

class Predictor:

    def __init__(self):

        self.model_dir = _find_model_dir()

        # ----------------------------------------------------
        # Models
        # ----------------------------------------------------

        self.soh_model = None

        self.rul_model = None
        self.rul_scaler = None

        self.metadata = {}

        self.soh_model_file = None
        self.rul_model_file = None

        self.sequence_length = SEQUENCE_LENGTH
        self.features = list(FEATURES)

        # ----------------------------------------------------
        # Live raw samples for the CURRENT discharge cycle
        # ----------------------------------------------------

        self.history = []

        # ----------------------------------------------------
        # Completed-cycle feature vectors
        # Each item has exactly 15 features.
        # ----------------------------------------------------

        self.cycle_history = []

        # ----------------------------------------------------
        # Cycle state
        # ----------------------------------------------------

        self.cycle_number = 0
        self.cycle_active = False
        self.waiting_for_full_charge = False

        self.last_cycle_completed = False

        self.empty_confirmation_count = 0

        # ----------------------------------------------------
        # Charging state
        # ----------------------------------------------------

        self.seen_full_charge = False

        # ----------------------------------------------------
        # Capacity / display
        # ----------------------------------------------------

        self.discharged_capacity_mah = 0.0
        self.remaining_capacity_mah = NOMINAL_CAPACITY_MAH
        self.capacity_ah = 0.0

        self.cycle_capacity_mah = 0.0

        self.last_sample_time = None
        self.last_current = None

        # ----------------------------------------------------
        # Predictions
        # ----------------------------------------------------

        self.last_soh = None
        self.last_rul = None

        self.soh_history = []
        self.rul_history = []

        self.prediction_count = 0

        self.soh_is_real_prediction = False
        self.rul_is_real_prediction = False

        self.last_result = None

        # ----------------------------------------------------
        # Model status
        # ----------------------------------------------------

        self.model_status = {
            "resolved_model_dir": str(self.model_dir),
            "soh_status": "not loaded",
            "rul_status": "not loaded",
        }

        self.load_models()


    # ========================================================
    # MODEL LOADING
    # ========================================================

    def load_models(self):

        # ----------------------------------------------------
        # SOH
        # ----------------------------------------------------

        soh_path = _choose_soh_model(self.model_dir)

        if soh_path is None:

            self.model_status["soh_status"] = (
                "No SOH model found. "
                "Expected soh_RandomForest.joblib."
            )

            print(
                "[WARNING]",
                self.model_status["soh_status"]
            )

        else:

            try:

                self.soh_model = joblib.load(
                    soh_path
                )

                self.soh_model_file = (
                    soh_path.name
                )

                self.model_status["soh_status"] = (
                    f"[OK] loaded {soh_path.name}"
                )

                print(
                    "[OK] SOH model:",
                    soh_path
                )

            except Exception as exc:

                self.model_status["soh_status"] = (
                    f"[ERROR] {exc}"
                )

                print(
                    "[ERROR] SOH model:",
                    exc
                )

        # ----------------------------------------------------
        # RUL CNN-BiLSTM
        # ----------------------------------------------------

        rul_path = (
            self.model_dir
            / "rul_CNN_BiLSTM.keras"
        )

        scaler_path = (
            self.model_dir
            / "rul_CNN_BiLSTM_scaler.joblib"
        )

        metadata_path = (
            self.model_dir
            / "rul_CNN_BiLSTM_metadata.json"
        )

        if not rul_path.exists():

            self.model_status["rul_status"] = (
                f"RUL model not found: {rul_path}"
            )

            print(
                "[WARNING]",
                self.model_status["rul_status"]
            )

        elif load_model is None:

            self.model_status["rul_status"] = (
                "TensorFlow/Keras is not available."
            )

            print(
                "[WARNING]",
                self.model_status["rul_status"]
            )

        else:

            try:

                self.rul_model = load_model(
                    rul_path
                )

                self.rul_model_file = (
                    rul_path.name
                )

                if not scaler_path.exists():

                    raise FileNotFoundError(
                        "RUL scaler not found: "
                        f"{scaler_path}"
                    )

                self.rul_scaler = joblib.load(
                    scaler_path
                )

                if not metadata_path.exists():

                    raise FileNotFoundError(
                        "RUL metadata not found: "
                        f"{metadata_path}"
                    )

                with open(
                    metadata_path,
                    "r",
                    encoding="utf-8",
                ) as file:

                    self.metadata = json.load(
                        file
                    )

                self.sequence_length = int(
                    self.metadata.get(
                        "sequence_length",
                        SEQUENCE_LENGTH,
                    )
                )

                metadata_features = (
                    self.metadata.get(
                        "features"
                    )
                )

                if metadata_features:

                    self.features = list(
                        metadata_features
                    )

                # ------------------------------------------------
                # HARD VALIDATION
                # ------------------------------------------------

                if self.features != FEATURES:

                    raise ValueError(
                        "RUL metadata feature order does not "
                        "match the 15-feature training schema.\n"
                        f"Expected: {FEATURES}\n"
                        f"Found:    {self.features}"
                    )

                if self.sequence_length != SEQUENCE_LENGTH:

                    raise ValueError(
                        "RUL sequence length mismatch. "
                        f"Expected {SEQUENCE_LENGTH}, "
                        f"found {self.sequence_length}."
                    )

                self.model_status["rul_status"] = (
                    f"[OK] loaded {rul_path.name}"
                )

                print(
                    "[OK] RUL model:",
                    rul_path
                )

                print(
                    "[OK] RUL scaler:",
                    scaler_path
                )

                print(
                    "[OK] RUL sequence length:",
                    self.sequence_length
                )

            except Exception as exc:

                self.rul_model = None
                self.rul_scaler = None

                self.model_status["rul_status"] = (
                    f"[ERROR] {exc}"
                )

                print(
                    "[ERROR] RUL model:",
                    exc
                )


    # ========================================================
    # RESET
    # ========================================================

    def reset(self):

        self.history = []
        self.cycle_history = []

        self.cycle_number = 0

        self.cycle_active = False
        self.waiting_for_full_charge = False

        self.last_cycle_completed = False

        self.empty_confirmation_count = 0

        self.seen_full_charge = False

        self.discharged_capacity_mah = 0.0
        self.remaining_capacity_mah = (
            NOMINAL_CAPACITY_MAH
        )

        self.capacity_ah = 0.0
        self.cycle_capacity_mah = 0.0

        self.last_sample_time = None
        self.last_current = None

        self.last_soh = None
        self.last_rul = None

        self.soh_history = []
        self.rul_history = []

        self.prediction_count = 0

        self.soh_is_real_prediction = False
        self.rul_is_real_prediction = False

        self.last_result = None


    reset_history = reset


    # ========================================================
    # SOC
    # ========================================================

    @staticmethod
    def calculate_soc(cell_voltage):

        span = (
            FULL_CELL_VOLTAGE
            - EMPTY_CELL_VOLTAGE
        )

        if span <= 0:
            return 0.0

        soc = (
            (
                float(cell_voltage)
                - EMPTY_CELL_VOLTAGE
            )
            / span
        ) * 100.0

        return float(
            np.clip(
                soc,
                0.0,
                100.0,
            )
        )


    # ========================================================
    # CAPACITY DISPLAY
    # ========================================================

    def calculate_capacity(self, soc):

        discharged_fraction = (
            100.0 - float(soc)
        ) / 100.0

        discharged_fraction = float(
            np.clip(
                discharged_fraction,
                0.0,
                1.0,
            )
        )

        self.discharged_capacity_mah = (
            NOMINAL_CAPACITY_MAH
            * discharged_fraction
        )

        self.remaining_capacity_mah = max(
            0.0,
            NOMINAL_CAPACITY_MAH
            - self.discharged_capacity_mah,
        )

        self.capacity_ah = (
            self.discharged_capacity_mah
            / 1000.0
        )


    # ========================================================
    # CURRENT MODE
    # ========================================================

    @staticmethod
    def _mode_from_current(current):

        current = float(current)

        if abs(current) < CURRENT_DEADBAND_A:
            return "IDLE"

        # Default project convention:
        # negative current = discharge
        if DISCHARGE_CURRENT_SIGN < 0:

            if current <= -CURRENT_DEADBAND_A:
                return "DISCHARGING"

            if current >= CURRENT_DEADBAND_A:
                return "CHARGING"

        else:

            if current >= CURRENT_DEADBAND_A:
                return "DISCHARGING"

            if current <= -CURRENT_DEADBAND_A:
                return "CHARGING"

        return "IDLE"


    # ========================================================
    # MODEL FEATURE NAMES
    # ========================================================

    @staticmethod
    def _model_feature_names(model):

        names = getattr(
            model,
            "feature_names_in_",
            None,
        )

        if names is not None:
            return list(names)

        named_steps = getattr(
            model,
            "named_steps",
            None,
        )

        if named_steps:

            for step in reversed(
                list(named_steps.values())
            ):

                names = getattr(
                    step,
                    "feature_names_in_",
                    None,
                )

                if names is not None:
                    return list(names)

        return None


    # ========================================================
    # STRICT SOH FEATURE ALIGNMENT
    # ========================================================

    def _align_soh_features(self, features):

        if self.soh_model is None:

            raise RuntimeError(
                "SOH model is not loaded."
            )

        model_names = (
            self._model_feature_names(
                self.soh_model
            )
        )

        if model_names is None:

            model_names = list(
                FEATURES
            )

        # ----------------------------------------------------
        # Never silently insert missing values.
        # ----------------------------------------------------

        missing = [
            name
            for name in model_names
            if name not in features
        ]

        if missing:

            raise ValueError(
                "SOH feature generation is incomplete. "
                f"Missing: {missing}"
            )

        unknown = [
            name
            for name in model_names
            if name not in FEATURES
        ]

        if unknown:

            raise ValueError(
                "SOH model expects features outside the "
                "current 15-feature schema: "
                f"{unknown}"
            )

        row = {
            name: float(features[name])
            for name in model_names
        }

        return pd.DataFrame(
            [row],
            columns=model_names,
        )


    # ========================================================
    # CYCLE FEATURE EXTRACTION
    # ========================================================

    def extract_cycle_features(self):

        if len(self.history) < MIN_CYCLE_SAMPLES:

            return None

        df = pd.DataFrame(
            self.history
        )

        # Average of the two cell voltages is used as
        # the cycle voltage feature.
        voltage = (
            df["cell1_voltage"].astype(float)
            + df["cell2_voltage"].astype(float)
        ) / 2.0

        current = (
            df["current"].astype(float)
        )

        temperature = (
            df["temperature"].astype(float)
        )

        # Training power is based on the measured cell terminal
        # voltage. Keep the live feature on the same basis; using
        # 2S pack voltage here would approximately double power.
        power = voltage * current

        timestamps = (
            df["timestamp"].astype(float)
        )

        duration_min = 0.0

        if len(timestamps) >= 2:

            duration_min = max(
                0.0,
                (
                    timestamps.iloc[-1]
                    - timestamps.iloc[0]
                )
                / 60.0,
            )

        features = {

            "voltage_mean":
                float(voltage.mean()),

            "voltage_min":
                float(voltage.min()),

            "voltage_max":
                float(voltage.max()),

            "voltage_std":
                float(
                    voltage.std(
                        ddof=0
                    )
                ),

            "current_mean":
                float(current.mean()),

            "current_abs_mean":
                float(
                    current.abs().mean()
                ),

            "current_rms":
                float(
                    np.sqrt(
                        np.mean(
                            np.square(
                                current
                            )
                        )
                    )
                ),

            "current_std":
                float(
                    current.std(
                        ddof=0
                    )
                ),

            "temperature_mean":
                float(
                    temperature.mean()
                ),

            "temperature_min":
                float(
                    temperature.min()
                ),

            "temperature_max":
                float(
                    temperature.max()
                ),

            "temperature_std":
                float(
                    temperature.std(
                        ddof=0
                    )
                ),

            "duration_min":
                float(duration_min),

            "power_mean":
                float(power.mean()),

            "power_abs_mean":
                float(
                    power.abs().mean()
                ),
        }

        # ----------------------------------------------------
        # Hard schema check.
        # ----------------------------------------------------

        missing = [
            feature
            for feature in FEATURES
            if feature not in features
        ]

        if missing:

            raise RuntimeError(
                "Cycle feature extraction failed. "
                f"Missing features: {missing}"
            )

        return {
            feature: float(
                features[feature]
            )
            for feature in FEATURES
        }


    # ========================================================
    # SOH PREDICTION
    # ========================================================

    def predict_soh(self, features):

        self.soh_is_real_prediction = False

        if self.soh_model is None:

            return None

        try:

            X = self._align_soh_features(
                features
            )

            prediction = (
                self.soh_model.predict(X)
            )

            soh = float(
                np.asarray(
                    prediction
                ).reshape(-1)[0]
            )

            soh = float(
                np.clip(
                    soh,
                    0.0,
                    100.0,
                )
            )

            self.last_soh = soh

            self.soh_is_real_prediction = True

            return soh

        except Exception as exc:

            self.model_status[
                "soh_status"
            ] = (
                "[ERROR during prediction] "
                f"{exc}"
            )

            print(
                "[ERROR] SOH prediction:",
                exc
            )

            return None


    # ========================================================
    # RUL PREDICTION
    # ========================================================

    def predict_rul(self):

        self.rul_is_real_prediction = False

        if (
            self.rul_model is None
            or self.rul_scaler is None
        ):

            return None

        if (
            len(self.cycle_history)
            < self.sequence_length
        ):

            return None

        try:

            sequence = np.asarray(
                self.cycle_history[
                    -self.sequence_length:
                ],
                dtype=np.float32,
            )

            expected_shape = (
                self.sequence_length,
                len(self.features),
            )

            if sequence.shape != expected_shape:

                raise ValueError(
                    "Invalid RUL sequence shape. "
                    f"Expected {expected_shape}, "
                    f"got {sequence.shape}."
                )

            # ------------------------------------------------
            # IMPORTANT:
            # The training pipeline scaled the flattened
            # 20 x 15 sequence, then reshaped it to
            # 20 x 15 before feeding the CNN-BiLSTM.
            # ------------------------------------------------

            sequence_2d = sequence.reshape(
                -1,
                len(self.features),
            )

            scaled_2d = (
                self.rul_scaler.transform(
                    sequence_2d
                )
            )

            scaled_sequence = (
                scaled_2d.reshape(
                    1,
                    self.sequence_length,
                    len(self.features),
                )
            )

            prediction = (
                self.rul_model.predict(
                    scaled_sequence,
                    verbose=0,
                )
            )

            rul = float(
                np.asarray(
                    prediction
                ).reshape(-1)[0]
            )

            rul = max(
                0.0,
                rul,
            )

            self.last_rul = rul

            self.rul_is_real_prediction = True

            return rul

        except Exception as exc:

            self.model_status[
                "rul_status"
            ] = (
                "[ERROR during prediction] "
                f"{exc}"
            )

            print(
                "[ERROR] RUL prediction:",
                exc
            )

            return None


    # ========================================================
    # COMPLETE CYCLE
    # ========================================================

    def _complete_cycle(self):

        features = (
            self.extract_cycle_features()
        )

        if features is None:

            print(
                "[WARNING] Cycle ended with too few samples."
            )

            return None

        # ----------------------------------------------------
        # SOH
        # ----------------------------------------------------

        soh = self.predict_soh(
            features
        )

        # ----------------------------------------------------
        # Store exactly 15 features.
        # ----------------------------------------------------

        vector = [
            float(features[name])
            for name in self.features
        ]

        self.cycle_history.append(
            vector
        )

        # Keep only the latest 20 cycles.
        self.cycle_history = (
            self.cycle_history[
                -self.sequence_length:
            ]
        )

        # ----------------------------------------------------
        # RUL
        # ----------------------------------------------------

        rul = self.predict_rul()

        if soh is not None:

            self.soh_history.append(
                soh
            )

        if rul is not None:

            self.rul_history.append(
                rul
            )

        self.prediction_count += 1

        print()
        print("=" * 70)
        print(
            f"COMPLETED DISCHARGE CYCLE "
            f"{self.cycle_number}"
        )
        print("=" * 70)

        print(
            "Samples:",
            len(self.history)
        )

        print(
            "Completed cycles available:",
            len(self.cycle_history)
        )

        if soh is not None:

            print(
                f"SOH: {soh:.2f}%"
            )

        else:

            print(
                "SOH: unavailable"
            )

        if rul is not None:

            print(
                f"RUL: {rul:.2f} cycles"
            )

        else:

            print(
                "RUL: waiting for "
                f"{self.sequence_length} "
                "completed cycles"
            )

        print("=" * 70)

        return (
            soh,
            rul,
            features,
        )


    # ========================================================
    # LIVE SAMPLE UPDATE
    # ========================================================

    def update(self, sample):

        if sample is None:
            return None

        now = time.time()

        required = [
            "cell1_voltage",
            "cell2_voltage",
            "pack_voltage",
            "current",
            "temperature",
        ]

        try:

            values = {
                key: float(sample[key])
                for key in required
            }

        except Exception as exc:

            raise ValueError(
                "Invalid Arduino sample: "
                f"{exc}"
            )

        if not all(
            np.isfinite(value)
            for value in values.values()
        ):

            raise ValueError(
                "Arduino sample contains "
                "NaN or infinity."
            )

        cell1 = values[
            "cell1_voltage"
        ]

        cell2 = values[
            "cell2_voltage"
        ]

        pack = values[
            "pack_voltage"
        ]

        current = values[
            "current"
        ]

        temperature = values[
            "temperature"
        ]

        # ----------------------------------------------------
        # Basic sensor sanity checks.
        # ----------------------------------------------------

        if not (
            0.0
            < cell1
            < 5.0
        ):

            raise ValueError(
                f"Invalid cell 1 voltage: {cell1}"
            )

        if not (
            0.0
            < cell2
            < 5.0
        ):

            raise ValueError(
                f"Invalid cell 2 voltage: {cell2}"
            )

        if not (
            0.0
            < pack
            < 10.0
        ):

            raise ValueError(
                f"Invalid pack voltage: {pack}"
            )

        # ----------------------------------------------------
        # SOC
        # ----------------------------------------------------

        average_cell = (
            cell1 + cell2
        ) / 2.0

        soc = self.calculate_soc(
            average_cell
        )

        self.calculate_capacity(
            soc
        )

        # ----------------------------------------------------
        # Battery mode
        # ----------------------------------------------------

        mode = self._mode_from_current(
            current
        )

        # ----------------------------------------------------
        # Full-charge detection
        # ----------------------------------------------------

        if (
            mode in ("CHARGING", "IDLE")
            and soc >= FULL_SOC_THRESHOLD
        ):

            self.seen_full_charge = True

            # A completed cycle can now be followed
            # by another discharge cycle.
            if self.waiting_for_full_charge:

                self.waiting_for_full_charge = False

        # ----------------------------------------------------
        # Start first / next discharge cycle
        # ----------------------------------------------------

        can_start_cycle = (
            not self.cycle_active
            and not self.waiting_for_full_charge
        )

        if (
            mode == "DISCHARGING"
            and can_start_cycle
        ):

            # First cycle:
            # allow start immediately.
            #
            # Later cycles:
            # require the battery to have been
            # charged/recovered.
            if (
                self.cycle_number == 0
                or self.seen_full_charge
            ):

                self.cycle_active = True

                self.last_cycle_completed = False

                self.empty_confirmation_count = 0

                self.history = []

                self.cycle_capacity_mah = 0.0

                self.cycle_number += 1

                # Once a new discharge starts, the
                # full-charge flag has been consumed.
                self.seen_full_charge = False

        # ----------------------------------------------------
        # Collect current-cycle samples
        # ----------------------------------------------------

        if (
            self.cycle_active
            and mode == "DISCHARGING"
        ):

            self.history.append(
                {
                    "timestamp": now,

                    "cell1_voltage":
                        cell1,

                    "cell2_voltage":
                        cell2,

                    "pack_voltage":
                        pack,

                    "current":
                        current,

                    "temperature":
                        temperature,
                }
            )

            # ------------------------------------------------
            # Coulomb-counting capacity for the current
            # discharge cycle.
            #
            # This is a hardware display quantity.
            # It is NOT one of the 15 ML features.
            # ------------------------------------------------

            if (
                self.last_sample_time is not None
                and self.last_current is not None
            ):

                dt = (
                    now
                    - self.last_sample_time
                )

                if (
                    dt > 0.0
                    and dt < 10.0
                ):

                    avg_current = (
                        abs(self.last_current)
                        + abs(current)
                    ) / 2.0

                    delta_mah = (
                        avg_current
                        * dt
                        / 3600.0
                        * 1000.0
                    )

                    self.cycle_capacity_mah += (
                        delta_mah
                    )

            self.discharged_capacity_mah = (
                self.cycle_capacity_mah
            )

            self.remaining_capacity_mah = max(
                0.0,
                NOMINAL_CAPACITY_MAH
                - self.cycle_capacity_mah,
            )

            self.capacity_ah = (
                self.cycle_capacity_mah
                / 1000.0
            )

        # ----------------------------------------------------
        # Empty confirmation
        # ----------------------------------------------------

        if (
            self.cycle_active
            and mode == "DISCHARGING"
            and soc <= EMPTY_SOC_THRESHOLD
        ):

            self.empty_confirmation_count += 1

        elif (
            self.cycle_active
            and soc > EMPTY_SOC_THRESHOLD
        ):

            self.empty_confirmation_count = 0

        # ----------------------------------------------------
        # Complete the cycle
        # ----------------------------------------------------

        cycle_finished = (
            self.cycle_active
            and
            len(self.history)
            >= MIN_CYCLE_SAMPLES
            and
            self.empty_confirmation_count
            >= EMPTY_CONFIRMATION_SAMPLES
        )

        if cycle_finished:

            prediction = (
                self._complete_cycle()
            )

            soh = None
            rul = None

            if prediction is not None:

                soh, rul, _ = prediction

            self.cycle_active = False

            self.waiting_for_full_charge = True

            self.last_cycle_completed = True

            self.empty_confirmation_count = 0

            result = self._build_result(
                values=values,
                soc=soc,
                mode=mode,
                soh=soh,
                rul=rul,
                now=now,
            )

            self.last_result = result

            self.last_sample_time = now
            self.last_current = current

            return result

        # ----------------------------------------------------
        # Live state
        # ----------------------------------------------------

        # The last completed-cycle SOH/RUL remains visible.
        # RUL stays None until 20 completed cycles exist.
        soh = self.last_soh
        rul = self.last_rul

        result = self._build_result(
            values=values,
            soc=soc,
            mode=mode,
            soh=soh,
            rul=rul,
            now=now,
        )

        self.last_result = result

        self.last_sample_time = now
        self.last_current = current

        return result


    # ========================================================
    # RESULT
    # ========================================================

    def _build_result(
        self,
        values,
        soc,
        mode,
        soh,
        rul,
        now,
    ):

        # ----------------------------------------------------
        # Progress
        # ----------------------------------------------------

        if mode == "CHARGING":

            progress = soc

        else:

            progress = 100.0 - soc

        progress = float(
            np.clip(
                progress,
                0.0,
                100.0,
            )
        )

        # ----------------------------------------------------
        # Health status
        # ----------------------------------------------------

        if soh is None:

            health_status = (
                "Waiting for completed "
                "discharge cycle"
            )

        elif soh <= EOL_SOH:

            health_status = (
                "EOL / Below Threshold"
            )

        else:

            health_status = (
                "Healthy / Above Threshold"
            )

        # ----------------------------------------------------
        # RUL status
        # ----------------------------------------------------

        if rul is not None:

            rul_status = (
                "Real CNN-BiLSTM prediction"
            )

        else:

            remaining_cycles = max(
                0,
                self.sequence_length
                - len(self.cycle_history)
            )

            rul_status = (
                "Waiting for "
                f"{remaining_cycles} more "
                "completed cycle(s)"
            )

        return {

            "timestamp":
                float(now),

            "cell1_voltage":
                float(values["cell1_voltage"]),

            "cell2_voltage":
                float(values["cell2_voltage"]),

            "pack_voltage":
                float(values["pack_voltage"]),

            "current":
                float(values["current"]),

            "temperature":
                float(values["temperature"]),

            "soc":
                float(soc),

            "nominal_capacity_mah":
                float(NOMINAL_CAPACITY_MAH),

            "discharged_capacity_mah":
                float(
                    self.discharged_capacity_mah
                ),

            "remaining_capacity_mah":
                float(
                    self.remaining_capacity_mah
                ),

            "capacity_ah":
                float(
                    self.capacity_ah
                ),

            "soh":
                (
                    float(soh)
                    if soh is not None
                    else None
                ),

            "rul":
                (
                    float(rul)
                    if rul is not None
                    else None
                ),

            "soh_is_real_prediction":
                bool(
                    self.soh_is_real_prediction
                ),

            "rul_is_real_prediction":
                bool(
                    self.rul_is_real_prediction
                ),

            "cycle_number":
                int(self.cycle_number),

            "cycle_progress":
                progress,

            "battery_mode":
                mode,

            "last_cycle_completed":
                bool(
                    self.last_cycle_completed
                ),

            "prediction_count":
                int(self.prediction_count),

            "cell_imbalance":
                float(
                    abs(
                        values["cell1_voltage"]
                        - values["cell2_voltage"]
                    )
                ),

            "power_w":
                float(
                    values["pack_voltage"]
                    * values["current"]
                ),

            "health_status":
                health_status,

            "rul_status":
                rul_status,

            "eol_threshold":
                float(EOL_SOH),

            "ready":
                bool(
                    self.soh_model is not None
                    or
                    self.rul_model is not None
                ),

            "cycles_available":
                len(self.cycle_history),

            "cycles_required_for_RUL":
                int(self.sequence_length),

            "SOH_model":
                self.soh_model_file
                or "Not loaded",

            "RUL_model":
                self.rul_model_file
                or "CNN-BiLSTM not loaded",

            "model_status":
                dict(self.model_status),
        }


    # ========================================================
    # ADD A COMPLETE CYCLE MANUALLY
    # ========================================================

    def add_cycle(self, features):

        if not isinstance(
            features,
            dict,
        ):

            raise TypeError(
                "features must be a dictionary."
            )

        missing = [
            feature
            for feature in FEATURES
            if feature not in features
        ]

        if missing:

            raise ValueError(
                "Complete cycle is missing "
                f"features: {missing}"
            )

        clean = {
            feature: float(
                features[feature]
            )
            for feature in FEATURES
        }

        vector = [
            clean[name]
            for name in self.features
        ]

        self.cycle_history.append(
            vector
        )

        self.cycle_history = (
            self.cycle_history[
                -self.sequence_length:
            ]
        )

        self.cycle_number += 1

        soh = self.predict_soh(
            clean
        )

        rul = self.predict_rul()

        if soh is not None:
            self.soh_history.append(soh)

        if rul is not None:
            self.rul_history.append(rul)

        self.prediction_count += 1

        self.last_cycle_completed = True

        return self._prediction_summary(
            soh,
            rul,
        )


    def _prediction_summary(
        self,
        soh,
        rul,
    ):

        return {

            "SOH_percent":
                (
                    round(
                        float(soh),
                        2,
                    )
                    if soh is not None
                    else None
                ),

            "RUL_cycles":
                (
                    round(
                        float(rul),
                        2,
                    )
                    if rul is not None
                    else None
                ),

            "cycles_used":
                len(self.cycle_history),

            "SOH_model":
                self.soh_model_file
                or "Not loaded",

            "RUL_model":
                self.rul_model_file
                or "CNN-BiLSTM not loaded",

            "SOH_is_real":
                bool(
                    self.soh_is_real_prediction
                ),

            "RUL_is_real":
                bool(
                    self.rul_is_real_prediction
                ),
        }


    # ========================================================
    # HISTORY ACCESS
    # ========================================================

    def cycles_available(self):

        return len(
            self.cycle_history
        )


    def get_cycle_history(self):

        return list(
            self.cycle_history
        )


    def get_soh_history(self):

        return list(
            self.soh_history
        )


    def get_rul_history(self):

        return list(
            self.rul_history
        )


    # ========================================================
    # CURRENT RAW FEATURES
    # ========================================================

    def current_features(self):

        if not self.history:

            return None

        rows = []

        for item in self.history:

            rows.append(
                {
                    "voltage":
                        (
                            item[
                                "cell1_voltage"
                            ]
                            +
                            item[
                                "cell2_voltage"
                            ]
                        ) / 2.0,

                    "current":
                        item["current"],

                    "temperature":
                        item["temperature"],

                    "time":
                        item["timestamp"],
                }
            )

        return pd.DataFrame(
            rows
        )


# ============================================================
# BACKWARD COMPATIBILITY
# ============================================================

RealtimeBatteryPredictor = Predictor


# ============================================================
# MANUAL PREDICTION
# ============================================================

def manual_prediction(
    cell1_voltage,
    cell2_voltage,
    pack_voltage,
    current,
    temperature,
    cycle_index=1,
    samples=30,
):
    """
    Manual prediction compatible with main.py.

    IMPORTANT:
    A single manual measurement is NOT a complete discharge
    cycle. Therefore:

    - SOH can be calculated as a model input diagnostic, but
      it is not equivalent to a real completed-cycle prediction.
    - CNN-BiLSTM RUL is NOT generated from one measurement.
    - RUL remains None until 20 real cycle vectors exist.

    This function intentionally does NOT create fake repeated
    samples and does NOT claim a fake RUL prediction.
    """

    del samples

    predictor = Predictor()

    try:

        cell1 = float(cell1_voltage)
        cell2 = float(cell2_voltage)
        pack = float(pack_voltage)
        current_value = float(current)
        temp = float(temperature)
        cycle_index = int(cycle_index)

    except Exception as exc:

        raise ValueError(
            "Invalid manual input: "
            f"{exc}"
        )

    if cycle_index < 1:

        raise ValueError(
            "cycle_index must be >= 1."
        )

    values = [
        cell1,
        cell2,
        pack,
        current_value,
        temp,
    ]

    if not all(
        np.isfinite(value)
        for value in values
    ):

        raise ValueError(
            "Manual input contains "
            "NaN or infinity."
        )

    average_cell = (
        cell1 + cell2
    ) / 2.0

    soc = predictor.calculate_soc(
        average_cell
    )

    predictor.calculate_capacity(
        soc
    )

    power = (
        pack
        * current_value
    )

    # --------------------------------------------------------
    # One-measurement diagnostic vector.
    #
    # This matches the feature schema but does NOT represent
    # a complete discharge cycle.
    # --------------------------------------------------------

    features = {

        "voltage_mean":
            average_cell,

        "voltage_min":
            average_cell,

        "voltage_max":
            average_cell,

        "voltage_std":
            0.0,

        "current_mean":
            current_value,

        "current_abs_mean":
            abs(current_value),

        "current_rms":
            abs(current_value),

        "current_std":
            0.0,

        "temperature_mean":
            temp,

        "temperature_min":
            temp,

        "temperature_max":
            temp,

        "temperature_std":
            0.0,

        "duration_min":
            0.0,

        "power_mean":
            power,

        "power_abs_mean":
            abs(power),
    }

    # --------------------------------------------------------
    # SOH diagnostic model prediction
    # --------------------------------------------------------

    soh = predictor.predict_soh(
        features
    )

    # Do NOT generate fake RUL.
    rul = None

    return {

        "timestamp":
            time.time(),

        "cell1_voltage":
            cell1,

        "cell2_voltage":
            cell2,

        "pack_voltage":
            pack,

        "current":
            current_value,

        "temperature":
            temp,

        "soc":
            float(soc),

        "nominal_capacity_mah":
            float(
                NOMINAL_CAPACITY_MAH
            ),

        "discharged_capacity_mah":
            float(
                predictor.discharged_capacity_mah
            ),

        "remaining_capacity_mah":
            float(
                predictor.remaining_capacity_mah
            ),

        "capacity_ah":
            float(
                predictor.capacity_ah
            ),

        "soh":
            (
                float(soh)
                if soh is not None
                else None
            ),

        "rul":
            None,

        "soh_is_real_prediction":
            bool(
                predictor.soh_is_real_prediction
            ),

        "rul_is_real_prediction":
            False,

        "cycle_number":
            cycle_index,

        "cycle_progress":
            float(
                np.clip(
                    100.0 - soc,
                    0.0,
                    100.0,
                )
            ),

        "battery_mode":
            predictor._mode_from_current(
                current_value
            ),

        "last_cycle_completed":
            False,

        "prediction_count":
            0,

        "cell_imbalance":
            abs(
                cell1 - cell2
            ),

        "power_w":
            power,

        "health_status":
            (
                "Diagnostic SOH prediction"
                if soh is not None
                else "SOH model unavailable"
            ),

        "rul_status":
            "RUL requires 20 completed cycles",

        "eol_threshold":
            float(EOL_SOH),

        "ready":
            bool(
                predictor.soh_model is not None
            ),

        "cycles_available":
            0,

        "cycles_required_for_RUL":
            int(
                predictor.sequence_length
            ),

        "SOH_model":
            predictor.soh_model_file
            or "Not loaded",

        "RUL_model":
            predictor.rul_model_file
            or "CNN-BiLSTM not loaded",

        "model_status":
            dict(
                predictor.model_status
            ),

        "manual_prediction":
            True,
    }


# ============================================================
# DATASET PIPELINE TEST
# ============================================================

def test_with_dataset():

    """
    Pipeline test using the processed dataset.

    This does NOT measure independent model accuracy.
    It only verifies that:
        dataset -> features -> models
    works without schema errors.
    """

    project_root = (
        Path(__file__).resolve().parent.parent
    )

    dataset_path = (
        project_root
        / "data"
        / "processed"
        / "hybrid_cycle_dataset.csv"
    )

    if not dataset_path.exists():

        print(
            "Dataset not found:",
            dataset_path
        )

        return

    df = pd.read_csv(
        dataset_path
    )

    required = [
        "battery_id",
        "cycle",
    ]

    missing = [
        col
        for col in required
        if col not in df.columns
    ]

    if missing:

        print(
            "Dataset missing:",
            missing
        )

        return

    print()
    print("=" * 70)
    print("REALTIME PREDICTOR PIPELINE TEST")
    print("=" * 70)

    print(
        "Dataset:",
        dataset_path
    )

    print(
        "Rows:",
        len(df)
    )

    print(
        "Batteries:",
        df["battery_id"].nunique()
    )

    print("=" * 70)

    # --------------------------------------------------------
    # Find a battery with at least 20 cycles.
    # --------------------------------------------------------

    counts = (
        df.groupby(
            "battery_id"
        )["cycle"]
        .nunique()
        .sort_values(
            ascending=False
        )
    )

    selected_battery = None

    for battery_id, count in counts.items():

        if count >= SEQUENCE_LENGTH:

            selected_battery = battery_id
            break

    if selected_battery is None:

        print(
            "No battery contains at least "
            f"{SEQUENCE_LENGTH} cycles."
        )

        return

    print(
        "Test battery:",
        selected_battery
    )

    print(
        "Available cycles:",
        int(
            counts.loc[
                selected_battery
            ]
        )
    )

    print("=" * 70)

    predictor = Predictor()

    # --------------------------------------------------------
    # The processed dataset normally already contains
    # cycle-level feature columns.
    # --------------------------------------------------------

    battery_df = (
        df[
            df["battery_id"]
            == selected_battery
        ]
        .sort_values("cycle")
    )

    successful = 0

    for _, row in battery_df.iterrows():

        if successful >= SEQUENCE_LENGTH:
            break

        if not all(
            feature in row.index
            for feature in FEATURES
        ):
            print(
                "Dataset does not contain the required "
                "15 feature columns."
            )
            return

        feature_dict = {
            feature: float(
                row[feature]
            )
            for feature in FEATURES
        }

        try:

            result = predictor.add_cycle(
                feature_dict
            )

            successful += 1

            print(
                f"Cycle {successful:02d}: "
                f"SOH={result['SOH_percent']} "
                f"RUL={result['RUL_cycles']}"
            )

        except Exception as exc:

            print(
                f"Cycle {successful + 1:02d} failed:",
                exc
            )

            break

    print("=" * 70)
    print(
        "Completed cycles:",
        successful
    )

    print(
        "SOH model:",
        predictor.soh_model_file
    )

    print(
        "RUL model:",
        predictor.rul_model_file
    )

    print("=" * 70)


# ============================================================
# COMMAND-LINE TEST
# ============================================================

if __name__ == "__main__":

    print()
    print("=" * 70)
    print("HYBRID BATTERY REALTIME PREDICTOR")
    print("=" * 70)

    predictor = Predictor()

    print()
    print("MODEL STATUS")
    print("-" * 70)

    print(
        "Model directory:",
        predictor.model_dir
    )

    print(
        "SOH:",
        predictor.model_status[
            "soh_status"
        ]
    )

    print(
        "RUL:",
        predictor.model_status[
            "rul_status"
        ]
    )

    print()
    print(
        "Current discharge sign:",
        DISCHARGE_CURRENT_SIGN
    )

    print(
        "RUL sequence length:",
        predictor.sequence_length
    )

    print(
        "Nominal 2S pack capacity:",
        NOMINAL_CAPACITY_MAH,
        "mAh"
    )

    print("=" * 70)
