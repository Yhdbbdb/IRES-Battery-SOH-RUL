# Hybrid Battery SOH/RUL — Arduino Uno Final
1. Install: `python -m pip install -r requirements.txt`
2. Run: `python main.py`
3. Prepare dataset.
4. Train models.
5. Upload `arduino/battery_monitor_uno.ino`.
6. Open dashboard and select the Arduino COM port.

NASA is the lifecycle training source. C01-C08 processed `*_discharge_soh.csv` files can be placed in `data/raw`. NH E-Cycle is treated as operating-condition/real-world validation; it is not assigned artificial RUL labels.

EOL = SOH <= 80%. RUL = EOL cycle - current cycle.

Do not connect a battery directly to Arduino analog pins. Use properly rated sensor interfaces and protection.
