"""
Battery SOH & RUL Estimator with Real-Time GUI
================================================
State of Health (SOH) and Remaining Useful Life (RUL) estimator for a
battery cell, driven by a simple physics-inspired empirical degradation
model (temperature + C-rate accelerated capacity fade).

Requirements:
    pip install matplotlib

Run:
    python battery_soh_rul_gui.py

Author: Generated for Nithin
"""

import math
import random
import tkinter as tk
from tkinter import ttk, messagebox
from collections import deque

try:
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
except ImportError:
    raise SystemExit(
        "matplotlib is required. Install it with:\n"
        "    pip install matplotlib --break-system-packages"
    )


# --------------------------------------------------------------------------
# Battery degradation model
# --------------------------------------------------------------------------
class BatteryModel:
    """
    Empirical capacity-fade model.

    Each simulated cycle, the battery loses a fraction of its remaining
    capacity. The base fade rate is accelerated by temperature (Arrhenius-
    like) and by C-rate (higher charge/discharge current -> faster fade).
    Small random noise is added to mimic real measurement/process variance.
    """

    def __init__(self):
        # User-adjustable parameters (defaults)
        self.nominal_capacity = 3.0      # Ah, rated/nameplate capacity
        self.initial_capacity = 3.0      # Ah, actual capacity at cycle 0
        self.base_fade_rate = 0.05       # % capacity lost per cycle at 25C, 1C
        self.temperature = 25.0          # deg C
        self.c_rate = 1.0                # charge/discharge rate
        self.eol_threshold = 80.0        # % SOH considered End of Life
        self.noise_std = 0.01            # % random noise std dev per cycle

        self.reset()

    def reset(self):
        self.cycle = 0
        self.capacity = self.initial_capacity
        self.soh_history = deque(maxlen=2000)
        self.cycle_history = deque(maxlen=2000)
        self.fade_rate_history = deque(maxlen=2000)
        self._record()

    def _record(self):
        soh = (self.capacity / self.nominal_capacity) * 100.0
        self.cycle_history.append(self.cycle)
        self.soh_history.append(soh)

    def _temp_factor(self):
        # Fade roughly doubles every +10C above 25C (Arrhenius-style approx)
        return math.exp(0.0693 * (self.temperature - 25.0))

    def _crate_factor(self):
        # Fade increases with C-rate above 1C, mild protective effect below 1C
        if self.c_rate >= 1.0:
            return 1.0 + 0.35 * (self.c_rate - 1.0)
        return 1.0 - 0.15 * (1.0 - self.c_rate)

    def step(self):
        """Advance the simulation by one charge/discharge cycle."""
        if self.capacity <= 0:
            return

        temp_f = self._temp_factor()
        crate_f = self._crate_factor()
        effective_rate = self.base_fade_rate * temp_f * crate_f

        noise = random.gauss(0, self.noise_std)
        pct_loss_this_cycle = max(0.0, effective_rate + noise)

        self.capacity -= self.capacity * (pct_loss_this_cycle / 100.0)
        self.capacity = max(self.capacity, 0.0)
        self.cycle += 1
        self.fade_rate_history.append(pct_loss_this_cycle)
        self._record()

    def soh(self):
        return (self.capacity / self.nominal_capacity) * 100.0

    def rul(self):
        """
        Estimate Remaining Useful Life in cycles until SOH drops to
        eol_threshold, via linear regression over the recent SOH history.
        """
        n = len(self.soh_history)
        if n < 5:
            return None  # not enough data yet

        window = min(n, 100)
        xs = list(self.cycle_history)[-window:]
        ys = list(self.soh_history)[-window:]

        x_mean = sum(xs) / window
        y_mean = sum(ys) / window
        num = sum((x - x_mean) * (y - y_mean) for x, y in zip(xs, ys))
        den = sum((x - x_mean) ** 2 for x in xs)

        if den == 0:
            return None

        slope = num / den  # SOH % change per cycle (expected negative)
        current_soh = ys[-1]

        if slope >= 0:
            return float("inf")  # not degrading (or improving) -> RUL undefined/huge
        if current_soh <= self.eol_threshold:
            return 0

        cycles_remaining = (current_soh - self.eol_threshold) / (-slope)
        return max(0, cycles_remaining)


# --------------------------------------------------------------------------
# GUI Application
# --------------------------------------------------------------------------
class BatteryApp(tk.Tk):
    UPDATE_INTERVAL_MS = 300  # how often to advance the simulation

    def __init__(self):
        super().__init__()
        self.title("Battery SOH & RUL Estimator")
        self.geometry("1050x650")
        self.minsize(950, 600)

        self.model = BatteryModel()
        self.running = False

        self._build_layout()
        self._refresh_display()

    # ---------------------------------------------------------- UI layout
    def _build_layout(self):
        container = ttk.Frame(self, padding=10)
        container.pack(fill="both", expand=True)

        left = ttk.Frame(container)
        left.pack(side="left", fill="y", padx=(0, 10))

        right = ttk.Frame(container)
        right.pack(side="right", fill="both", expand=True)

        self._build_param_panel(left)
        self._build_status_panel(left)
        self._build_chart_panel(right)

    def _build_param_panel(self, parent):
        box = ttk.LabelFrame(parent, text="Battery Parameters", padding=10)
        box.pack(fill="x", pady=(0, 10))

        self.vars = {
            "nominal_capacity": tk.DoubleVar(value=self.model.nominal_capacity),
            "initial_capacity": tk.DoubleVar(value=self.model.initial_capacity),
            "base_fade_rate": tk.DoubleVar(value=self.model.base_fade_rate),
            "temperature": tk.DoubleVar(value=self.model.temperature),
            "c_rate": tk.DoubleVar(value=self.model.c_rate),
            "eol_threshold": tk.DoubleVar(value=self.model.eol_threshold),
            "noise_std": tk.DoubleVar(value=self.model.noise_std),
        }

        fields = [
            ("Nominal Capacity (Ah)", "nominal_capacity"),
            ("Initial Capacity (Ah)", "initial_capacity"),
            ("Base Fade Rate (%/cycle)", "base_fade_rate"),
            ("Temperature (\u00b0C)", "temperature"),
            ("C-rate", "c_rate"),
            ("EOL SOH Threshold (%)", "eol_threshold"),
            ("Noise Std Dev (%)", "noise_std"),
        ]

        for label, key in fields:
            row = ttk.Frame(box)
            row.pack(fill="x", pady=3)
            ttk.Label(row, text=label, width=22).pack(side="left")
            ttk.Entry(row, textvariable=self.vars[key], width=10).pack(side="right")

        ttk.Button(box, text="Apply Parameters", command=self._apply_params).pack(
            fill="x", pady=(8, 0)
        )

        # Temperature slider for quick real-time adjustment
        slider_row = ttk.Frame(box)
        slider_row.pack(fill="x", pady=(10, 0))
        ttk.Label(slider_row, text="Live Temp (\u00b0C)").pack(anchor="w")
        self.temp_slider = ttk.Scale(
            box, from_=-10, to=60, orient="horizontal", command=self._on_temp_slide
        )
        self.temp_slider.set(self.model.temperature)
        self.temp_slider.pack(fill="x")

        slider_row2 = ttk.Frame(box)
        slider_row2.pack(fill="x", pady=(10, 0))
        ttk.Label(slider_row2, text="Live C-rate").pack(anchor="w")
        self.crate_slider = ttk.Scale(
            box, from_=0.2, to=4.0, orient="horizontal", command=self._on_crate_slide
        )
        self.crate_slider.set(self.model.c_rate)
        self.crate_slider.pack(fill="x")

        controls = ttk.Frame(parent)
        controls.pack(fill="x", pady=(0, 10))
        self.start_btn = ttk.Button(controls, text="Start", command=self._start)
        self.start_btn.pack(side="left", expand=True, fill="x", padx=2)
        self.pause_btn = ttk.Button(controls, text="Pause", command=self._pause)
        self.pause_btn.pack(side="left", expand=True, fill="x", padx=2)
        self.reset_btn = ttk.Button(controls, text="Reset", command=self._reset)
        self.reset_btn.pack(side="left", expand=True, fill="x", padx=2)

    def _build_status_panel(self, parent):
        box = ttk.LabelFrame(parent, text="Real-Time Status", padding=10)
        box.pack(fill="x")

        self.soh_label = ttk.Label(
            box, text="SOH: --%", font=("Segoe UI", 20, "bold")
        )
        self.soh_label.pack(anchor="w", pady=2)

        self.rul_label = ttk.Label(
            box, text="RUL: -- cycles", font=("Segoe UI", 20, "bold")
        )
        self.rul_label.pack(anchor="w", pady=2)

        self.cycle_label = ttk.Label(box, text="Cycle: 0")
        self.cycle_label.pack(anchor="w", pady=(8, 0))

        self.capacity_label = ttk.Label(box, text="Capacity: -- Ah")
        self.capacity_label.pack(anchor="w")

        self.status_label = ttk.Label(box, text="Status: Stopped", foreground="red")
        self.status_label.pack(anchor="w", pady=(8, 0))

    def _build_chart_panel(self, parent):
        self.fig = Figure(figsize=(6, 6), dpi=100)
        self.ax_soh = self.fig.add_subplot(211)
        self.ax_fade = self.fig.add_subplot(212)

        self.ax_soh.set_title("State of Health vs Cycle")
        self.ax_soh.set_xlabel("Cycle")
        self.ax_soh.set_ylabel("SOH (%)")
        self.ax_soh.grid(True, alpha=0.3)

        self.ax_fade.set_title("Per-Cycle Fade Rate")
        self.ax_fade.set_xlabel("Cycle")
        self.ax_fade.set_ylabel("Fade (%/cycle)")
        self.ax_fade.grid(True, alpha=0.3)

        self.fig.tight_layout()

        self.canvas = FigureCanvasTkAgg(self.fig, master=parent)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)

    # ---------------------------------------------------------- callbacks
    def _apply_params(self):
        try:
            m = self.model
            m.nominal_capacity = max(0.001, self.vars["nominal_capacity"].get())
            m.initial_capacity = max(0.001, self.vars["initial_capacity"].get())
            m.base_fade_rate = max(0.0, self.vars["base_fade_rate"].get())
            m.temperature = self.vars["temperature"].get()
            m.c_rate = max(0.01, self.vars["c_rate"].get())
            m.eol_threshold = min(99.9, max(0.0, self.vars["eol_threshold"].get()))
            m.noise_std = max(0.0, self.vars["noise_std"].get())
            self.temp_slider.set(m.temperature)
            self.crate_slider.set(m.c_rate)
            m.reset()
            self._refresh_display()
            self._redraw_chart()
        except tk.TclError:
            messagebox.showerror("Invalid input", "Please enter valid numeric values.")

    def _on_temp_slide(self, value):
        self.model.temperature = float(value)
        self.vars["temperature"].set(round(float(value), 1))

    def _on_crate_slide(self, value):
        self.model.c_rate = float(value)
        self.vars["c_rate"].set(round(float(value), 2))

    def _start(self):
        if not self.running:
            self.running = True
            self.status_label.config(text="Status: Running", foreground="green")
            self._loop()

    def _pause(self):
        self.running = False
        self.status_label.config(text="Status: Paused", foreground="orange")

    def _reset(self):
        self.running = False
        self.model.reset()
        self.status_label.config(text="Status: Stopped", foreground="red")
        self._refresh_display()
        self._redraw_chart()

    # ---------------------------------------------------------- sim loop
    def _loop(self):
        if not self.running:
            return
        self.model.step()
        self._refresh_display()
        self._redraw_chart()

        soh = self.model.soh()
        if soh <= self.model.eol_threshold or self.model.capacity <= 0:
            self.running = False
            self.status_label.config(
                text="Status: End of Life reached", foreground="red"
            )
            return

        self.after(self.UPDATE_INTERVAL_MS, self._loop)

    def _refresh_display(self):
        m = self.model
        soh = m.soh()
        rul = m.rul()

        self.soh_label.config(text=f"SOH: {soh:.2f}%")
        if rul is None:
            rul_text = "RUL: -- cycles (collecting data)"
        elif rul == float("inf"):
            rul_text = "RUL: \u221e (not degrading)"
        else:
            rul_text = f"RUL: {rul:.0f} cycles"
        self.rul_label.config(text=rul_text)

        self.cycle_label.config(text=f"Cycle: {m.cycle}")
        self.capacity_label.config(
            text=f"Capacity: {m.capacity:.3f} Ah / {m.nominal_capacity:.3f} Ah"
        )

        if soh <= m.eol_threshold:
            self.soh_label.config(foreground="red")
        elif soh <= m.eol_threshold + 10:
            self.soh_label.config(foreground="orange")
        else:
            self.soh_label.config(foreground="black")

    def _redraw_chart(self):
        m = self.model
        self.ax_soh.clear()
        self.ax_soh.plot(m.cycle_history, m.soh_history, color="tab:blue")
        self.ax_soh.axhline(
            m.eol_threshold, color="red", linestyle="--", linewidth=1,
            label=f"EOL ({m.eol_threshold:.0f}%)"
        )
        self.ax_soh.set_title("State of Health vs Cycle")
        self.ax_soh.set_xlabel("Cycle")
        self.ax_soh.set_ylabel("SOH (%)")
        self.ax_soh.legend(loc="upper right", fontsize=8)
        self.ax_soh.grid(True, alpha=0.3)

        self.ax_fade.clear()
        if len(m.fade_rate_history) > 0:
            xs = list(m.cycle_history)[1:]
            self.ax_fade.plot(xs, m.fade_rate_history, color="tab:orange")
        self.ax_fade.set_title("Per-Cycle Fade Rate")
        self.ax_fade.set_xlabel("Cycle")
        self.ax_fade.set_ylabel("Fade (%/cycle)")
        self.ax_fade.grid(True, alpha=0.3)

        self.fig.tight_layout()
        self.canvas.draw_idle()


if __name__ == "__main__":
    app = BatteryApp()
    app.mainloop()
