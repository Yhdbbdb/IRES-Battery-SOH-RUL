function Metrics = evaluateRegression(Actual, Predicted, numPredictors)
% EVALUATEREGRESSION  Compute a full regression metric suite, with a
% divide-by-zero-safe MAPE/RMSPE (the original script produced Inf
% whenever a true SOH value was ~0, since MAPE divides by Actual).

Actual = Actual(:);
Predicted = Predicted(:);
Error = Actual - Predicted;
n = numel(Actual);

MAE = mean(abs(Error));
MSE = mean(Error.^2);
RMSE = sqrt(MSE);

% --- Safe MAPE / RMSPE: exclude near-zero actual values ---
epsVal = 1e-6;
validIdx = abs(Actual) > epsVal;
if any(validIdx)
    MAPE  = mean(abs(Error(validIdx) ./ Actual(validIdx))) * 100;
    RMSPE = sqrt(mean((Error(validIdx) ./ Actual(validIdx)).^2)) * 100;
    if nnz(~validIdx) > 0
        warning('evaluateRegression:NearZeroActual', ...
            '%d sample(s) with near-zero Actual value excluded from MAPE/RMSPE.', nnz(~validIdx));
    end
else
    MAPE = NaN;
    RMSPE = NaN;
end

% --- R^2 (guarded against zero total variance) ---
SStot = sum((Actual - mean(Actual)).^2);
if SStot > 0
    R2 = 1 - sum(Error.^2) / SStot;
else
    R2 = NaN;
end

% --- Adjusted R^2 ---
if nargin < 3 || isempty(numPredictors)
    numPredictors = 1;
end
if ~isnan(R2) && (n - numPredictors - 1) > 0
    AdjR2 = 1 - (1 - R2) * (n - 1) / (n - numPredictors - 1);
else
    AdjR2 = NaN;
end

% --- Normalized RMSE (range-based) ---
rangeY = max(Actual) - min(Actual);
if rangeY > 0
    NRMSE = RMSE / rangeY;
else
    NRMSE = NaN;
end

Metrics = struct( ...
    'MAE', MAE, ...
    'MSE', MSE, ...
    'RMSE', RMSE, ...
    'MAPE', MAPE, ...
    'RMSPE', RMSPE, ...
    'R2', R2, ...
    'AdjustedR2', AdjR2, ...
    'NRMSE', NRMSE, ...
    'MaximumError', max(abs(Error)), ...
    'MeanError', mean(Error), ...
    'StdError', std(Error));

end
