function [selectedFeatures, weights] = selectFeatures(trainTbl, candidateFeatures, numToSelect)
% SELECTFEATURES  Rank candidate features by relevance to SOH using
% Neighborhood Component Analysis for regression (fsrnca), a built-in
% Statistics and Machine Learning Toolbox method -- no third-party
% toolbox required. Fit strictly on the TRAINING set to avoid any
% val/test information leaking into the feature-selection decision.

if nargin < 3 || isempty(numToSelect)
    numToSelect = min(8, numel(candidateFeatures));
end

X = trainTbl{:,candidateFeatures};
y = trainTbl.SOH;

% Temporary standardization purely for fair NCA weighting (the actual
% model-facing normalization is refit later on the selected feature set).
Xz = normalize(X);

mdl = fsrnca(Xz, y, 'Solver','lbfgs', 'Verbose', 0, ...
    'Lambda', 1/size(Xz,1), 'IterationLimit', 200);

[sortedW, idx] = sort(mdl.FeatureWeights, 'descend');

numToSelect = min(numToSelect, numel(candidateFeatures));
selIdx = idx(1:numToSelect);

selectedFeatures = candidateFeatures(selIdx);
weights = sortedW(1:numToSelect);

fprintf('\nFeature selection (fsrnca, fit on TRAIN only) -- top %d of %d features:\n', ...
    numToSelect, numel(candidateFeatures));
for i = 1:numToSelect
    fprintf('  %-20s weight = %.4f\n', selectedFeatures{i}, weights(i));
end

end
