function [foldIdx, K] = groupKFoldIndices(groups, K)
% GROUPKFOLDINDICES  Assign each row to one of K folds such that all
% rows belonging to the same group (battery) fall in the same fold.
% This is what makes the subsequent out-of-fold (OOF) stacking valid --
% a battery's cycles are never split between a CV training fold and its
% corresponding held-out fold.

groups = categorical(groups);
uniqueGroups = categories(removecats(groups));
nG = numel(uniqueGroups);

if nG < K
    warning('groupKFoldIndices:ReducedK', ...
        'Fewer batteries (%d) than requested folds (%d); reducing K to %d.', nG, K, nG);
    K = nG;
end

rng(2); % reproducibility, independent stream from the train/val/test split
shuffledGroups = uniqueGroups(randperm(nG));
groupFold = mod(0:nG-1, K) + 1;

foldIdx = zeros(numel(groups),1);
for g = 1:nG
    foldIdx(groups == shuffledGroups{g}) = groupFold(g);
end

fprintf('\nGrouped %d-fold CV: %d batteries assigned to folds (battery-disjoint).\n', K, nG);

end
