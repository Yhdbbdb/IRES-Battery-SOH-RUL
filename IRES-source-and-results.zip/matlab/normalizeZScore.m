function [Xn, mu, sigma] = normalizeZScore(X)
% NORMALIZEZSCORE  Fit z-score normalization parameters on X (intended
% to be called on the TRAINING set only) and return both the normalized
% matrix and the (mu, sigma) needed to apply the identical transform to
% validation/test data, preventing normalization leakage.

mu = mean(X, 1, 'omitnan');
sigma = std(X, 0, 1, 'omitnan');
sigma(sigma == 0) = 1; % guard against divide-by-zero for constant columns

Xn = (X - mu) ./ sigma;

end
