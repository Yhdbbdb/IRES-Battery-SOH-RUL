function rawTable = loadNASADataset(folder)
% LOADNASADATASET  Extract discharge-cycle raw signals from the NASA
% Battery Aging Dataset (B0005-B0056), automatically handling:
%   - missing/corrupted cycle fields
%   - mismatched signal lengths
%   - non-finite (NaN/Inf) samples
%   - missing Capacity fields (estimated from raw current when absent)
%
% OUTPUT
%   rawTable : one row per usable discharge cycle, columns:
%       BatteryID, CycleIndex, Voltage, Current, Temperature, Time (cell
%       arrays holding the raw per-sample signals), Capacity (Ah),
%       RatedCapacity (Ah)
%
% NOTE: Capacity is retained ONLY to compute the SOH target downstream.
% It is never engineered directly as a model feature -- see
% engineerFeatures.m for why (data-leakage fix).

files = dir(fullfile(folder,'*.mat'));
if isempty(files)
    error('loadNASADataset:NoFiles','No .mat files found in %s', folder);
end

RatedCapacity = 2.0; % Ah, nominal rating for the NASA B00xx cells

BatteryID = {}; CycleIndex = []; Voltage = {}; Current = {};
Temperature = {}; Time = {}; Capacity = []; RatedCap = [];

fprintf('Found %d battery file(s) in dataset folder.\n', numel(files));

for k = 1:numel(files)
    fname = files(k).name;

    try
        S = load(fullfile(folder,fname));
        varsInFile = fieldnames(S);
        battery = S.(varsInFile{1});
        cycles = battery.cycle;
    catch ME
        warning('loadNASADataset:LoadFailed', ...
            'Skipping %s: could not load battery struct (%s)', fname, ME.message);
        continue;
    end

    dischargeCount = 0;
    skippedCount = 0;

    for i = 1:numel(cycles)
        if ~isfield(cycles(i),'type') || ~strcmpi(cycles(i).type,'discharge')
            continue;
        end

        try
            data = cycles(i).data;

            if ~isfield(data,'Voltage_measured') || ~isfield(data,'Current_measured') ...
                    || ~isfield(data,'Temperature_measured') || ~isfield(data,'Time')
                skippedCount = skippedCount + 1;
                continue;
            end

            V = double(data.Voltage_measured(:));
            I = double(data.Current_measured(:));
            T = double(data.Temperature_measured(:));
            t = double(data.Time(:));

            if isempty(V) || isempty(I) || isempty(T) || isempty(t)
                skippedCount = skippedCount + 1;
                continue;
            end

            % --- Align lengths (corrupted/mismatched arrays) ---
            n = min([numel(V) numel(I) numel(T) numel(t)]);
            if n < 5
                skippedCount = skippedCount + 1;
                continue;
            end
            V = V(1:n); I = I(1:n); T = T(1:n); t = t(1:n);

            % --- Drop non-finite samples rather than the whole cycle ---
            validMask = isfinite(V) & isfinite(I) & isfinite(T) & isfinite(t);
            if nnz(validMask) < 5
                skippedCount = skippedCount + 1;
                continue;
            end
            V = V(validMask); I = I(validMask); T = T(validMask); t = t(validMask);

            % --- Capacity: use reported value if valid, else estimate ---
            cap = NaN;
            if isfield(data,'Capacity') && ~isempty(data.Capacity)
                capCandidate = double(data.Capacity);
                if isscalar(capCandidate) && isfinite(capCandidate) && capCandidate > 0
                    cap = capCandidate;
                end
            end
            if isnan(cap)
                cap = trapz(t, abs(I)) / 3600; % Ah, from raw current (missing-field fallback)
            end
            if ~isfinite(cap) || cap <= 0
                skippedCount = skippedCount + 1;
                continue;
            end

            dischargeCount = dischargeCount + 1;

            BatteryID{end+1,1}   = erase(fname,'.mat');  %#ok<AGROW>
            CycleIndex(end+1,1)  = dischargeCount;         %#ok<AGROW>
            Voltage{end+1,1}     = V;                      %#ok<AGROW>
            Current{end+1,1}     = I;                      %#ok<AGROW>
            Temperature{end+1,1} = T;                      %#ok<AGROW>
            Time{end+1,1}        = t;                      %#ok<AGROW>
            Capacity(end+1,1)    = cap;                    %#ok<AGROW>
            RatedCap(end+1,1)    = RatedCapacity;           %#ok<AGROW>

        catch ME
            skippedCount = skippedCount + 1;
            warning('loadNASADataset:CycleError', ...
                'Skipping corrupted cycle %d in %s: %s', i, fname, ME.message);
            continue;
        end
    end

    fprintf('  %-14s -> %4d usable discharge cycles (%d skipped)\n', ...
        fname, dischargeCount, skippedCount);
end

if isempty(BatteryID)
    error('loadNASADataset:NoUsableData', ...
        'No usable discharge cycles were extracted from the dataset.');
end

rawTable = table(BatteryID, CycleIndex, Voltage, Current, Temperature, Time, ...
    Capacity, RatedCap, ...
    'VariableNames', {'BatteryID','CycleIndex','Voltage','Current', ...
    'Temperature','Time','Capacity','RatedCapacity'});

rawTable.BatteryID = categorical(rawTable.BatteryID);

fprintf('\nTotal usable discharge cycles extracted: %d (from %d batteries)\n', ...
    height(rawTable), numel(categories(rawTable.BatteryID)));

end
