function MetaModel = trainMetaLearner(metaX, y)
% TRAINMETALEARNER  Train a DNN meta-learner using ONLY out-of-fold (OOF)
% predictions from the base learners as input.
%
% STACKING LEAKAGE FIX (critical): the original script trained the
% meta-learner on each base learner's predictions on the SAME data those
% base learners were trained on. Since a model's in-sample predictions
% are systematically closer to the truth than its predictions on unseen
% data, this teaches the meta-learner an overly optimistic, non-
% generalizing mapping. Here, metaX must be the OOF prediction matrix
% assembled in main_SOH_Prediction.m (each row's base-learner
% predictions come from a model that never saw that row during
% training), which is the standard/correct way to build a stacked
% ensemble.

layers = [
    featureInputLayer(size(metaX,2), 'Normalization','zscore', 'Name','input')
    fullyConnectedLayer(32, 'Name','fc1')
    reluLayer('Name','relu1')
    dropoutLayer(0.2, 'Name','drop1')
    fullyConnectedLayer(16, 'Name','fc2')
    reluLayer('Name','relu2')
    fullyConnectedLayer(1, 'Name','fc_out')
    regressionLayer('Name','output')];

options = trainingOptions('adam', ...
    'MaxEpochs', 200, ...
    'MiniBatchSize', 32, ...
    'InitialLearnRate', 5e-4, ...
    'L2Regularization', 1e-4, ...
    'Shuffle','every-epoch', ...
    'Verbose', false, ...
    'Plots','none');

MetaModel = trainNetwork(metaX, y, layers, options);

end
