# Hybrid Battery SOH Prediction — NASA Dataset (B0005–B0056)

Research-grade MATLAB pipeline: **ANN (fitrnet) + SVR (fitrsvm) + Random
Forest (fitrensemble)** base learners, stacked with a **DNN meta-learner
trained on out-of-fold predictions**.

## Requirements
- MATLAB R2024a or R2024b
- Statistics and Machine Learning Toolbox
- Deep Learning Toolbox
- No third-party toolboxes (LSSVMlab removed entirely)

## How to run
1. Open `main_SOH_Prediction.m`.
2. Edit `datasetFolder` at the top to point to your local copy of the
   NASA Battery Data Set (folder containing `B0005.mat` … `B0056.mat`).
3. Run the file (it is a zero-argument function — MATLAB's Run button
   works directly).
4. Outputs are written to `Outputs/`:
   - `Figures/` — 8 publication-quality PNGs (300 DPI) + SHAP plot
   - `PredictionResults.xlsx`, `PerformanceMetrics.xlsx`, `FeatureImportance.xlsx`
   - `TrainedModels.mat` — all trained models + normalization params

Runtime note: each base learner runs Bayesian hyperparameter
optimization *inside* a 5-fold CV loop, so total training involves
`5 folds × 3 base learners + 3 final refits = 18` Bayesian optimization
runs. Lower `maxObjEval` in `main_SOH_Prediction.m` (e.g. to 10–15) for
faster exploratory runs; raise it for final paper-quality numbers.

## File structure
| File | Purpose |
|---|---|
| `main_SOH_Prediction.m` | Orchestrates the full pipeline |
| `loadNASADataset.m` | Extracts raw discharge-cycle signals; handles missing/corrupted cycles and missing Capacity fields |
| `engineerFeatures.m` | Builds 12 leakage-free scalar features from raw V/I/T/t signals |
| `batteryWiseSplit.m` | Splits by whole battery into train/val/test |
| `groupKFoldIndices.m` | Battery-grouped 5-fold CV assignment |
| `selectFeatures.m` | `fsrnca`-based feature ranking/selection (fit on train only) |
| `normalizeZScore.m` | Z-score fit on train, applied to val/test |
| `trainANN_Bayesopt.m` | ANN base learner (`fitrnet`, Bayesian-optimized) |
| `trainSVR_Bayesopt.m` | SVR base learner (`fitrsvm`, Bayesian-optimized) |
| `trainRF_Bayesopt.m` | Random Forest base learner (`fitrensemble`, Bayesian-optimized) |
| `trainMetaLearner.m` | DNN meta-learner, trained on OOF predictions only |
| `evaluateRegression.m` | RMSE, MAE, MAPE, RMSPE, R², Adjusted R², NRMSE (all divide-by-zero safe) |
| `explainModel.m` | SHAP (`shapley`) + global feature importance |
| `generatePublicationPlots.m` | 8 figures, saved via `exportgraphics` at 300 DPI |
| `exportResultsToExcel.m` | Predictions + metrics to `.xlsx` |

## How each original problem was fixed
1. **Data leakage** — Capacity and amp-hour throughput (algebraically
   identical to Capacity) are excluded from the feature set; see the
   comment block at the top of `engineerFeatures.m`.
2. **Random row-wise split** — `batteryWiseSplit.m` splits by whole
   battery so no battery's cycles cross the train/val/test boundary.
3. **Improper stacking** — `groupKFoldIndices.m` + the CV loop in
   `main_SOH_Prediction.m` produce genuine out-of-fold predictions;
   `trainMetaLearner.m` is trained only on those.
4. **No hyperparameter optimization** — every base learner uses
   `OptimizeHyperparameters` with `'Optimizer','bayesopt'`.
5. **Weak feature engineering** — 12 physically meaningful, leakage-free
   features (voltage stats + slope, current stats, temperature stats,
   discharge duration, cycle index).
6. **No cross-validation** — battery-grouped 5-fold CV.
7. **No feature selection** — `fsrnca` ranking in `selectFeatures.m`.
8. **No explainability** — `explainModel.m` (SHAP via `shapley`, plus
   `predictorImportance`).
9. **Basic DNN** — deeper, regularized (dropout + L2) meta-learner.
10. **MATLAB compatibility** — modern built-in functions only
    (`fitrnet`, `fitrsvm`, `fitrensemble`, `exportgraphics`, `shapley`),
    all valid in R2024a/R2024b.
11. **Missing Capacity fields** — auto-detected and estimated from raw
    current via `trapz` in `loadNASADataset.m`.
12. **MAPE → Inf** — `evaluateRegression.m` excludes near-zero actual
    values from the percentage-error calculations instead of dividing
    by them.
13. **Figure saving issues** — figures rendered off-screen and saved
    via `exportgraphics` inside `try/catch`, so one failure can't abort
    the run.
14. **Third-party toolboxes** — LSSVMlab removed; only Statistics and
    Machine Learning Toolbox + Deep Learning Toolbox are used.
