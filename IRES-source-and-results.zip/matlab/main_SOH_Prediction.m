function main_SOH_Prediction()
% MAIN_SOH_PREDICTION  Research-grade Battery SOH prediction pipeline.
%
% Base learners : ANN (fitrnet) + SVR (fitrsvm) + Random Forest (fitrensemble)
% Meta-learner  : DNN trained ONLY on out-of-fold (OOF) base predictions
% Dataset       : NASA Battery Aging Dataset (B0005-B0056)
% Toolboxes     : Statistics and Machine Learning Toolbox, Deep Learning Toolbox
%                 (no third-party toolboxes, e.g. no LSSVMlab)
%
% This script fixes, relative to the original implementation:
%   1. Data leakage (Capacity/Amp-hour-derived features removed)          -> engineerFeatures.m
%   2. Random row-wise split                 -> battery-wise split        -> batteryWiseSplit.m
%   3. Meta-learner trained on in-sample preds -> trained on OOF preds    -> this file + trainMetaLearner.m
%   4. No hyperparameter search              -> Bayesian optimization     -> trainANN/SVR/RF_Bayesopt.m
%   5. Weak feature engineering              -> 12 leakage-free features  -> engineerFeatures.m
%   6. No cross-validation                   -> battery-grouped 5-fold CV -> groupKFoldIndices.m
%   7. No feature selection                  -> fsrnca ranking            -> selectFeatures.m
%   8. No explainability                     -> SHAP + importance export  -> explainModel.m
%   9. Basic DNN architecture                -> deeper regularized DNN    -> trainMetaLearner.m
%  10. MATLAB compatibility issues           -> modern built-in functions only
%  11. Missing Capacity fields               -> auto-estimated/handled    -> loadNASADataset.m
%  12. MAPE -> Inf                           -> safe metric computation   -> evaluateRegression.m
%  13. Figure saving issues                  -> robust exportgraphics     -> generatePublicationPlots.m
%  14. Third-party toolboxes (LSSVMlab)      -> removed entirely

clear; clc; close all; rng(1);

%% ---------------------------------------------------------------
%  Configuration
%  -----------------------------------------------------------------
datasetFolder = "C:\Users\nithi\Documents\IRES\5.+Battery+Data+Set\5. Battery Data Set\all";
outputFolder  = "Outputs";
if ~exist(outputFolder,'dir'), mkdir(outputFolder); end

splitRatios = struct('train',0.70,'val',0.15,'test',0.15);
K = 5;                      % CV folds for OOF stacking
maxObjEval = 30;            % Bayesian optimization budget per base learner
                             % (reduce e.g. to 10-15 for quicker exploratory runs)

%% ---------------------------------------------------------------
%  1. Load raw dataset (handles missing/corrupted cycles & Capacity)
%  -----------------------------------------------------------------
rawTable = loadNASADataset(datasetFolder);

%% ---------------------------------------------------------------
%  2. Leakage-free feature engineering
%  -----------------------------------------------------------------
[dataTable, allFeatureNames] = engineerFeatures(rawTable);

%% ---------------------------------------------------------------
%  3. Battery-wise train / validation / test split
%  -----------------------------------------------------------------
[trainTbl, valTbl, testTbl] = batteryWiseSplit(dataTable, splitRatios);

%% ---------------------------------------------------------------
%  4. Feature selection (fit on TRAIN only)
%  -----------------------------------------------------------------
[selectedFeatures, ~] = selectFeatures(trainTbl, allFeatureNames);

%% ---------------------------------------------------------------
%  5. Z-score normalization (fit on TRAIN only)
%  -----------------------------------------------------------------
[trainX, mu, sigma] = normalizeZScore(trainTbl{:,selectedFeatures});
valX  = (valTbl{:,selectedFeatures}  - mu) ./ sigma;
testX = (testTbl{:,selectedFeatures} - mu) ./ sigma;

trainY = trainTbl.SOH;
valY   = valTbl.SOH;
testY  = testTbl.SOH;
trainGroups = trainTbl.BatteryID;

%% ---------------------------------------------------------------
%  6. Battery-grouped 5-fold CV -> out-of-fold (OOF) predictions
%     (this is what makes the meta-learner training statistically valid)
%  -----------------------------------------------------------------
[foldIdx, K] = groupKFoldIndices(trainGroups, K);

oofANN = nan(height(trainTbl),1);
oofSVR = nan(height(trainTbl),1);
oofRF  = nan(height(trainTbl),1);

for k = 1:K
    heldOutMask = (foldIdx == k);
    fitMask     = ~heldOutMask;

    fprintf('\n=== CV Fold %d/%d (fit on %d rows, predict %d held-out rows) ===\n', ...
        k, K, nnz(fitMask), nnz(heldOutMask));

    annModelK = trainANN_Bayesopt(trainX(fitMask,:), trainY(fitMask), maxObjEval);
    oofANN(heldOutMask) = predict(annModelK, trainX(heldOutMask,:));

    svrModelK = trainSVR_Bayesopt(trainX(fitMask,:), trainY(fitMask), maxObjEval);
    oofSVR(heldOutMask) = predict(svrModelK, trainX(heldOutMask,:));

    rfModelK = trainRF_Bayesopt(trainX(fitMask,:), trainY(fitMask), maxObjEval);
    oofRF(heldOutMask) = predict(rfModelK, trainX(heldOutMask,:));
end

assert(~any(isnan(oofANN)) && ~any(isnan(oofSVR)) && ~any(isnan(oofRF)), ...
    'Every training row must receive exactly one OOF prediction from each base learner.');

%% ---------------------------------------------------------------
%  7. Train final base learners on the FULL training set
%     (used for Val/Test inference; CV models above were only for OOF)
%  -----------------------------------------------------------------
fprintf('\n=== Training final base learners on full training set ===\n');
ANN_Final = trainANN_Bayesopt(trainX, trainY, maxObjEval);
SVR_Final = trainSVR_Bayesopt(trainX, trainY, maxObjEval);
RF_Final  = trainRF_Bayesopt(trainX, trainY, maxObjEval);

%% ---------------------------------------------------------------
%  8. Train DNN meta-learner on OOF predictions ONLY
%  -----------------------------------------------------------------
fprintf('\n=== Training DNN meta-learner on out-of-fold predictions ===\n');
metaTrainX = [oofANN, oofSVR, oofRF];
MetaModel = trainMetaLearner(metaTrainX, trainY);

%% ---------------------------------------------------------------
%  9. Validation-set evaluation (final base models -> meta-learner)
%  -----------------------------------------------------------------
valPredANN = predict(ANN_Final, valX);
valPredSVR = predict(SVR_Final, valX);
valPredRF  = predict(RF_Final,  valX);
metaValX = [valPredANN, valPredSVR, valPredRF];
valPredFinal = predict(MetaModel, metaValX);

ValMetrics = evaluateRegression(valY, valPredFinal, size(metaValX,2));
fprintf('\n--- Validation Set Performance ---\n');
disp(ValMetrics);

%% ---------------------------------------------------------------
% 10. Test-set evaluation (final, unbiased)
%  -----------------------------------------------------------------
testPredANN = predict(ANN_Final, testX);
testPredSVR = predict(SVR_Final, testX);
testPredRF  = predict(RF_Final,  testX);
metaTestX = [testPredANN, testPredSVR, testPredRF];
testPredFinal = predict(MetaModel, metaTestX);

Results = struct();
Results.Actual    = testY;
Results.Predicted = testPredFinal;
Results.ANN = testPredANN;
Results.SVR = testPredSVR;
Results.RF  = testPredRF;
Results.Error = testY - testPredFinal;

TestMetrics = evaluateRegression(testY, testPredFinal, size(metaTestX,2));
fprintf('\n--- Test Set Performance (final, held-out) ---\n');
disp(TestMetrics);

%% ---------------------------------------------------------------
% 11. Explainability, plots, and export
%  -----------------------------------------------------------------
explainModel(RF_Final, testX, selectedFeatures, outputFolder, 1);
generatePublicationPlots(Results, outputFolder);
exportResultsToExcel(Results, TestMetrics, outputFolder);

save(fullfile(outputFolder,'TrainedModels.mat'), ...
    'ANN_Final','SVR_Final','RF_Final','MetaModel', ...
    'mu','sigma','selectedFeatures','splitRatios','K');

fprintf('\n=====================================\n');
fprintf('PIPELINE COMPLETED SUCCESSFULLY\n');
fprintf('All outputs saved under: %s\n', outputFolder);
fprintf('=====================================\n');

end
