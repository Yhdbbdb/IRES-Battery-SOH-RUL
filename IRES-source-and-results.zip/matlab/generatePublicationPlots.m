function generatePublicationPlots(Results, outputFolder)
% GENERATEPUBLICATIONPLOTS  Generate and save publication-quality plots.
%
% FIGURE-SAVING FIX: figures are created invisible ('Visible','off') so
% nothing flashes on screen or steals focus during batch runs, saved at
% 300 DPI via exportgraphics (more robust and higher quality than
% saveas), wrapped in try/catch so one failed figure cannot abort the
% whole run, and explicitly closed afterward to avoid handle/memory
% buildup across repeated runs.

figFolder = fullfile(outputFolder,'Figures');
if ~exist(figFolder,'dir'), mkdir(figFolder); end

Actual = Results.Actual;
Predicted = Results.Predicted;
Error = Results.Error;

set(0,'DefaultAxesFontName','Times New Roman','DefaultAxesFontSize',11);
res = 300;

% --- 1. Actual vs Predicted (line) ---
try
    f = figure('Color','w','Visible','off','Position',[100 100 750 450]);
    plot(Actual,'b-','LineWidth',1.5); hold on;
    plot(Predicted,'r--','LineWidth',1.5); grid on; box on;
    xlabel('Sample Index'); ylabel('SOH (%)');
    title('Actual vs Predicted SOH');
    legend('Actual','Predicted','Location','best');
    exportgraphics(f, fullfile(figFolder,'Actual_vs_Predicted.png'), 'Resolution', res);
    close(f);
catch ME
    warning('Figure (Actual vs Predicted) failed: %s', ME.message);
end

% --- 2. Prediction Error ---
try
    f = figure('Color','w','Visible','off','Position',[100 100 750 400]);
    plot(Error,'k-','LineWidth',1.2); grid on; box on;
    yline(0,'r--','LineWidth',1);
    xlabel('Sample Index'); ylabel('Prediction Error (%)');
    title('Prediction Error');
    exportgraphics(f, fullfile(figFolder,'Prediction_Error.png'), 'Resolution', res);
    close(f);
catch ME
    warning('Figure (Prediction Error) failed: %s', ME.message);
end

% --- 3. Error Histogram ---
try
    f = figure('Color','w','Visible','off','Position',[100 100 650 450]);
    histogram(Error, 25, 'FaceColor',[0.2 0.4 0.7]); grid on; box on;
    xlabel('Prediction Error (%)'); ylabel('Frequency');
    title('Error Distribution');
    exportgraphics(f, fullfile(figFolder,'Error_Histogram.png'), 'Resolution', res);
    close(f);
catch ME
    warning('Figure (Error Histogram) failed: %s', ME.message);
end

% --- 4. Regression / Scatter Plot with R^2 annotation ---
try
    SStot = sum((Actual - mean(Actual)).^2);
    if SStot > 0
        R2 = 1 - sum(Error.^2) / SStot;
    else
        R2 = NaN;
    end

    f = figure('Color','w','Visible','off','Position',[100 100 600 550]);
    scatter(Actual, Predicted, 35, 'filled', 'MarkerFaceAlpha',0.6); hold on;
    lims = [min([Actual;Predicted]) max([Actual;Predicted])];
    plot(lims, lims, 'r-', 'LineWidth', 1.8);
    grid on; box on; axis equal; xlim(lims); ylim(lims);
    xlabel('Actual SOH (%)'); ylabel('Predicted SOH (%)');
    title(sprintf('Regression Plot (R^2 = %.4f)', R2));
    exportgraphics(f, fullfile(figFolder,'Regression.png'), 'Resolution', res);
    close(f);
catch ME
    warning('Figure (Regression) failed: %s', ME.message);
end

% --- 5. Residual Plot ---
try
    f = figure('Color','w','Visible','off','Position',[100 100 700 450]);
    scatter(Predicted, Error, 30, 'filled', 'MarkerFaceAlpha',0.6); hold on;
    yline(0,'r--','LineWidth',1.5);
    grid on; box on;
    xlabel('Predicted SOH (%)'); ylabel('Residual (%)');
    title('Residual Plot');
    exportgraphics(f, fullfile(figFolder,'Residual.png'), 'Resolution', res);
    close(f);
catch ME
    warning('Figure (Residual) failed: %s', ME.message);
end

% --- 6. Boxplot: Actual vs Predicted distribution ---
try
    f = figure('Color','w','Visible','off','Position',[100 100 500 450]);
    boxplot([Actual Predicted], 'Labels', {'Actual','Predicted'});
    grid on; box on;
    ylabel('SOH (%)');
    title('Actual vs Predicted Distribution');
    exportgraphics(f, fullfile(figFolder,'BoxPlot.png'), 'Resolution', res);
    close(f);
catch ME
    warning('Figure (BoxPlot) failed: %s', ME.message);
end

% --- 7. Cumulative Absolute Error ---
try
    f = figure('Color','w','Visible','off','Position',[100 100 700 400]);
    plot(cumsum(abs(Error)), 'LineWidth', 1.6); grid on; box on;
    xlabel('Sample Index'); ylabel('Cumulative |Error|');
    title('Cumulative Prediction Error');
    exportgraphics(f, fullfile(figFolder,'CumulativeError.png'), 'Resolution', res);
    close(f);
catch ME
    warning('Figure (CumulativeError) failed: %s', ME.message);
end

% --- 8. CDF of Error ---
try
    f = figure('Color','w','Visible','off','Position',[100 100 650 450]);
    cdfplot(Error); grid on; box on;
    xlabel('Prediction Error (%)'); ylabel('Cumulative Probability');
    title('CDF of Prediction Error');
    exportgraphics(f, fullfile(figFolder,'ErrorCDF.png'), 'Resolution', res);
    close(f);
catch ME
    warning('Figure (ErrorCDF) failed: %s', ME.message);
end

fprintf('\nAll figures saved to %s\n', figFolder);

end
