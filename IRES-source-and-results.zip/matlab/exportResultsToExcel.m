function exportResultsToExcel(Results, Metrics, outputFolder)
% EXPORTRESULTSTOEXCEL  Export per-sample predictions and the full
% performance-metric suite to Excel workbooks.

if ~exist(outputFolder,'dir'), mkdir(outputFolder); end

predTable = table( ...
    Results.Actual, Results.ANN, Results.SVR, Results.RF, ...
    Results.Predicted, Results.Error, ...
    'VariableNames', {'ActualSOH','ANN_Pred','SVR_Pred','RF_Pred', ...
    'Stacked_Pred','Error'});
writetable(predTable, fullfile(outputFolder,'PredictionResults.xlsx'));

metricNames = fieldnames(Metrics);
metricValues = cellfun(@(f) Metrics.(f), metricNames);
metricTable = table(metricNames, metricValues, 'VariableNames', {'Metric','Value'});
writetable(metricTable, fullfile(outputFolder,'PerformanceMetrics.xlsx'));

fprintf('\nResults exported:\n  %s\n  %s\n', ...
    fullfile(outputFolder,'PredictionResults.xlsx'), ...
    fullfile(outputFolder,'PerformanceMetrics.xlsx'));

end
