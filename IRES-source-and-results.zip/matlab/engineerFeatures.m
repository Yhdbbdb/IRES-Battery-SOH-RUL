function [dataTable, featureNames] = engineerFeatures(rawTable)
% ENGINEERFEATURES  Compute leakage-free scalar health-indicator features
% from raw per-cycle Voltage/Current/Temperature/Time signals.
%
% DATA-LEAKAGE FIX (critical): the original script used Capacity itself
% (and Amp-hour throughput, which is algebraically the same quantity via
% trapz(|I|)/3600) as a MODEL INPUT, while also using Capacity to DEFINE
% the SOH target (SOH = Capacity/RatedCapacity*100). That makes the
% target trivially recoverable from the input and inflates offline
% accuracy while destroying real-world generalization. Amp-hour
% throughput / discharge energy are therefore deliberately EXCLUDED from
% the feature set below.
%
% BatteryID is also excluded as a model feature (it is a categorical
% identity label, not a health indicator -- keeping it as a predictor
% would let models memorize per-battery behaviour instead of learning
% generalizable degradation patterns, which would undermine the
% battery-wise split entirely). BatteryID is retained in the output
% table ONLY for grouping/splitting purposes.

n = height(rawTable);

meanV = zeros(n,1); minV = zeros(n,1); maxV = zeros(n,1); stdV = zeros(n,1);
slopeV = zeros(n,1);
meanI = zeros(n,1); stdI = zeros(n,1);
meanT = zeros(n,1); maxT = zeros(n,1); tempRise = zeros(n,1);
duration = zeros(n,1);

for i = 1:n
    V = rawTable.Voltage{i};
    I = rawTable.Current{i};
    T = rawTable.Temperature{i};
    t = rawTable.Time{i};

    meanV(i) = mean(V);
    minV(i)  = min(V);
    maxV(i)  = max(V);
    stdV(i)  = std(V);

    meanI(i) = mean(abs(I));
    stdI(i)  = std(I);

    meanT(i) = mean(T);
    maxT(i)  = max(T);
    tempRise(i) = max(T) - min(T);

    duration(i) = max(t) - min(t);

    % Voltage discharge slope (dV/dt): a well-established indirect health
    % indicator, computed purely from raw V/t and independent of the
    % amp-hour integral used for Capacity.
    if numel(t) >= 2 && range(t) > 0
        p = polyfit(t, V, 1);
        slopeV(i) = p(1);
    else
        slopeV(i) = 0;
    end
end

SOH = (rawTable.Capacity ./ rawTable.RatedCapacity) * 100;

dataTable = table( ...
    rawTable.BatteryID, rawTable.CycleIndex, ...
    meanV, minV, maxV, stdV, slopeV, ...
    meanI, stdI, meanT, maxT, tempRise, duration, ...
    SOH, ...
    'VariableNames', {'BatteryID','CycleIndex', ...
    'MeanVoltage','MinVoltage','MaxVoltage','StdVoltage','VoltageSlope', ...
    'MeanCurrent','StdCurrent','MeanTemperature','MaxTemperature', ...
    'TempRise','DischargeDuration','SOH'});

featureNames = {'CycleIndex','MeanVoltage','MinVoltage','MaxVoltage', ...
    'StdVoltage','VoltageSlope','MeanCurrent','StdCurrent', ...
    'MeanTemperature','MaxTemperature','TempRise','DischargeDuration'};

% Drop any row with a non-finite engineered feature or target (guards
% against edge-case degenerate cycles slipping through the loader).
checkCols = [featureNames, {'SOH'}];
goodRows = all(isfinite(dataTable{:,checkCols}), 2);
nDropped = sum(~goodRows);
dataTable = dataTable(goodRows,:);

fprintf('\nFeature engineering complete: %d leakage-free features created (%d rows dropped as non-finite).\n', ...
    numel(featureNames), nDropped);
fprintf('EXCLUDED from features: Capacity, Amp-hour throughput, discharge energy (leakage sources).\n');
fprintf('EXCLUDED from features: BatteryID (kept only for battery-wise split/grouping).\n');

end
