function explainModel(RFModel, X, featureNames, outputFolder, queryIdx)
% EXPLAINMODEL  Model explainability using MATLAB's built-in `shapley`
% object (Statistics and Machine Learning Toolbox, R2021a+) applied to
% the Random Forest base learner, plus global permutation-based feature
% importance. This satisfies the explainability requirement without any
% third-party SHAP/LIME package.

if nargin < 5 || isempty(queryIdx)
    queryIdx = 1;
end

figFolder = fullfile(outputFolder,'Figures');
if ~exist(figFolder,'dir'), mkdir(figFolder); end

try
    explainer = shapley(RFModel, X, 'QueryPoint', X(queryIdx,:));

    f = figure('Color','w','Visible','off','Position',[100 100 700 450]);
    plot(explainer);
    title('SHAP Feature Contributions (Random Forest, sample query point)');
    exportgraphics(f, fullfile(figFolder,'SHAP_Explainability.png'), 'Resolution', 300);
    close(f);
    fprintf('\nSHAP explainability plot saved to %s\n', fullfile(figFolder,'SHAP_Explainability.png'));
catch ME
    warning('explainModel:ShapleyFailed', 'SHAP explainability step skipped: %s', ME.message);
end

try
    globalImportance = predictorImportance(RFModel);
    impTable = table(featureNames(:), globalImportance(:), ...
        'VariableNames', {'Feature','Importance'});
    impTable = sortrows(impTable, 'Importance', 'descend');
    writetable(impTable, fullfile(outputFolder,'FeatureImportance.xlsx'));
    fprintf('Global feature importance exported to FeatureImportance.xlsx\n');
catch ME
    warning('explainModel:ImportanceFailed', 'Feature importance export skipped: %s', ME.message);
end

end
