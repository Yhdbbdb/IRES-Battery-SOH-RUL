function [trainTbl, valTbl, testTbl] = batteryWiseSplit(dataTable, ratios)
% BATTERYWISESPLIT  Split data by whole battery (not by row), so no
% battery's cycles appear in more than one of train/val/test. This fixes
% the random row-wise split leakage in the original script, where cycles
% from the same battery could end up in both training and test sets.
%
% ratios : struct with fields train, val, test (should sum to ~1)

batteries = unique(dataTable.BatteryID);
nB = numel(batteries);

if nB < 3
    error('batteryWiseSplit:TooFewBatteries', ...
        'Need at least 3 distinct batteries for a train/val/test split (found %d).', nB);
end

rng(1); % reproducibility
shuffled = batteries(randperm(nB));

nTrain = max(1, round(ratios.train * nB));
nTrain = min(nTrain, nB - 2); % leave >=1 battery each for val and test
nVal   = max(1, round(ratios.val * nB));
nVal   = min(nVal, nB - nTrain - 1);
nTest  = nB - nTrain - nVal;

trainBatteries = shuffled(1:nTrain);
valBatteries   = shuffled(nTrain+1 : nTrain+nVal);
testBatteries  = shuffled(nTrain+nVal+1 : end);

trainTbl = dataTable(ismember(dataTable.BatteryID, trainBatteries), :);
valTbl   = dataTable(ismember(dataTable.BatteryID, valBatteries), :);
testTbl  = dataTable(ismember(dataTable.BatteryID, testBatteries), :);

fprintf('\nBattery-wise split (no battery appears in more than one set):\n');
fprintf('  Train: %2d batteries, %5d cycles\n', nTrain, height(trainTbl));
fprintf('  Val  : %2d batteries, %5d cycles\n', numel(valBatteries), height(valTbl));
fprintf('  Test : %2d batteries, %5d cycles\n', numel(testBatteries), height(testTbl));

end
