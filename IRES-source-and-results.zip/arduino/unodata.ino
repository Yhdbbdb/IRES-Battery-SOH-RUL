/*
  ==============================================================
       2S LI-ION BATTERY REAL-TIME MONITOR
       ARDUINO UNO -> PYTHON -> STREAMLIT
  ==============================================================

  SERIAL OUTPUT: 7 CSV values, 1 line per second, 115200 baud

  Cell1,Cell2,Pack,Current,BatteryTemp,AmbientTemp,Humidity

  HARDWARE:
  A0 -> Cell 1 voltage divider output
  A1 -> Cell 2 voltage divider output
  A2 -> ACS712 current sensor OUT
  D2 -> DHT11 DATA

  Pack voltage = Cell1 + Cell2
  No separate pack voltage sensor is used.
  BatteryTemp uses DHT11 temperature because no
  separate battery temperature sensor is connected.

  LIBRARIES:
  DHT sensor library by Adafruit
  Adafruit Unified Sensor

  IMPORTANT:
  - Keep A0 and A1 within 0-5 V.
  - Both cell measurements must be referenced correctly.
  - Negative current generally means discharging,
    depending on sensor orientation.
  ============================================================== 
*/

#include <DHT.h>

// ================= PIN CONFIGURATION =================

const int CELL1_PIN   = A0;
const int CELL2_PIN   = A1;
const int CURRENT_PIN = A2;

#define DHT_PIN  2
#define DHT_TYPE DHT11

DHT dht(DHT_PIN, DHT_TYPE);

// ================= ADC CONFIGURATION =================

const float ADC_REFERENCE = 5.000;
const int ADC_MAX = 1023;

// ================= VOLTAGE DIVIDER RATIOS =================
// Ratio = (Rtop + Rbottom) / Rbottom
// Change these according to actual resistor values.

const float CELL1_DIVIDER_RATIO = 2.000;
const float CELL2_DIVIDER_RATIO = 2.000;

// ================= VOLTAGE CALIBRATION =================
// Calibration = multimeter voltage / measured voltage

const float CELL1_CALIBRATION = 1.000;
const float CELL2_CALIBRATION = 1.000;

// ================= ACS712 CONFIGURATION =================
// ACS712-5A:  0.185 V/A
// ACS712-20A: 0.100 V/A
// ACS712-30A: 0.066 V/A
//
// Set these for your actual sensor.
// Zero voltage may need calibration.

float CURRENT_ZERO_VOLTAGE = 2.500;
float CURRENT_SENSITIVITY  = 0.185;

// ================= TIMING =================

const int ADC_SAMPLES = 20;

const unsigned long SEND_INTERVAL = 1000;
unsigned long lastSendTime = 0;

const unsigned long DHT_INTERVAL = 2000;
unsigned long lastDhtTime = 0;

float ambientTemp = 0.0;
float humidity = 0.0;

// ================= READ ADC VOLTAGE =================

float readAnalogVoltage(int pin)
{
  long total = 0;

  for (int i = 0; i < ADC_SAMPLES; i++)
  {
    total += analogRead(pin);
    delayMicroseconds(300);
  }

  float averageADC = (float)total / ADC_SAMPLES;

  return averageADC * ADC_REFERENCE / ADC_MAX;
}

// ================= READ CELL 1 VOLTAGE =================

float readCell1Voltage()
{
  return readAnalogVoltage(CELL1_PIN) *
         CELL1_DIVIDER_RATIO *
         CELL1_CALIBRATION;
}

// ================= READ CELL 2 VOLTAGE =================

float readCell2Voltage()
{
  return readAnalogVoltage(CELL2_PIN) *
         CELL2_DIVIDER_RATIO *
         CELL2_CALIBRATION;
}

// ================= READ BATTERY CURRENT =================

float readCurrent()
{
  float sensorVoltage = readAnalogVoltage(CURRENT_PIN);

  return (sensorVoltage - CURRENT_ZERO_VOLTAGE) /
         CURRENT_SENSITIVITY;
}

// ================= UPDATE DHT11 =================

void updateDHT()
{
  unsigned long now = millis();

  if (now - lastDhtTime < DHT_INTERVAL)
  {
    return;
  }

  lastDhtTime = now;

  float t = dht.readTemperature();
  float h = dht.readHumidity();

  if (!isnan(t))
  {
    ambientTemp = t;
  }

  if (!isnan(h))
  {
    humidity = h;
  }
}

// ================= LIMIT VALUES =================

float clampValue(float value, float minimum, float maximum)
{
  if (value < minimum) return minimum;
  if (value > maximum) return maximum;

  return value;
}

// ================= SEND CSV DATA =================

void sendBatteryData()
{
  updateDHT();

  float cell1 = readCell1Voltage();
  float cell2 = readCell2Voltage();

  // No pack voltage sensor: calculate from both cells.
  float pack = cell1 + cell2;

  float current = readCurrent();

  // DHT11 is the only temperature sensor.
  float batteryTemp = ambientTemp;

  // Limits for displayed values
  cell1 = clampValue(cell1, 0.0, 5.0);
  cell2 = clampValue(cell2, 0.0, 5.0);
  pack = clampValue(pack, 0.0, 10.0);
  current = clampValue(current, -20.0, 20.0);

  // Exactly seven comma-separated values
  Serial.print(cell1, 3);
  Serial.print(",");

  Serial.print(cell2, 3);
  Serial.print(",");

  Serial.print(pack, 3);
  Serial.print(",");

  Serial.print(current, 3);
  Serial.print(",");

  Serial.print(batteryTemp, 1);
  Serial.print(",");

  Serial.print(ambientTemp, 1);
  Serial.print(",");

  Serial.println(humidity, 1);
}

// ================= SETUP =================

void setup()
{
  Serial.begin(115200);

  pinMode(CELL1_PIN, INPUT);
  pinMode(CELL2_PIN, INPUT);
  pinMode(CURRENT_PIN, INPUT);

  dht.begin();

  delay(2000);

  // Initial DHT11 reading
  float t = dht.readTemperature();
  float h = dht.readHumidity();

  if (!isnan(t)) ambientTemp = t;
  if (!isnan(h)) humidity = h;

  lastDhtTime = millis();
  lastSendTime = millis();
}

// ================= MAIN LOOP =================

void loop()
{
  unsigned long now = millis();

  if (now - lastSendTime >= SEND_INTERVAL)
  {
    lastSendTime = now;
    sendBatteryData();
  }
}
